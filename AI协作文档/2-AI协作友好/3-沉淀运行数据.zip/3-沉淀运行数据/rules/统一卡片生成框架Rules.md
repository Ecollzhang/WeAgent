# Rules — 统一卡片生成框架

版本 ：v1.0
更新时间：2026.5.31

## 规则 1：emit 路径必须覆盖两种出口

`_enrich_file_element` 框架中，每个 `_gen_*()` 生成器有两种可能的返回值：

| 返回类型 | 示例 | emit 对象 |
|---------|------|-----------|
| 新元素 dict | `_gen_table` 返回 `{type:"table",...}` | emit 新元素 `c` |
| `None`（原地修改了原始 element） | `_gen_webpage` 在 `element.data` 上追加属性 | emit 原始 `element` |

**emit 代码块必须同时处理两种情况，缺一不可。**

禁止写法：
```python
c = gen(...)
if c:
    emit(c)     # ← 只处理新建元素，忘了 None 的情况
```

正确写法：
```python
c = gen(...)
if c:
    emit(c)
elif card_type_modified_original_element:
    flag_modified(message, 'elements')
    emit(element)   # ← 原地修改的原始 element 也要推送
```

### 追溯

此规则源于 Phase 2.5 引入统一框架时，`_gen_webpage` 从"新建元素"改为"原地修改"后，emit 路径断裂。导致前后端 JSON 不一致——后端改了但前端看不到。

## 规则 2：新增卡片类型必须同时注册以下三处

1. `CARD_ROUTES` 路由表
2. `generator_map` 生成函数映射
3. 对应的 `_gen_*()` 方法实现

缺一不可。缺少任一处会导致该类型卡片路由失败（已有 debug `[LOG Card]` 日志辅助）。

## 规则 3：前端编辑器 buttons 入口必须与后端卡片类型同步

后端新增 `_gen_*` → 前端对应类型的卡片模板中必须追加"编辑"按钮入口。否则后端生成卡片后，前端只展示不编辑，用户看不到任何交互入口。
