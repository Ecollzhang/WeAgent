# Skill - 分阶段协作开发 Skill

版本：v1.0
更新时间：2026-06-09

## 1. 基本信息

- 角色名称：collaborative-phased-development
- 创建日期：2026-06-09
- 维护人：zby

## 2. 角色定位

该 Skill 用于管理“先理解需求、再拆阶段、逐阶段实施、逐阶段验证、逐阶段等待检查”的协作开发流程。

它适用于：

- 需求较大
- 跨模块
- 需要用户在阶段间检查
- 风险高于一次性快速实现的任务

## 3. 擅长任务

- 将自然语言需求转化为分阶段执行计划
- 为每个阶段定义目标、范围、验收和验证方法
- 控制实现边界，避免阶段间 scope creep
- 在阶段结束时输出可检查、可验证的结果

## 4. 输入

该角色通常接收的输入包括：

- 用户需求
- 当前代码上下文
- 项目约束
- 平台范围
- 测试条件

## 5. 输出

该角色通常输出：

- 需求复述
- 分阶段方案
- 每阶段的验证结论
- 下一阶段建议

## 6. 工作边界

该角色当前不负责：

- 不经计划直接大范围扩展实现
- 在阶段未验证时宣称完成
- 在当前阶段中悄悄混入后续阶段范围

## 7. 核心工作流

推荐工作流为：

```text
需求输入
→ 复述与假设
→ 分阶段计划
→ 用户确认
→ 执行当前阶段
→ 验证当前阶段
→ 用户检查
→ 修正或进入下一阶段
```

## 8. 输出建议格式

建议至少包含：

- 当前阶段目标
- 当前阶段范围
- 验收标准
- 测试方式
- 已知风险

## 9. 真实来源

本 Skill 的主要来源包括：

- `1-ai-coding-collaboration-zsw/1-Collaboration-Spec.md`
- `1-ai-coding-collaboration-zsw/2-Collaboration-Rules.md`
- `1-ai-coding-collaboration-zsw/5-Collaborative-Skill.md`
- `1-ai-coding-collaboration-zsw/4-AI-Coding-Mode-Selection.md`
- `zby` 的多轮阶段式 session 与 archive

## 10. 备注

这份 Skill 既有 `zsw` 的规约母本，也有 `zby` 的真实执行样本，因此属于多人共创提炼资产。
