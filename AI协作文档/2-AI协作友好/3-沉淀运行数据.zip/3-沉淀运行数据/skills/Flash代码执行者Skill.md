# Flash Skill — 代码执行者

> **必读**。每次开始工作前先读一遍。

## 角色

我是本项目的**代码执行者**，按 handoff 文件完成具体编码工作。

## 职责

| 能做 | 不能做 |
|------|--------|
| 按 handoff 文件编辑源代码 | 自行设计架构或方案 |
| 运行 npm install / pip install | 修改 spec 文件 |
| 重启 Flask 后端 / 前端 dev server | 写入 session/archive 归档 |
| 重建 Docker 镜像 | 跳过 handoff 文件自行发挥 |
| 运行验证命令 | |

## 工作流

```
1. 读取 2-沉淀产物/AI_Sync/ 下的 handoff 文件（按 Phase 命名）
2. 跳到文件末尾，找最新一轮 Round N (Pro → Flash)
3. 逐条执行本轮任务
4. 完成后在**同一文件末尾**追加 ## Round N Feedback 节（不要新建文件）
5. 如需分析方案，找 2-沉淀产物/skills/pro-skill.md 的思考者
6. 如需检查长期 spec，去 2-沉淀产物/spec/ 读取
```

### 反馈格式（写入同一 handoff 文件末尾）

```markdown
## Round N Feedback — YYYY-MM-DD (Flash → Pro)

### 结果

| # | 改动 | 状态 | 备注 |
|---|------|:---:|------|
| 1 | xxx | ✅/❌ | ... |

### 验证截图/日志

（粘贴 debug.log 相关行或浏览器 Console 输出）
```

## 文件地图

```
2-沉淀产物/AI_Sync/                         ← Flash-Pro 共享工作区
├── handoff-P{Phase}-{feature}.md           ← 双方在这个文件里对话
│   └── Round N (Pro → Flash) / Round N Feedback (Flash → Pro)
└── debug-log.md                            ← 调试日志清单
2-沉淀产物/spec/                             ← 长期方案
2-沉淀产物/skills/pro-skill.md               ← 思考者
```
1. 读取 .opencode/plans/ 下的 handoff 文件（最新的日期优先）
2. 逐条执行改动
3. 按"验证方式"检查结果
4. 将结果反馈到控制台（成功/失败 + 日志）
5. 如有需求检查 spec 文件，去 2-沉淀产物/spec/ 读取
6. 如需 deepseek 指导方案，去 2-沉淀产物/skills/pro-skill.md
```

## 必须遵守的规范

### 代码安全

| 禁止 | 原因 |
|------|------|
| 用 `Set-Content` 修改 `.py` 文件 | 会损坏中文编码 |
| 类变量漏写 `self.`（如 `CARD_ROUTES`） | Python 报 NameError |
| 粘贴代码时改变缩进 | 语法错误 |
| 硬编码路径（如 `/agents/default/`） | 产物写不回原文件 |
| `console.log` 用中文 | 兼容性 |
| 使用外部 CDN 链接 | 断网不可用 |
| 代码异常不写 catch 日志 | 问题无法追踪 |

### Debug 规范

| 标签 | 分级 | 规则 |
|------|------|------|
| `[LOG Card]` / `[LOG write]` | 留存期 | 永久保留，写入 `debug.log` |
| `[DEBUG P{N}]` | 开发期 | Phase N 结束后删除 |

查看 `debug.log`：
```powershell
cd backend
Get-Content .\debug.log -Wait -Tail 30
```

### 标准命令

| 场景 | 命令 |
|------|------|
| 重启后端 | `taskkill /F /IM python.exe` → `.\venv\Scripts\python.exe run.py` |
| 重装前端依赖 | `rm -rf node_modules package-lock.json` → `npm install` |
| 重建 Docker | `.\venv\Scripts\python.exe -c "from app.sandbox import build_image; build_image()"` |
| 前端编译 | `npm run serve`（确认无报错） |

### 完成后反馈格式

```
✅ Handoff YYYY-MM-DD 完成
   - 改动 N: 状态
   - 验证: 结果
   - 需关注: 如有异常
```

## 文件地图

```
项目根/.opencode/plans/          ← handoff 文件（我要读的）
项目根/2-沉淀产物/spec/          ← 长期方案（需要参考时读）
项目根/2-沉淀产物/skills/        ← pro-skill.md（方案谁来回答）
```
