# 双 AI 协作归档 Skill — Pro-Flash 归档工作流

> 提炼来源：`pro-skill.md`、`flash-skill.md`、`handoff-P3-editor.md`、`05-30_pro_指导` / `05-30_flash_运行` session
> 适用场景：两个 AI 角色（方案者 + 执行者）协作完成一个任务后，如何将协作成果归档到沉淀产物中。

---

## 角色分工

| 角色 | 归档职责 | 不负责 |
|------|---------|--------|
| **Pro**（方案者） | 写 spec、写 session、写 archive、写 summary | 不写代码 |
| **Flash**（执行者） | 写 handoff 反馈、写执行记录 | 不写 session/archive |

---

## 核心原则：一次协作，一个 session

**一次完整的 Pro-Flash 协作（一个 handoff 文件从开始到所有 Round 完成），最终只对应一个 session。不按 Round 分次归档，不在中途写 session。**

归档只在协作完全收口后执行，由 Pro 一次性完成。

## 协作归档流程

```
阶段 1：Pro 出方案 → 写 handoff Round 1（不写 session）
阶段 2：Flash 执行 → 写 Round N Feedback（不写 session）
阶段 3：多轮迭代直到任务收敛（仍不写 session）
阶段 4：统一收口 → Pro 回到 handoff 文件
  → 提取关键决策、执行结果、根因
  → 写一份 session（含全部 Round 的关键信息）
  → 判断是否需要升级为 archive / spec / skill / rule
```

### 关键原则

```
谁设计方案 → 谁写归档
谁执行代码 → 谁提供素材（handoff 反馈）
归档只在最后做一次
```

Flash 不写 session/archive，但 handoff 反馈是归档的原材料。Pro 在任务收口后，从 handoff 中提取以下内容写入一份 session：

- 本轮要解决什么问题（来自 handoff Round N 的任务描述）
- 执行结果和验证结果（来自 Flash 的反馈）
- 迭代过程中发现的根因和关键决策
- 是否值得升级为 spec / skill / rule

---

## Handoff 文件→归档的映射

| Handoff 中的内容 | 归档到哪里 |
|----------------|-----------|
| Round N 任务描述（问题 + 方案） | session 的「背景与目标」或「讨论过程」 |
| Round N 代码改动和路径 | session 的「收敛结果」 |
| Round N 验证结果 | session 的「验证记录」 |
| 多轮迭代中发现的根因 | archive 的「决策记录」 |
| 可复用的排查或修复模式 | skill 或 rule |

---

## 归档时机

归档只在**所有 Round 完成后统一做一次**：

| 触发条件 | 归档类型 | 谁执行 |
|---------|---------|--------|
| handoff 文件所有 Round 完成后，任务收敛 | session（一份） | Pro |
| 本次协作有核心决策或收口价值 | archive（可选，从 session 升级） | Pro |
| 协作模式稳定重复出现 | skill / rule（可选） | Pro |

---

## 示例（从 handoff-P3-editor.md 看归档链路）

```
handoff-P3-editor.md 内容：
  Round 1 (Pro → Flash): 3 个任务
  Round 1 Feedback (Flash → Pro): 执行结果
  Round 2 (Pro → Flash): 根因分析 + 修复方案
  Round 2 Feedback (Flash → Pro): 验证结果

归档结果：
  session: "Phase 3 编辑器双弹窗修复与推送修复"
    从 Round 1 的任务描述提取背景
    从 Round 1 Feedback 提取执行结果
    从 Round 2 的根因分析提取关键决策
    从 Round 2 Feedback 提取验证结果

  archive → card-framework-rules.md:
    从 Round 2 发现的 emit 路径断裂问题
    提炼为规则：`emit 路径必须覆盖两种出口`
```

---

## 不做的事

- Flash 不写 session/archive
- 不按 Round 分次归档（等所有 Round 完成后一次写）
- 不要求每个 handoff 文件都对应一个 session（只有收敛后值得保留的才归档）
- 归档不在中途写，只在最后收口时统一写
