# Session — Elements Schema、Diff 产物展示与全链路调试

版本 ：v1.12
更新时间：2026.5.29

## 1. 基本信息

- Session 名称：Elements Schema 实现、Diff 产物展示、WebPreviewCard 文件树、容器内提示词修改
- 日期：2026-05-28 ~ 2026-05-29
- 参与人类成员：zby（张博阳）
- 参与 AI 角色：AI 协作助手
- 对应负责人：zby
- 对应任务方向：从代码块到后端信息数据存储与前端展示
- 本次记录范围：Elements Schema 重构（type+role+subtype）、产物数据链条（tool_results → Artifact → diff 元素）、WebPreviewCard 文件树双面板、Dashboard 文件浏览器的 diff 渲染、容器内提示词修改、多轮全链路调试

## 2. 本轮背景与初始判断

- 上一轮（v1.1 和 v1.12-05-28）已完成环境部署和分支切换
- 项目使用 feature/multi-agent-and-artifact-v1 分支
- 本轮目标：实现 Elements 数据结构重构和产物数据链条的端到端打通
- 讨论从产物存储方案开始，经过多轮发散—收敛，最终聚焦于 diff 展示和 Artifact 记录

## 3. 讨论过程

### 【讨论一】产物存储方案

- 【问题】Agent 回复中产生的文件应该怎么存储？
- 【方案比较】
  - 方案 A：只存路径引用（Artifact 表只存 path，内容从容器读取）
  - 方案 B：全量存到 DB
  - 方案 C：全不存
- 【收敛】分层方案：文本文件（.html/.css/.js/.py/.md 等）存 content 到 DB，二进制（图片）只存 path

### 【讨论二】Elements 数据结构设计

- 【问题】旧版平铺 9 种元素类型（text/code/table/image/file/doc/webpage/diff/deploy_status），继续扩展会失控
- 【收敛】三级分类：
  - type（5 个基础）：text / code / table / image / file — 不再增加
  - role：progress / result / error — 控制视觉效果
  - subtype：决定渲染变体（diff / webpage / doc / deploy_status / code_preview / editable 等）
- 新增 type: deploy — 部署状态卡片不适合放 file 下，单独新增为第 6 个 type
- table 默认可编辑，readonly 是特例

### 【讨论三】Diff 展示改版

- 【需求】从行级 diff 改为 Codex 风格：文件卡片头 + 修改纪要 + 统计
- 【收敛】diff 元素有两层：折叠时显示文件卡片 + `+12 -3` 标签，展开时显示 DiffViewCard
- 实施：MessageBubble 中 `code.subtype=diff` 默认以文件卡片展示，点击"Diff对比"按钮切换为行级 diff 视图

### 【讨论四】HTML 文件树展示

- 【需求】HTML 产物显示文件树（index.html + css/style.css + js/app.js），独立预览每种文件
- 【实施】WebPreviewCard 改为双面板：左侧文件树，右侧 iframe/代码预览
- 后端 `_enrich_webpage_elements` 自动将同目录文件归组成 `files` 数组

### 【讨论五】部署方式

- 任务说明明确了 4 种部署方式：预览 URL / 静态站点部署 / 容器化部署 / 源码打包
- 创建 deploy 后端 API（最小化 CRUD）

### 【讨论六】Artifact 存储与 diff 生成位置

- 【问题】diff 在容器内生成还是 Host 端生成？
- 【方案比较】
  - 容器内：需要重建 Docker 镜像（15-18 分钟），调试困难
  - Host 端：利用已存入 DB 的 Artifact 内容做 difflib 对比，不需要重建镜像
- 【收敛】Host 端生成 diff
- 实施：`_create_artifact_from_tool` 中新增 diff 生成逻辑——创建 Artifact 后查询同 path 的上一个版本，有则 `difflib.unified_diff` 对比，生成 `{type: "code", subtype: "diff"}` 元素

### 【讨论七】Container 内提示词修改

- 【问题】Agent 修改文件后不报告 file 类型元素，导致前端无显示
- 【修改】`agent.py` 的 `_format_agent_md()` 和 `_runtime_instruction()` 都增加了规则：修改已有文件后必须用 `weagent-report type=file` 上报
- **需要重建 Docker 镜像**，尚未执行

### 【讨论八】全链路调试过程

- 【问题】`_mark_agent_message_done_if_active` 不执行
  - 定位：事件桥已先将状态设为 done，导致该函数早期 return
  - 修复：将 `tool_results` 的处理移到状态检查之前，无论消息状态都创建 Artifact
  - 同时加上 `flag_modified(msg, 'elements')` 确保 SQLAlchemy 检测变更
- 【问题】删除会话报 Server Error
  - 定位：`db.session.delete(conversation)` 级联删除 messages 时，Artifact 和 AgentRun 的外键约束违反
  - 修复：在 delete 前先批量删除 Artifact 和 AgentRun 记录
- 【问题】属性面板不显示
  - 做了多轮尝试：fetch 内容、服务端注入编辑脚本、改变 `src`/`srcdoc` 方式
  - 最终回退了大部分改动，保持原始 ArtifactFullscreenPreview 的 `showLayers` + `srcdoc` 方案
  - 现状：属性面板仍未正常工作，原因可能涉及 iframe postMessage 或 INJECT_SCRIPT 执行

### 【讨论九】Ai-collab 归档整理

- 将 WeAgent-main 和 WeAgent 两个目录下的 ai-collab 内容合并到 2-沉淀产物
- WeAgent（旧项目）版本优先（含更多 archive、rules、session 文件）
- WeAgent-main 独有的 2 个 session 文件（v1.1-05-28、v1.12-05-28）已补充

## 4. 执行细节

### 后端文件变更

| 文件 | 改动内容 |
|------|---------|
| `message_element_builder.py` | 新增 `error_element`；`progress_element`/`result_element` 改为 `type:text`+`role`；`file_event_element` 按扩展名映射 subtype；URL 加入 `urllib.parse.quote` 编码 |
| `sandbox_event_bridge.py` | 适配新旧 schema 兼容（progress 检查同时支持 `type=progress` 和 `type=text+role=progress`）|
| `message_service.py` | `_mark_agent_message_done_if_active` 重构：tool_results 处理提到状态检查前；新增 `_create_artifact_from_tool`、`_enrich_webpage_elements`、`_read_artifact_content`、`_guess_artifact_type`；`has_result`/`has_text` 检查适配新 role 字段 |
| `models/artifact.py` | 新增 `path`、`meta` 字段；`artifact_type` 枚举加 `deploy` |
| `models/conversation.py` | 已含 sandbox 相关字段（本分支已有）|
| `services/conversation_service.py` | `delete_conversation` 先删 Artifact/AgentRun 再删 conversation |
| `sandbox/container/agent.py` | `_format_agent_md()` 和 `_runtime_instruction()` 增加"修改文件必须上报 file"规则 |
| `sandbox/api/routes.py` | 新增 `/editor/` 端点（服务端注入编辑脚本，最终未使用）|
| `app/__init__.py` | 注册 deploy blueprint；artifacts.path/meta 自动迁移；deploys 自动建表；deploy_service 延迟导入 |

### 前端文件变更

| 文件 | 改动内容 |
|------|---------|
| `MessageBubble/index.vue` | 元素渲染适配新 schema（role + subtype）；新增 code.subtype=diff 文件卡片风格（diff stat 标签 + Diff 对比按钮）；新增 file.subtype=webpage/code_preview/deploy_status 渲染分支；导入 5 个新组件；新增全屏预览 ArtifactFullscreenPreview |
| `WebPreviewCard/index.vue` | 增加文件树双面板布局（左侧文件列表，右侧 iframe/代码预览）|
| `Dashboard.vue` | 导入 DiffViewCard；文件浏览器预览区新增 `.diff` 文件分支；新增 `diffViewData` computed |
| `Settings.vue` | 新增自定义模型名称输入框；保存时替换 model 为 custom_model_name |
| `ArtifactFullscreenPreview/index.vue` | 回退至原始版本；新增文件树侧边栏 + 文件/层级 tab 切换；自动 fetch URL 内容 |
| 新增 `ArtifactPreview` | 从旧项目移植 |
| 新增 `DiffViewCard` | 从旧项目移植（256 行）|
| 新增 `WebPreviewCard` | 从旧项目移植（基础上改造）|
| 新增 `DocPreviewCard` | 从旧项目移植（139 行）|
| 新增 `DeployStatusCard` | 从旧项目移植（188 行）|
| 新增 `ArtifactFullscreenPreview` | 从旧项目移植（593 行）|
| 新增 `api/deploy.js` | 从旧项目移植 |

### 配置文件

- `opencode.json` — 新增，配置 AI 协作规则
- `PROJECT_STRUCTURE.md` — 新增，项目文件树地图
- `C:\Users\Lenovo\.docker\daemon.json` — 新增 registry-mirrors
- `docs/ai-collab/` — 合并到 `2-沉淀产物/`

## 5. 当前收敛结果

- Elements Schema 已重构为 type + role + subtype 三级分类
- Artifact 记录已能正常创建（数据库有数据）
- diff 元素已能在后端生成并存入 `Artifact.meta.diff_text`
- `_mark_agent_message_done_if_active` 已修复提前返回问题
- 删除会话的外键约束问题已修复
- 文件树双面板（WebPreviewCard）已实现
- 容器内提示词已修改（但 Docker 镜像未重建，尚未生效）
- 旧项目中的 6 个前端组件已移植到新分支
- Windows Docker Desktop registry-mirrors 已配置

### 未解决问题

1. **diff 元素前端不显示** — 可能原因：`UPDATE_MESSAGE` mutation 的 `mergeElements` 逻辑或组件渲染问题
2. **属性面板不显示** — ArtifactFullscreenPreview 的 iframe postMessage 通信问题
3. **Docker 镜像未重建** — 提示词修改需要重建容器后才能生效
4. **WebPreviewCard 文件树内容** — 依赖后端 `_enrich_webpage_elements` 生成 `files` 数组，需要验证

## 6. 后续方向

- zby 决定**从头开始**，可能涉及重构或重新设计
- 未生效的 Docker 镜像重建、属性面板修复等工作可能在新方案中重新处理

## 7. 可沉淀结果

- 是否值得升级为 `Archive`：是 — Elements Schema 和产物数据链条是核心架构决策
- 可升级为 `Spec`：是 — elements 三级分类完整规范
- 可升级为 `Skill`：否
- 可升级为 `Rules`：是 — "新增元素类型必须遵循 type+role+subtype 三级分类，不得平铺枚举"
