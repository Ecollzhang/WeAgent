# Session - Phase 4 Diff 历史副本路线实现与联调收口
版本：v1.15
更新时间：2026.5.31

## 1. 基本信息

- Session 名称：Phase 4 Diff 历史副本路线实现与联调收口
- 日期：2026-05-31
- 协作模式：AI 协作助手 / 人类（zby）
- 对应负责人：zby
- 对应任务方向：前端产物编辑系统 Phase 4 Diff
- 本次记录范围：从 Diff 技术路线讨论 → 选定 `.weagent_history` 历史副本方案 → 落地后端 diff 生成 / 前端 diff 卡片 → 联调与问题定位
- 文件路径：`2-沉淀产物/sessions/zby-session-v1.15-05-31-2.md`

## 2. 本轮背景与初始判断

- 在 HTML 轻量编辑器初步可用后，下一主线切到 spec 中的 Phase 4：Diff 展示与应用
- 起初讨论过三条路线：
  - 直接使用 Git
  - 使用模型记忆生成 diff
  - 在 Docker 工作空间内建立历史文本副本
- 结合当前项目状态判断：
  - Git 路线正确但偏重，不适合这一阶段
  - 纯模型记忆 diff 展示性强但不稳定
  - 基于真实文件前后内容生成 diff，是当前最平衡的折中路线
- 最终用户确认：
  - 在容器工作空间内建立 `.weagent_history`
  - 同一文件最多保留两版历史
  - 先只跟踪文本类文件

## 3. 讨论与实现过程

- 【路线收敛】确认 Phase 4 不再坚持 spec 里原来的“模型记忆 diff”方案，而是改为“真实文件前后内容 + 工作区历史副本”
- 【规则确认】用户明确接受以下规则：
  - 只要文件将被写入，就进入历史跟踪
  - 历史放在 `/workspace/.weagent_history`
  - 同一文件只保留 `latest` / `previous` 两版
  - 先只处理文本类文件
- 【后端实现】新增 `workspace_diff_service.py`
  - 负责 trackable 文件判断
  - 负责 `.weagent_history` 快照写入
  - 负责基于真实 before / after 生成 unified diff
  - 负责把 diff 转成前端消息元素
- 【后端接线】在写回 API 与 `file_write` 事件桥接中接入 diff 能力
  - 前端编辑器保存文件时，写回接口会先计算 diff、写入文件、再存最新快照
  - agent `file_write` 事件到来时，会尝试从历史快照中取上一版并生成 diff 元素
- 【前端接线】新增 `DiffViewCard`
  - 独立展示 diff 卡片
  - 支持 `Diff / 修改后` 两种视图
  - 提供“应用修改”按钮，直接写回目标文件
- 【联调发现】第一次 agent 改某个旧文件时没有 diff 卡片
  - 通过后端 debug 日志定位到 `latest_len=None / had_latest=False / reason=first-snapshot`
  - 结论：当前实现第一次只能建立首个快照，第二次才能稳定产出 diff
- 【性能与体验优化】围绕“diff 出现太慢”做了三类减法：
  - 不再把“修改前整份内容”跟随消息流传输
  - `DiffViewCard` 只保留 `diff + 修改后预览`
  - 大文件 diff / after 内容增加截断预览，减轻消息体与渲染压力
- 【过程提示】为 `file_write` 增加了“正在生成 diff...”的进度占位，再补真正结果
- 【路径问题】修复 `file_write` 上报相对路径 `agents/...` 时无法生成文件元素的问题
- 【噪音问题】联调中又出现两个问题：
  - 出现两个 `index3.html`
  - 暴露了 `.weagent_claude_session`
- 【定位结果】判断来源有两层：
  - 系统文件本应隐藏，却被当普通 file/event 暴露
  - 前端步骤区把重复 file_write / event 也展开显示，放大了重复感
- 【收口修复】
  - 后端 `message_element_builder.py` 过滤系统文件与 `.weagent_history`
  - 前端 `MessageBubble` 的 historySteps 过滤内部路径
  - artifact 去重键改为更稳定的规范化路径

## 4. 当前收敛结果

- Phase 4 已从“纯讨论”推进到“有代码主链”
- 当前已具备：
  - 文本类文件进入 `.weagent_history`
  - 后端基于真实文件内容生成 diff
  - 聊天流中渲染独立 diff 卡片
  - diff 卡片支持查看 diff 与修改后预览
  - diff 卡片支持应用修改
- 已知行为边界：
  - agent 第一次修改某个尚未进入历史的旧文件时，通常只建快照，不直接出 diff
  - 第二次再改同一文件时，才更稳定地产出 diff
- 已知体验边界：
  - “正在生成 diff...”占位可能因为真实生成速度较快而不明显
  - 当前还没有强制最小展示时长

## 5. Debug / 验证记录

| # | 验证项 | 结果 | 关键日志 / 备注 |
|---|--------|:---:|----------------|
| 1 | 后端 diff 服务语法检查 | 通过 | `python -m py_compile` 已通过 |
| 2 | 首次 agent 改旧文件是否直接出 diff | 否 | `[DEBUG P4] ... reason=first-snapshot` |
| 3 | 第二次同文件修改是否理论可出 diff | 是 | 由快照逻辑推导，待持续联调 |
| 4 | file_write 相对路径 `agents/...` 是否可识别 | 已修复 | `message_element_builder.py` 已补路径规范化 |
| 5 | `.weagent_claude_session` 是否应暴露 | 否 | 已在后端与前端步骤区双层过滤 |
| 6 | 重复 `index3.html` 是否需要去重 | 是 | 已改 artifactKey 和 historySteps 去重策略 |
| 7 | 占位 diff 是否稳定可感知 | 未完全验证 | 当前只加了占位进度，尚未加最小展示时长 |

## 6. 未解决问题 / 后续建议

- 若希望“agent 第一次修改已有文件就直接出现 diff”，仍需要把当前逻辑进一步推进到真正的“写前备份”
- 若用户仍觉得占位 diff 不明显，可后续补“最小可见时长”
- 当前 diff 卡片已做轻量化，但对超大 HTML/CSS/JS 文件仍可能偏重，后续可继续优化：
  - 只展示变更块
  - 更激进的 diff 截断
  - 分块加载
- 多文件页面（`html + css + js`）后续仍需单独设计：
  - 现在 diff 是按单文件生成
  - 还没有真正的多文件变更汇总视图

## 7. 可沉淀结果

- 是否值得升级为 Archive：是，涉及 Phase 4 Diff 技术路线从 spec 旧方案转向真实文件历史副本方案
- 可升级为 Spec：是，可更新现有前端产物编辑系统 spec 中过时的 diff 路线描述
- 可升级为 Rules：是，可沉淀“分析类提问先确认是否需要改代码”“当前阶段优先真实文件历史副本而非 Git / 模型记忆 diff”
- 可升级为 Skill：否
