# Session — 新分支代码摸底与前端产物编辑系统方案设计

版本 ：v1.13
更新时间：2026.5.29

## 1. 基本信息

- Session 名称：新分支代码摸底与前端产物编辑系统方案设计
- 日期：2026-05-29
- 参与人类成员：zby（张博阳）
- 参与 AI 角色：AI 协作助手
- 对应负责人：zby
- 对应任务方向：产物前端编辑增强（代码编辑、表格编辑、图片裁剪、Diff 应用）
- 本次记录范围：阅读新分支代码、架构决策讨论、前端产物编辑系统方案设计与文档产出

## 2. 本轮背景与初始判断

- 上一轮（v1.12-05-29）结束时的产物编辑改动因效果不理想，zby 撤销了所有更改
- 组长已更新代码到新分支 `bugfix/partipant_num_and_msg_time_fix`
- zby 希望在重新开发前进行深入讨论，明确架构设计后再动手
- 核心目标：增强前端产物组件的编辑能力，让用户可以在聊天流中直接修改 Agent 生成的代码、表格、图片、Diff

## 3. 讨论过程

### 【讨论一】架构决策：DB 还是文件驱动

- 【初始】zby 提出不设计 DB，所有修改直接对接 Docker 容器中的文件
- 【追问】Artifact 表是否废弃 → 【收敛】废弃，Docker 容器文件系统为唯一真相源
- 【追问】元素内是否嵌入 content → 【收敛】方案 B：text/code/table/diff 的 content 嵌入元素 JSON，图片/二进制只存 path

### 【讨论二】Diff 生成方案评估

- 【方案】zby 提出三种方案：A 容器装 git / B 模型记忆 / C 历史文件夹
- 【讨论】方案 A 需修改 Docker 镜像（装 git、管理 .gitignore），复杂度高；方案 B 最简但不可靠；方案 C 文件系统操作，隔离性好
- 【收敛】先采用方案 B（模型记忆），简单验证可行性，后续可升级

### 【讨论三】前端编辑与容器写回

- 【问题】前端编辑后如何写回容器？当前只有 `upload_agent_file()` 能写入
- 【方案】设计新的写回 API：`PUT /api/sandbox/sessions/{sid}/files/write`
- 【问题】编辑后的 Agent 是否应看到新版本 → 【收敛】必须看到，保存即覆盖容器文件

### 【讨论四】代码编辑器选型

- 【讨论】CodeMirror（~100KB gzip）vs Monaco（~20MB）
- 【收敛】CodeMirror，轻量且语法高亮好，对 150MB 的镜像影响可忽略。要求 material-darker 暗色主题

### 【讨论五】图片裁剪方案

- 【讨论】cropperjs（40KB）vs 原生 Canvas API
- 【对比】cropperjs 内置：拖拽、缩放、比例锁定、旋转、翻转、实时预览、触摸支持，而原生 Canvas 需要手工实现 80-150 行
- 【收敛】采用 cropperjs，40KB 换完整的裁剪体验

### 【讨论六】表格编辑与 CSV 文件

- 【问题】Agent 上报的 table 是纯 JSON，Docker 里没有对应文件，保存时怎么办
- 【收敛】要求 Agent 上报 table 时必须同时写入 CSV 文件并上报 file。表格天然有 path，保存直接覆盖

### 【讨论七】HTML 编辑器选型 — GrapesJS 替代手写组件

- 【问题】旧版 ArtifactFullscreenPreview（593 行手写代码）功能包含可视化编辑、源码编辑、层次树、属性面板、组件增删改。是否有轻量级现成替代？
- 【方案】zby 提到之前手写的 HTML 编辑器，功能对标低代码编辑器。讨论了 GrapesJS 作为替代
- 【对比】GrapesJS（~200KB gzip）内置：可视化拖拽、源码切换（内联 CodeMirror）、层次树面板、属性面板（CSS）、撤销/重做、响应式预览。比手写代码更稳定成熟，不会有 postMessage 通信问题
- 【CodeMirror 重复问题】zby 提出 GrapesJS 内置 CodeMirror，与独立安装的 codemirror 是否重复 → 【结论】不重复。GrapesJS 内联打包自己的 CodeMirror，外界不可访问。独立 CodeMirror 用于 .py/.js/.css 等非 HTML 文件编辑
- 【收敛】HTML 文件编辑采用 GrapesJS，替代旧版 ArtifactFullscreenPreview。Phase 3 拆分为 3A（CodeMirror 独立编辑器）+ 3B（GrapesJS 低代码编辑器），按文件类型自动分发

### 【收敛】确认方案设计

- zby 确认所有讨论点后，产出完整开发方案 spec 文档
- 方案包含 6 个 Phase，按依赖顺序实施
- HTML 编辑采用 GrapesJS（替代 ArtifactFullscreenPreview），与 CodeMirror 独立编辑器按文件类型分发
- 拆分了部署功能为独立讨论

## 4. 当前收敛结果

- 新分支 `bugfix/partipant_num_and_msg_time_fix` 代码已完整摸底
- 流式产物链路已梳理清楚：`weagent-report → push_event → SandboxEventBridge → MessageBubble`
- 架构决策明确：
  - 文件驱动（无 DB 存储产物内容）
  - 编辑 → 保存 → 写回容器文件
  - 小文本嵌入元素，大文件/图片引用 path
  - CodeMirror 做非 HTML 代码编辑，GrapesJS 做 HTML 可视化编辑
  - cropperjs 做图片裁剪
  - Diff 依赖模型记忆（方案 B）
- 产出正式开发方案文档：`.opencode/plans/5-前端产物编辑系统.md` 及 `2-沉淀产物/spec/5-前端产物编辑系统-开发方案.md`

## 5. 未解决问题 / 后续建议

- HTML 编辑+部署功能拆分单独讨论
- Diff 方案 B（模型记忆）需实际测试验证可靠性
- 写回 API 的 agent_id 解析需确认 workspace_name 与 participant_name 的映射逻辑
- 图片跨域加载至 cropperjs 需确认沙箱 API 返回正确的 CORS 头

## 6. 可沉淀结果

- 是否值得升级为 `Archive`：是 — 本次对话确定了核心架构决策（文件驱动、写回 API、技术选型）
- 可升级为 `Spec`：是 — 已产出完整开发方案 `.opencode/plans/5-前端产物编辑系统.md`
- 可升级为 `Skill`：否
- 可升级为 `Rules`：是 — "产物编辑后的内容一律写回 Docker 容器文件，不经过 DB 中转"
