# Session — 对话产物跨会话迁移方案执行（Spec 9）

版本 ：v1.15
更新时间：2026.06.06

## 1. 基本信息

- Session 名称：对话产物跨会话迁移方案执行（Spec 9）
- 日期：2026-06-06
- 协作模式：执行者（Codex）+ 人类（zby）
- 通信目录：2-沉淀产物/AI_Sync/
- 对应负责人：zby
- 对应任务方向：`spec/9-对话产物跨会话迁移方案` 文档收口后的代码实现
- 本次记录范围：围绕 `combineartifact_editing_system(base_v1.08)` 落地跨会话文件迁移的后端 API、前端入口与对话框最小闭环，并同步补 session 记录
- 文件路径：2-沉淀产物/sessions/zby-session-v1.15-06-06-spec9执行.md
- 本 Session 产出 Handoff：无

## 2. 本轮背景与初始判断

在 `spec/9`、`9.1`、`9.2`、`9.3` 已经把方案边界和评议收口到 `v1.2` 之后，用户要求不再停留在文档层，而是直接“按照 9- 进行执行”。

开始时的初始判断是：

- 当前底层并不是从零开始
- `combineartifact_editing_system(base_v1.08)` 已有单会话文件树、raw、download、write、export-zip，以及 host 侧 Docker SDK 直读直写能力
- 因此最小实现闭环应该是：
  - 后端：preview + execute API、owner 校验、路径映射、复制逻辑、系统结果消息
  - 前端：ChatWindow 更多菜单入口、迁移对话框、preview/execute 调用

也就是说，本轮重点不是补底层文件能力，而是补一层“跨会话复制编排”。

## 3. 讨论过程

【进展】确认当前代码切入点
- 阅读并确认了以下真实主链路：
  - `backend/app/sandbox/api/routes.py`
  - `backend/app/sandbox/host/manager.py`
  - `backend/app/services/conversation_service.py`
  - `frontend/src/api/sandbox.js`
  - `frontend/src/components/ChatWindow/index.vue`
  - `frontend/src/views/Dashboard.vue`
- 结论：后端最合适的承载点是 `sandbox routes + conversation_service + manager`，前端最合适的承载点是 `ChatWindow -> Dashboard -> FileMigrationDialog`

【收敛】消息落点明确不走 `SandboxEventBridge`
- 代码核对后确认：
  - `SandboxEventBridge` 强依赖 runtime event / active run / message_id
  - 不适合承载“用户主动点击迁移文件”的管理动作
- 因此实现上改为：
  - 在 `conversation_service.py` 新增系统结果消息写入方法
  - 直接创建 `Message(sender_id='system')`
  - 通过 socket 推送 `conversation_message_created`

【进展】后端实现：ConversationService 扩展
- 在 `conversation_service.py` 中新增：
  - `get_owned_conversation_or_error`
  - `resolve_sandbox_session_id`
  - `create_migration_result_message`
- 目的：
  - 统一 owner 校验
  - 统一 `conversation -> sandbox_session_id` 解析
  - 统一迁移完成后的系统消息创建与 socket 发射

【进展】后端实现：Manager 扩展
- 在 `backend/app/sandbox/host/manager.py` 中新增迁移主逻辑：
  - `preview_files_between_sessions`
  - `copy_files_between_sessions`
  - `_collect_migration_candidates`
  - `_resolve_migration_path_mapping`
  - `_map_target_path`
  - `_target_path_exists`
  - `_copy_one_path_between_sessions`
  - `_is_empty_directory`
  - `_normalize_workspace_path`
- 当前策略按 `spec/9 v1.2` 收口：
  - 外部默认根目录 `/workspace/agents`
  - 默认过滤低价值目录
  - 单文件失败采用尽力模式，写入 `errors`
  - 空目录记入 `skipped`
  - 自动 mapping 以 ASCII 同名 workspace 为主，其余走 `migrated_from_*`

【进展】后端实现：Sandbox Routes 扩展
- 在 `backend/app/sandbox/api/routes.py` 中新增：
  - `GET /api/sandbox/conversations/{source}/files/migrate-preview`
  - `POST /api/sandbox/conversations/{source}/files/migrate`
- 并补充：
  - `_current_user_id_required`
  - `source == target` 防护
  - preview 支持显式 `paths`
- 执行迁移后会自动在目标会话中写一条系统结果消息

【补充】preview 与实际勾选路径对齐
- 原本 preview 如果只按根目录做，会和用户当前树上勾选的不一致
- 后续补成：
  - 前端 preview 传 `paths`
  - 后端 preview 路由读取 `paths / paths[]`
- 这样 preview 展示的是“本次实际打算迁移的那批文件”的 mapping 和冲突

【进展】前端实现：API 封装
- 在 `frontend/src/api/sandbox.js` 中新增：
  - `previewMigration`
  - `migrateFiles`
- 路由前缀与当前 spec 一致，走 `/sandbox/conversations/...`

【进展】前端实现：ChatWindow 入口
- 在 `frontend/src/components/ChatWindow/index.vue` 的“更多”菜单中新增：
  - `迁移文件`
- 点击后向上抛出 `open-migration`

【进展】前端实现：新增 FileMigrationDialog
- 新增组件：
  - `frontend/src/components/FileMigrationDialog/index.vue`
- 当前最小闭环功能包括：
  - 选择目标会话
  - 展示 `/workspace/agents` 文件树
  - 勾选目录/文件
  - preview 自动 mapping 与冲突
  - overwrite 开关
  - execute 执行迁移
  - 成功后跳转到目标会话

【进展】前端实现：Dashboard 接线
- 在 `frontend/src/views/Dashboard.vue` 中：
  - 挂载 `FileMigrationDialog`
  - 接收 `ChatWindow` 的 `open-migration`
  - 迁移成功后刷新 conversation 列表
  - 支持直接切换到目标会话

【验证】后端 Python 语法检查
- 使用：
  - `python -m py_compile conversation_service.py routes.py manager.py`
- 结果：通过

【限制】本轮尚未完成完整前端构建或联调
- 当前完成了代码级接线和后端语法检查
- 但没有继续跑：
  - Vue 构建
  - 浏览器联调
  - 真容器迁移验收

## 4. 当前收敛结果

本轮结束时，已经形成以下实际代码结果：

- 后端已有跨会话迁移 preview / execute API
- 后端已有 owner 校验和 `conversation -> sandbox session` 解析
- 后端已有自动 mapping、冲突检测、尽力模式和空目录跳过逻辑
- 后端已有迁移完成后的系统结果消息写入
- 前端已有“迁移文件”菜单入口
- 前端已有 `FileMigrationDialog` 最小操作闭环
- 前端已有 preview / execute API 调用和成功后切换目标会话的处理

从“文档阶段”往“真实实现阶段”已经完成了第一轮推进，不再只是 spec 层面的讨论。

## 5. Debug / 验证记录

| # | 验证项 | 结果 | 关键日志 / 备注 |
|---|--------|:---:|----------------|
| 1 | `conversation_service.py` 语法检查 | ✅ | `python -m py_compile` 通过 |
| 2 | `sandbox/api/routes.py` 语法检查 | ✅ | `python -m py_compile` 通过 |
| 3 | `sandbox/host/manager.py` 语法检查 | ✅ | `python -m py_compile` 通过 |
| 4 | 前端关键接线搜索 | ✅ | `previewMigration / migrateFiles / open-migration / FileMigrationDialog` 均能搜到 |
| 5 | Preview 支持实际勾选路径 | ✅ | preview API 与前端已都补 `paths` |
| 6 | 前端构建验证 | ❌ | 本轮未执行 |
| 7 | 真容器跨会话迁移联调 | ❌ | 本轮未执行 |

## 6. 未解决问题 / 后续建议

- 需要继续做一次前端构建验证
  - 重点确认 `FileMigrationDialog` 在当前 Vue 2 + Element UI 环境中无模板语法问题

- 需要继续做一次真实联调
  - 至少覆盖：
    - 选中文件 preview
    - overwrite=false 冲突
    - overwrite=true 覆盖
    - 空目录跳过
    - 迁移后目标会话系统消息出现

- 需要进一步确认低价值目录过滤策略是否过严
  - 例如 `node_modules` 是否应永久排除，还是只作为前端默认不展示项

- 当前前端仍坚持“默认不自动全选”
  - 这和 `9.2` 的建议不同
  - 后续若真实使用表明绝大多数用户都是“整目录搬迁”，可以再把默认交互切到“全选后取消”

- 当前 preview 没有把 mapping 类型单独作为字段返回
  - 现在前端是通过目标路径是否包含 `/migrated_from_` 来推断 fallback
  - 若后续要增强显示，可让后端显式返回 mapping meta

## 7. 可沉淀结果

- 是否值得升级为 Archive：是
- 可升级为 Spec：已直接落实到 `spec/9 v1.2`
- 可升级为 Skill：否
- 可升级为 Rules：是
  - 可沉淀规则包括：
    - “管理类用户操作不要误接入 runtime event bridge”
    - “preview / execute 两段式交互优先于先写后解释”
    - “跨会话复制默认先限制在 `/workspace/agents` 范围”
