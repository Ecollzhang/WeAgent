# Session - web 统一工作台 diff 与消息卡片 UI 收口

版本：v1.15  
日期：2026-06-06  
负责人：zby

## 1. 本轮记录范围

本轮围绕 `combineartifact_editing_system(base_v1.08)` 的 web 端统一工作台与消息卡片，集中收口以下问题：

1. 消息卡片顶部文件信息、类型标签、文件大小、操作按钮的布局重排
2. 文件附属 diff 的展示方式从双列/冗余头部收口为轻量模式
3. 非代码文件不再在聊天区内直接展示 diff，只允许在工作台中查看
4. 工作台内同一批文件之间的 diff 切换、侧栏开关与拖拽能力补齐
5. 顶栏增加 `打开 Diff` 与 `选择导出`，并对齐 desktop 统一工作台的能力
6. 编辑模式与 diff 侧栏的交互收口
7. 修复 web 前端若干编译与模板错误

主要涉及文件：

- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/components/MessageBubble/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/components/DiffViewCard/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/components/ArtifactWorkbench/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/api/sandbox.js`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/vue.config.js`

## 2. 本轮背景与初始判断

本轮工作承接前一轮 `diff附属未收口` 的继续推进。前序已经基本确认：

- `DiffViewCard` 本体可用
- workbench 侧的 diff 展示链路基本存在
- 真正未收口的是“聊天卡片如何挂载 diff”和“统一工作台如何在同批文件间自然切换 diff”

用户在本轮进一步提出了更明确的交互目标：

1. 顶部文件卡片要保持单行观感，但内部是 `左 / 中 / 右` 信息结构  
   左侧是文件信息，中间是类型标签与大小，右侧是操作
2. diff 的聊天区展示必须弱化，只保留真正必要的操作
3. 工作台不能只在“从外面点开某个文件”时才有 diff，进入后应能在同批文件内继续看其它文件的 diff
4. 工作台中的 diff 侧栏应该能手动打开、关闭、拖拽调整宽度
5. 非代码文件的 diff 不应在聊天框中展开，而应统一引导到工作台查看

初始判断是：这不是单个组件 bug，而是消息卡片、DiffViewCard、ArtifactWorkbench 三者之间的数据传递与 UI 层级没有统一。

## 3. 讨论与实现过程

### 3.1 收口消息卡片顶部布局

这一轮最先收的是文件卡片顶部布局。用户对布局要求经历了几次澄清：

- 不是简单左右布局
- 也不是整体两行卡片
- 而是整体保持单行观感，内部按 `左 / 中 / 右` 排布
- 左侧文件信息块内部允许文件名与路径上下排，且文件名明显大于路径
- 中间偏左放置 `代码/图片/网页` 等标签与文件大小
- 右侧保留 `复制 / 编辑`

基于这一判断，`MessageBubble` 中的文件卡片结构被重排为：

- 左：展开箭头、图标、文件名、路径
- 中：类型标签、文件大小
- 右：复制、编辑

中间属性块后续又继续向左收紧，并通过真实间距而不是视觉估计去控制与左侧主信息块的距离。

### 3.2 将聊天区 diff 收口为“附属信息”

用户明确不希望聊天区 diff 继续使用完整卡片式样，而是希望：

- 顶部文件卡片仍然是主体
- diff 只作为其附属状态与入口
- 聊天区不再承载太重的 diff 结构

因此 `DiffViewCard` 增加了 `compact` 模式，在消息卡片附属 diff 中：

- 去掉原有冗余 header / toolbar
- 去掉双列对照感过强的结构
- 收成单列最终稿模式
- 仅保留单列行号与最终文本内容

随后又进一步收口为：

- 只有代码文件的 diff 允许在聊天区提供 `展示Diff / 撤销`
- 非代码文件即便有关联 diff，也不在聊天区展开
- 在原位置仅显示“详情请在工作台查看”

### 3.3 统一按钮样式与间距

用户对右上角操作按钮和 diff 摘要行按钮提出两点意见：

1. 样式应统一，避免四个控件像来自两套系统
2. `复制 / 编辑`、`展示Diff / 撤销` 两组按钮间距过近

因此 `MessageBubble` 中相关按钮被统一为一套轻量文字/胶囊风格，并同步拉开组内间距，保证顶部操作和 diff 摘要行操作有一致的层级与节奏。

### 3.4 处理文件清单中的重复索引列

用户反馈某些“文件清单”表格会出现重复的索引列，一列是“序号”，一列是 `#`。

问题判断为：

- summary/table 渲染逻辑会自动补一列索引
- 原始 markdown 表格本身又带了 `#` 或 `序号`

最终处理为两层：

- 如果原始表头已经包含索引列，则不再自动补
- 如果前两列实质上是重复索引列，则在渲染前去掉一列

### 3.5 补文件大小兜底

用户发现部分文件卡片不显示大小，例如通过消息文本路径补识别出来的文件。

判断原因：

- 某些文件元素不是直接来自 `file_write` 事件
- 只是前端从文本里识别出的路径引用
- 这类元素天然缺少 `size`

因此前端增加了兜底逻辑：

- 如果卡片本身没有文件大小
- 则按路径补拉一次 metadata
- 再将 size 回填到对应 artifact 卡片

### 3.6 让工作台支持同批文件内切换 diff

用户指出一个更关键的问题：

- 当前只有“从聊天框点开某个带 diff 的文件”时，工作台才会显示右侧 diff 侧栏
- 进入工作台后，无法继续查看同一批文件中的其它 diff

这一点最终定位为数据传递问题，而不是单纯 UI 开关缺失。

修复思路：

1. `MessageBubble` 在打开工作台时，不只传入口文件的 `diffElement`
2. 同时将同批文件的 `diffMap` 一并传入
3. `ArtifactWorkbench` 根据当前选中文件路径，从 `diffMap` 中解析对应 diff

这样之后，在工作台中点击左侧其它已修改文件时，右侧 diff 侧栏可以跟随切换，而不再只认入口文件。

### 3.7 增加工作台 diff 开关、拖拽与修改标记

围绕工作台 diff 侧栏，本轮继续收口了三个能力：

1. 顶栏增加 `打开 Diff / 关闭 Diff`
2. 右侧 diff 面板支持拖拽调宽
3. 左侧文件树中，带 diff 的文件名后显示黄色 `M`

这使得 diff 在工作台内从“偶发附带显示”转成了“显式可控的侧栏能力”。

### 3.8 将 desktop 的“选择导出”移植到 web

用户要求对齐 desktop 统一工作台中的“选择导出”能力，并明确给出了目标按钮顺序：

`上级目录 -> 打开 Diff -> 下载 -> 导出 ZIP -> 选择导出 -> 其余不变`

本轮处理包括：

- 参照 desktop 工作台的交互，在 web 端顶栏增加 `选择导出`
- 增加可勾选的导出树弹层
- 前端将所选路径以 `selected_paths` 传给导出接口
- `sandbox.js` 扩展 `getSessionZipExportUrl(...)`，支持 selected paths 参数

完成后，web 端已经具备与 desktop 基本一致的“选择导出”入口能力。

### 3.9 约束编辑态与 diff 的关系

用户要求：点击 `编辑` 后，默认关闭 diff，除非用户再次手动点开。

因此工作台行为被收口为：

- 点击 `编辑` 时，自动执行 `showDiffPanel = false`
- 进入编辑后不再默认占用右侧 diff 空间
- 只有用户再次点击 `打开 Diff` 时，才重新展开

这使“编辑”与“审阅 diff”这两类模式不再同时挤占主视图。

### 3.10 修复前端构建与模板问题

本轮过程中还穿插修复了两类前端报错。

第一类是 `index.html` 冲突：

- `HtmlWebpackPlugin` 生成 `index.html`
- `CopyPlugin` 又复制 `public/index.html`
- 最终触发 `Multiple assets emit different content to the same filename index.html`

处理为在 `vue.config.js` 中显式固定 html 模板，并让 copy 明确忽略 `index.html`。

第二类是 `ArtifactWorkbench` 模板编译错误：

- `npm run build` 能过
- `npm run serve` 在 template compiler 阶段报最外层 `<div>` 无闭合

最终定位不是整体结构错，而是若干提示文案在上次改动中把 `</div>` 吃坏了，导致开发编译器一路将 `awb-layout / awb-body / awb-main` 判为未闭合。修复坏标签后，`serve` 与 `build` 均恢复正常。

## 4. 当前收敛结果

截至本轮结束，web 端已经明确收敛的结果包括：

- 消息卡片顶部布局已经收口为 `左 / 中 / 右`
- 文件名与路径层级更清楚，类型标签与大小独立为中间属性块
- 聊天区 diff 仅对代码文件提供 `展示Diff / 撤销`
- 非代码文件不再在聊天区直接展开 diff，而是提示去工作台查看
- `DiffViewCard` 的聊天区附属模式已收成更轻量的单列最终稿模式
- 工作台可以在同批文件间切换查看 diff
- 工作台顶栏已经具备 `打开 Diff` 与 `选择导出`
- 编辑模式默认关闭 diff 侧栏
- 左侧文件树会用黄色 `M` 标记被修改文件
- `index.html` 冲突已解决
- `ArtifactWorkbench` 的模板编译问题已解决

## 5. Debug / 验证记录

| # | 验证项 | 结果 | 备注 |
|---|--------|:---:|------|
| 1 | `npm run build` | 通过 | web 前端多次改动后可稳定构建 |
| 2 | `npm run serve` | 通过 | 修复 `ArtifactWorkbench` 坏标签后恢复正常 |
| 3 | 消息卡片文件头布局 | 通过 | 已按 `左 / 中 / 右` 收口 |
| 4 | 仅代码文件显示聊天区 diff 操作 | 通过 | 非代码文件改为“详情请在工作台查看” |
| 5 | 工作台 diff 侧栏拖拽 | 通过 | 可手动调整宽度 |
| 6 | 工作台同批文件切换 diff | 通过 | 依赖 `diffMap` 传递 |
| 7 | 顶栏 `选择导出` | 通过 | 已接入 selected paths 导出 |
| 8 | 点击编辑默认关闭 diff | 通过 | 需用户手动重新打开 |
| 9 | 文件清单重复索引列 | 通过 | 已补去重逻辑 |
| 10 | 缺失文件大小回填 | 通过 | 前端已加 metadata 兜底 |

## 6. 未解决问题 / 后续建议

- 当前虽然已能在工作台中切换同批文件 diff，但顶栏按钮的视觉统一性仍可能继续细抠
- `ArtifactWorkbench` 与 `MessageBubble` 中仍存在部分历史乱码文案，建议专门开一轮清洗
- `选择导出` 当前已可用，但如果后续需要与 desktop 完全统一，还可以继续对齐弹层样式与树节点交互
- diff 侧栏虽然已支持手动开关与拖拽，但未来可以再补“记忆上次宽度”的体验

## 7. 可沉淀结果

本轮适合继续向上沉淀的内容有：

## 8. 本轮追修（06-06 晚场）

上一轮 `diff附属未收口` 的核心问题是「diff 元素在消息卡片中始终不显示」。经前序排查已确认 DiffViewCard 本体可用、分组逻辑正确、DOM 中曾出现 diff 行，但用户始终看不到。

### 8.1 根因定位：elementKey 冲突

追查发现：`frontend/src/store/modules/message.js` 中的 `elementKey()` 函数对不同元素类型统一使用 `data.path` 作为唯一标识。diff 元素、file 元素、code 元素指向同一文件路径时，三者的 `elementKey` 完全一致。

当后端 `conversation_message_status` 事件携带完整 `elements` 数组通过 `mergeElements` 合并时：

1. `mergeElements` 先用 `elementKey` 做去重：遍历现有元素，key 相同则跳过
2. 再遍历 incoming 元素：key 相同则**替换**现有元素
3. diffEl 和 fileEl/codeEl 的 key 都是 `data.path` → 合并过程中 diffEl 被 fileEl 或 codeEl 静默覆盖
4. 最终 `message.elements` 中 diff 元素彻底丢失

**修复**（`message.js:32-51`）：检测 diff 元素（`type === 'diff'` 或携带 `diff_text`/`diff_stat`），使用 `diff::path::snippet` 作为唯一 key，不与 file/code 元素的路径 key 碰撞。

修复后验证：debug badge 从 ✕ 变为 ✓，diff 行稳定显示。

### 8.2 DiffViewCard 简化：去掉「修改后」Tab

用户要求在统一工作台内只保留 Diff 视图，去掉「修改后」预览 tab：

- 移除 radio group 切换控件
- 移除 `viewMode` data / `activeText` computed
- 移除 `<pre v-else>` 代码面板分支
- 简化 toolbar 为纯标题 + 操作按钮

涉及文件：`DiffViewCard/index.vue`

### 8.3 工作台 diff 侧边栏拖拽问题

用户反馈两点：

**拖拽粘手**：根本原因在于 HTML 预览时主区域为 `iframe`，鼠标拖拽侧栏过程中移入 iframe 区域后，`mouseup` 事件被 iframe 捕获，无法送达 `window` 监听器，导致拖动状态无法结束，必须再次点击边界才能退出。

修复：
- 拖拽开始时：在 `document` 上动态绑定 `mousemove` / `mouseup`（而非 `window`）
- 增加全屏 `.awb-resize-overlay`：拖拽时 `position: fixed; inset: 0; z-index: 1000; cursor: col-resize`，覆盖所有 iframe，确保鼠标事件始终由 overlay 捕获
- 拖拽结束时：统一移除事件监听
- `beforeDestroy` 中调用 `stopSideResize()` 确保清理

**侧栏太短**：`.awb-side` 未设置高度撑满容器，导致 DiffViewCard 显示区域过短。

修复：`.awb-side` 增加 `display: flex; flex-direction: column; align-self: stretch;`；`.awb-side-resizer` 增加 `align-self: stretch;`；DiffViewCard 内部 `.diff-lines` 设置 `flex: 1; min-height: 0; overflow: auto`。

### 8.4 文件树增加「新增文件」标记

已有 M（黄色，已修改）标签。用户要求对本轮新增的文件也标记出来。

实现：

**MessageBubble** 增加 `buildWorkbenchFileMap()`：遍历 `artifactElements`，收集 `type: 'file'` 元素的路径到 `fileMap`。payload 附带 `fileMap` 传入工作台。

**ArtifactWorkbench** `filterTree` 增加 `diffAdded` 判断：`node.type === 'file' && hasFileForPath(node.path) && !hasDiffForPath(node.path)`——有 file 元素但无 diff 的视为新增文件。

模板新增 `<span v-if="data.diffAdded" class="awb-tree-added">A</span>`，红底红字。

### 8.5 清理所有历史 Debug 日志

移除全量 `[AWB DEBUG]` 日志：

| 位置 | 移除内容 |
|---|---|
| MessageBubble/index.vue | `awbDebugSeq`、`logWorkbenchDebug`、`logDiffGroupDebug`、`logDiffRenderDebug`、`logSingleDiffRenderDebug` |
| DiffViewCard/index.vue | `logDiffCardDebug`、watcher/mounted/updated 中的 debug 调用 |

### 8.6 涉及文件

- `frontend/src/store/modules/message.js` — elementKey 修复（diff 唯一 key）
- `frontend/src/components/MessageBubble/index.vue` — buildWorkbenchFileMap、fileMap 传递、移除 debug
- `frontend/src/components/ArtifactWorkbench/index.vue` — A 标签、filterTree、resize 重写、侧栏高度
- `frontend/src/components/DiffViewCard/index.vue` — 移除「修改后」tab、移除 debug

## 9. 可沉淀结果

- 可升级为 Archive：
  - web 统一工作台 diff 查看链路收口
  - 聊天卡片附属 diff 与工作台 diff 的职责边界
  - web 端“选择导出”能力的移植与接入

- 可升级为 Rules：
  - 非代码文件的 diff 不在聊天框内展开，只允许在工作台查看
  - 编辑模式默认关闭 diff 侧栏，避免与主编辑视图竞争空间
  - 同批文件 diff 应通过路径映射统一传递给工作台，而不是只传入口文件的单个 diff 元素

- 可升级为 Spec：
  - 统一工作台顶栏按钮顺序与 diff 开关交互规则
  - 消息卡片中文件主体信息、属性信息、操作信息的布局层级定义
