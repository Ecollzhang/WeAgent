# Session - WeAgent 统一编辑平台二次收口记录

版本：v1.15  
更新日期：2026-06-04  
负责人：zby

## 1. 本轮目标

围绕 `weagent-v1.06` 中新迁入的统一编辑平台，继续收口以下问题：

- CSV / HTML / 图片 / 下载的体验缺陷
- `main` 与 `v1.06` 在 Workbench 打开速度上的差异
- 打开后右侧预览迟迟不出现
- 图片和 HTML 保存后仍然像“重新从 docker 读一遍”
- 切换过的文件再次打开仍然很慢，缺少本地缓存

本轮目标不是彻底解决所有“绝对耗时慢”，而是先把统一编辑平台从“远程文件浏览器式体验”推进到更接近 `main` 的“本地工作台式体验”。

## 2. 本轮主要结论

### 2.1 `main` 更顺，不是因为后端文件接口本质更快

对比 `main` 与 `v1.06` 后确认：

- `/files/tree`
- `/files/raw`
- `/files/download`

这三条后端基础链路在两个分支里基本同构，都是：

`browser -> host route -> host client -> container /api/files/* -> orchestrator`

因此：

- `main` 的“更顺”不能简单归因于后端接口更先进
- 差异更多来自前端打开入口、局部状态持有和保存后的本地回写

### 2.2 当前统一编辑平台的核心问题，是“每次都像第一次远程读文件”

在 `v1.06` 中，Workbench 之前更像这样：

`打开 -> 读树 -> 选文件 -> 读 raw/file -> 预览`

以及：

`编辑完成 -> 写 docker -> 再重新加载资源 -> 再显示`

这会导致几个直观问题：

- 首次打开明显慢
- 图片裁剪后不立刻显示
- HTML 保存后像重新打开了一次
- 切走再切回同一个文件仍然慢

## 3. 本轮已完成的代码收口

### 3.1 先修统一编辑平台中的直接 Bug

已修：

- CSV 不再轻易显示“暂无表格内容”
- 图片预览补了 loading
- HTML 预览补了 loading
- HTML 文本清空后编辑控件不再立刻消失
- 单文件下载路径优化为优先直取 Docker archive

### 3.2 修掉 html/image 预览 loading 死锁

曾出现的问题：

- 左侧树已经加载出来
- 右侧一直卡在“加载中”

根因：

- 为了加 loading，把 iframe/img 写成了：
  - `v-if loading -> spinner`
  - `v-else-if -> iframe/img`
- 结果 loading 为真时，真正的预览节点根本没有挂载
- 浏览器也就不会触发 `load`
- loading 永远不会结束

修正：

- 改成“先挂载 iframe/img，再叠一层 loading 覆盖层”
- 保留明确的加载提示
- 同时避免预览节点挂载死锁

### 3.3 吸收 `main` 的本地闭环：保存后先更新前端状态

这轮显式吸收了 `main` 的优点：

- Workbench 内部引入 path 级缓存
- MessageBubble 接收 Workbench 的 `saved` 事件
- 保存后先回写本地 artifact/workbench 状态，再让持久化写入跟上

当前已经补齐：

- `code/text`：保存后本地直接回显
- `html`：保存后直接用本地 blob 预览，不必重新读 raw 才看见
- `image`：裁剪后先本地显示新图，再后台写 docker
- `table/csv`：保存后本地行列状态同步更新

### 3.4 增加 Workbench 内部缓存，减少重复读取

在 `ArtifactWorkbench` 中引入了：

- `pathCache`
- `objectPreviewUrls`

缓存内容包括：

- `textContent`
- `tableHeaders`
- `tableRows`
- `imageUrl`
- `htmlPreviewUrl`

效果：

- 切换过的文件再切回来，不再默认重新从 docker 拉一遍
- HTML 可以直接走本地 blob URL 预览
- 图片可直接吃缓存/base64 结果

### 3.5 调整打开顺序：右侧优先，文件树异步补

继续对齐 `main` 的体验方向：

- `initializeWorkbench()` 不再先等树
- 优先 `selectFile(currentPath)`
- 树通过异步方式补加载

同时在 `MessageBubble -> Workbench` payload 中增加：

- HTML `previewUrl`

这样：

- 气泡里本来就能预览的 HTML
- 打开 Workbench 时右侧可以先直接吃现成预览 URL
- 不必先等树，也不必先读源码

## 4. 当前验证情况

用户已确认：

1. 图片裁剪后即时回显问题：已解决  
2. 再次打开已切换过的文件，比之前快：已改善  
3. 关闭再打开后，已保存内容能保持感知：已解决

当前仍未彻底解决：

- 首次打开仍然慢
- HTML 虽然在气泡中已有预览，但 Workbench 首开仍不够“秒开”
- 用户体感上仍存在“树优先、右侧跟不上”的现象

## 5. 当前判断

到本轮结束，可以把问题拆成两层：

### 第一层：前端体感问题

这一层已经取得实质进展：

- 本地回显
- 路径缓存
- 保存后状态回写
- 右侧优先

这些修改已经让统一编辑平台更接近 `main`。

### 第二层：首次打开的绝对耗时

这一层仍未真正量透：

- 即使右侧已经尽量利用气泡中的现成信息
- 首次打开仍然明显慢

因此下一步更像是：

- 不再继续只靠前端猜测式优化
- 而是需要对以下链路做分段 timing：
  - Workbench 打开到首个右侧可视内容
  - `/files/tree`
  - `/files/raw`
  - `/workspace/...`
  - host -> container 这一段中间链路

## 6. 对 Spec 7 的影响

本轮说明了两件事：

1. Phase 3 不能只写成“迁入 Workbench 骨架”
   - 还必须包含：
     - 保存后本地状态回写
     - html/image/table 的缓存与即时回显
     - 右侧优先、树异步补加载

2. `main` 值得吸收的不是表面组件文件本身，而是：
   - 打开入口更靠近 `MessageBubble`
   - artifact payload 更厚
   - 保存后优先更新本地状态

## 7. 下一步建议

下一阶段建议进入 Phase 3 的后半段专项联调与打点：

1. 给首次打开链路补分段 timing  
2. 验证为什么 HTML 气泡已有预览时，Workbench 首开仍不够快  
3. 继续收口 `MessageBubble -> ArtifactWorkbench` 的状态来源，尽量让右侧预览先于树出现  
4. 在 Phase 3 稳定后，再考虑进入 Phase 4 的 UI 收口
