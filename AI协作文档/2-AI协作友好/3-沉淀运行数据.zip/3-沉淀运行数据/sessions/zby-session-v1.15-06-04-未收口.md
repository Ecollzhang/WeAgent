# Session - WeAgent 产物 Workbench 打开性能排查记录

版本：v1.15  
更新时间：2026-06-04

## 1. 基本信息

- Session 名称：WeAgent 产物 Workbench 打开性能排查记录
- 日期：2026-06-04
- 对应成员：zby
- 对应任务方向：多源数据产物展示链路 / Artifact Workbench 体验优化
- 关联代码主线：
  - `3-WeAgent/weagent-v1.06/WeAgent`
  - 参考对照：`3-WeAgent/WeAgent-main/WeAgent`
- 对应 Spec：
  - [7-WeAgent双版本多源数据链路合并方案.md](/E:/华南理工/研一/第二学期%202026.3.2-/3-竞赛/1-字节全栈挑战赛/2-沉淀产物/spec/7-WeAgent双版本多源数据链路合并方案.md)
- 本次记录范围：
  - Phase 3 最小版 `ArtifactWorkbench` 接入后的打开性能排查
  - 对 `main` 与 `v1.06` 的 Workbench 打开方式做结构对比
  - 确认当前“产物首开慢”的主要瓶颈
  - 明确哪些优化已经尝试，哪些问题转入后续优化而非本轮继续推进

## 2. 本轮背景与初始判断

- 在 `v1.06` 中已经完成了最小版 `ArtifactWorkbench` 接入，并把 `code / table / image / webpage / diff` 等产物逐步汇入统一工作台。
- 用户实际体验中，点击聊天消息里的产物卡片后，Workbench 打开依然明显慢于 `WeAgent-main`。
- 初始判断曾有两个方向：
  - 方向 A：Workbench 首开慢，可能是前端组件自身挂载和渲染成本高。
  - 方向 B：Workbench 首开慢，可能是打开链路过长，或左侧文件树请求拖慢了整体体感。
- 后续排查逐步证明，单纯在前端做轻缓存和小幅预灌虽然有帮助，但和 `main` 的体感差距依然明显，说明问题不止是内容请求层面。

## 3. 讨论与推进过程

### 3.1 先做最小性能补丁，验证“是不是 Workbench 本体太重”

- 先对 `ArtifactWorkbench/index.vue` 做了三类不改变交互结构的优化：
  - 把打开顺序从“先拉树、再选中文件”改成“先选中文件、后异步拉树”
  - 把 `artifact` 的深监听改成浅比较，避免重复初始化
  - 给 tree / text / table 加前端缓存
- 这一步的目的不是彻底解决，而是验证：
  - 如果只是 Workbench 内部初始化顺序不合理，用户体感应当显著改善
- 实际反馈：
  - `png` 首开改善明显
  - 其他类型改善有限
  - 第一次慢，第二次也只是略好一点
- 因而初步结论是：
  - 轻缓存有效，但不是根因
  - 不能把问题简单归因为“前端组件写得太笨”

### 3.2 回读 `main`，确认它为什么“体感更顺”

- 对 `WeAgent-main` 中的 `ArtifactWorkbench` 与打开入口做了重新比对。
- 关键发现：
  - `main` 的 `ArtifactWorkbench` 本体并没有明显更“聪明”
    - 也会先 `loadTree`
    - 也会再 `selectFile`
    - 也仍存在深监听
  - `main` 真正重要的差异在于“打开入口更贴近消息卡片”
    - `ArtifactWorkbench` 直接挂在 `MessageBubble` 里
    - 点击 artifact card 时，由 `MessageBubble` 本地组装 `workbenchArtifact`
    - 而不是像当前 `v1.06` 一样，默认走 `MessageBubble -> ChatWindow -> Dashboard -> Workbench`
- 同时也确认了一个容易误判的点：
  - `main` 虽然会传 `imageUrl / codeContent / tableRows` 等字段给 Workbench
  - 但 Workbench 真正显式优先利用上的，明确能看到的是 `imageUrl`
  - 因此不能简单地说“main 更快是因为它用了很多预灌数据”
- 这一步的收敛结论是：
  - 差距更可能来自“打开链路和挂载位置”，而不是 Workbench 文件本体写法完全不同

### 3.3 先不搬结构，尝试“中间方案”：预灌更多产物数据

- 为了验证“打开链路太远、初始数据太瘦”是不是主因，先做了一个折中方案：
  - `MessageBubble` 在 `open-file` 时，不再只往上抛 `{ path, type }`
  - 而是把现成的产物数据一起带上：
    - `codeContent`
    - `tableHeaders`
    - `tableRows`
    - `imageUrl`
    - `diffElement`
  - `Dashboard` 保留这些信息继续传给 `ArtifactWorkbench`
  - `ArtifactWorkbench` 优先吃预灌数据
- 进一步又做了一次增强：
  - 不是“点到什么元素就只带什么元素”
  - 而是按同一路径在当前消息的 `artifactElements` 里关联兄弟元素
  - 例如：
    - 点 `file`
    - 若同路径已有 `code` 元素，则优先把 `codeContent` 带上
    - 点 `diff`
    - 若同路径已有 `code / webpage / table`，一并带上
- 这一步完成后，用户反馈仍然是：
  - 与 `main` 仍差很多
  - 第一次慢，第二次只是略好一点
- 因此判断：
  - 仅靠加厚 payload 和轻缓存，无法弥补结构层差距

### 3.4 进一步向 `main` 靠拢：把 artifact 打开逻辑移回 `MessageBubble`

- 在用户确认后，继续做结构调整：
  - 将 artifact card 的 Workbench 打开责任从 `Dashboard` 往回收
  - 现在 `code / table / image / webpage / diff / file` 这些 artifact 卡片，优先在 `MessageBubble` 本地直接打开 `ArtifactWorkbench`
  - 只有步骤列表路径、附件列表等普通文件入口，仍继续走 `Dashboard`
- 这样做的目的：
  - 尽量还原 `main` 的“离卡片更近”的打开方式
  - 避免每次点产物卡片都经过整条全局 UI 链
- 但用户实际测试后仍认为体感和 `main` 差很多。
- 由此可见：
  - 问题虽然与结构有关，但仍有其他耗时环节没有被解释清楚

### 3.5 浏览器侧加 Debug，明确首开到底慢在哪

- 为了不再盲改，给浏览器侧加入了一套 Workbench 打开 debug：
  - `MessageBubble` 侧：
    - `open-artifact`
    - 记录 `path / sourceType / payloadType / hasCodeContent / tableRows / hasImageUrl / relatedTypes`
  - `ArtifactWorkbench` 侧：
    - `initialize:start / initialize:end`
    - `tree:request / tree:loaded / tree:cache-hit`
    - `text:request / text:loaded / text:cache-hit / text:prefetched`
    - `table:request / table:loaded / table:cache-hit / table:prefetched`
- 用户打开一个 `index.html` 后，拿到的关键日志是：
  - `initialize:start`
  - `select:webpage elapsedMs: 1`
  - `tree:request`
  - `initialize:end elapsedMs: 8`
  - `tree:loaded elapsedMs: 21173`
- 这一轮日志非常关键，说明：
  - 首屏文件类型识别很快
  - Workbench 初始化本身也很快
  - 真正拖慢体感的是 **tree 请求**

### 3.6 一度怀疑 tree 接口太重，但随后被新证据推翻

- 在看到 `tree:loaded 21173ms` 后，曾怀疑：
  - `files/tree` 递归太深
  - agent 目录里文件太多
  - 目录结构扫描导致 21 秒延迟
- 但用户给出了反证：
  - `/workspace/agents/数据分析师` 目录实际很小
  - 文件数量很少
  - 没有大型工程目录
- 这使得“因为目录太大而慢”的解释站不住脚。

### 3.7 继续下钻后端 tree 实现，确认宿主路由并不重

- 顺着路由链检查了：
  - `backend/app/sandbox/api/routes.py`
  - `backend/app/sandbox/host/manager.py`
  - `backend/app/sandbox/host/client.py`
- 结论：
  - 宿主机 Flask 路由层很薄
  - `manager.get_file_tree()` 只是转发给 `session.client.list_file_tree(root)`
  - `host client` 默认会带：
    - `root`
    - `include_hidden=false`
    - `max_depth=8`
- 也就是说：
  - 宿主后端不是主要瓶颈
  - 真正执行目录树构建的是容器内 `orchestrator.list_tree()`

### 3.8 给容器内 `list_tree()` 增加 timing，最终确认 tree 也不是核心瓶颈

- 为了继续缩小范围，在容器内 `orchestrator.list_tree()` 增加了 timing 日志：
  - `resolve_ms`
  - `total_ms`
  - `dirs`
  - `files`
  - `listdir_ms`
  - `file_meta_ms`
- 用户重建容器后，最终拿到日志：

```text
2026-06-04 08:15:07 INFO [weagent.sandbox] list_tree_timing {"root":"/workspace/agents/数据分析师","real_root":"/workspace/agents/数据分析师","resolve_ms":0.1,"total_ms":0.4,"dirs":1,"files":5,"listdir_ms":0.1,"file_meta_ms":0.0,"max_depth":8,"include_hidden":false}
```

- 这条日志直接说明：
  - 容器内 tree 构建本身只要 `0.4ms`
  - 目录里只有 `1` 个目录、`5` 个文件
  - `listdir`、文件元信息都非常快
- 因而本轮可以明确排除：
  - “目录太大”
  - “容器内 list_tree 逻辑过重”
  - “tree 递归本身是 21 秒瓶颈”

### 3.9 当前收敛结论：前端 21 秒日志与容器内 0.4ms 之间存在中间层时延，但本轮不继续深挖

- 现在已经出现一个新的事实差：
  - 浏览器侧 `tree:loaded` 看起来耗时约 `21s`
  - 容器内 `list_tree_timing.total_ms` 实际只有 `0.4ms`
- 说明这 21 秒不在容器目录树构建本身。
- 更可能的环节包括：
  - 宿主到容器的 HTTP 调用链中某个阶段被阻塞
  - 浏览器侧请求到响应处理之间存在其他等待
  - 或本次观测混入了非 tree 本身的时序偏差
- 但用户在这一节点明确要求：
  - 先不继续展开这条优化线
  - 保留“自动加载树”的产品要求
  - 将该问题归入后续优化，而不是本轮继续消耗时间

## 4. 本轮结论与收敛结果

- 已经确认：
  - 仅靠前端轻缓存和预灌数据，不足以把体感拉齐到 `main`
  - 仅靠把 Workbench 挂载位置移回 `MessageBubble`，也仍不足以达到 `main` 体验
- 已经验证并排除：
  - 目录本身太大导致 tree 慢
  - 容器内 `list_tree()` 逻辑本身执行慢
- 已经确认的现象：
  - 浏览器侧 Workbench 调试日志里，`tree:loaded` 仍可能表现为非常长的时间
  - 但容器内 timing 证明 tree 构建几乎瞬时完成
- 产品方向已明确保留：
  - Workbench 左侧文件树仍然应当自动加载
  - 不采用“默认不加载树、手动点按钮再加载”的止血方案

## 5. 关键修改与排查落点

- 前端：
  - `frontend/src/components/ArtifactWorkbench/index.vue`
    - 初始化顺序调整
    - tree/text/table 缓存
    - 浏览器侧 AWB debug
  - `frontend/src/components/MessageBubble/index.vue`
    - artifact 本地打开 Workbench
    - payload 预灌
    - 兄弟元素关联
    - 浏览器侧 AWB debug
  - `frontend/src/views/Dashboard.vue`
    - Workbench payload 中继保留
- 后端：
  - `backend/app/sandbox/container/orchestrator.py`
    - `list_tree()` 增加 timing 日志
  - `backend/app/sandbox/host/client.py`
    - 确认默认 `max_depth=8`

## 6. 调试证据摘要

### 6.1 浏览器侧关键证据

- 打开 `index.html` 时：
  - `initialize:start`
  - `select:webpage elapsedMs: 1`
  - `initialize:end elapsedMs: 8`
  - `tree:loaded elapsedMs: 21173`

这说明：
- 首屏 Workbench 初始化本身并不慢
- 前端观测到的长耗时聚焦在 tree 链路上

### 6.2 容器侧关键证据

```text
list_tree_timing {
  "root": "/workspace/agents/数据分析师",
  "real_root": "/workspace/agents/数据分析师",
  "resolve_ms": 0.1,
  "total_ms": 0.4,
  "dirs": 1,
  "files": 5,
  "listdir_ms": 0.1,
  "file_meta_ms": 0.0,
  "max_depth": 8,
  "include_hidden": false
}
```

这说明：
- 容器里目录树构建不是慢点
- 当前 tree 问题的真正耗时位置不在 `orchestrator.list_tree()` 内部

## 7. 本轮未解决问题

- 仍未完全解释：
  - 为什么浏览器侧的 `tree:loaded` 会表现为极长耗时，而容器侧 `list_tree()` 仅为 `0.4ms`
- 仍未完成：
  - Workbench 打开体验与 `WeAgent-main` 完全对齐

## 8. 后续建议

- 将以下内容转入后续优化项，而不是本轮继续追：
  1. 在宿主 `host client -> container server` 链路上继续加更细粒度 timing
  2. 核查浏览器侧 `tree:loaded` 的计时边界是否包含了非 tree 本身的等待
  3. 对 `main` 与 `v1.06` 的 Workbench 打开完整调用栈做进一步结构级对齐
- 本轮阶段性建议：
  - 先不再围绕 Workbench 打开性能继续耗时
  - 保持自动加载树的产品要求不变
  - 把该问题作为后续专项优化处理

## 9. 是否建议升档

- 本轮内容适合作为 `session` 保留。
- 暂不建议单独升级为 `archive`，原因是：
  - 当前仍处于排查途中
  - 尚未形成稳定通用的性能优化规则
  - 结论更多是“排除项与边界收敛”，还不是最终方法论
