# Session - diff 作为代码文件附属项未收口

版本：v1.15
日期：2026-06-05
负责人：zby

## 1. 本轮记录范围

本轮围绕 `weagent-v1.06` 前端消息卡片中的 `diff` 呈现方式展开，重点目标不是让 `diff` 作为独立卡片显示，而是希望：

1. `diff` 作为代码文件的附属项出现
2. 文件卡片本身多出一行变更摘要
3. 摘要行显示：
   - `+ / -` 统计
   - `展示Diff`
   - `撤销`
4. 展开后再显示完整 diff 内容

核心关注文件为：

- `3-WeAgent/weagent-v1.06/WeAgent/frontend/src/components/MessageBubble/index.vue`
- `3-WeAgent/weagent-v1.06/WeAgent/frontend/src/components/DiffViewCard/index.vue`
- `3-WeAgent/weagent-v1.06/WeAgent/frontend/src/components/ArtifactWorkbench/index.vue`
- `3-WeAgent/weagent-v1.06/WeAgent/backend/app/services/workspace_diff_service.py`

## 2. 本轮背景与初始判断

在统一编辑平台和消息卡片主布局基本收口后，用户提出新的体验要求：

- `diff` 不应再作为一张平级主卡片出现
- 更应被理解为“某个代码文件的变更层”
- 文件本体仍然是主项，diff 只是附属

最初判断是：

1. 后端应该已经产出了 diff 元素
2. Workbench 侧的 diff 展示能力可以复用
3. 前端消息卡片的问题主要在于：
   - 分组优先级
   - 卡片层级
   - 展示位置

## 3. 讨论与实现过程

### 3.1 先保证 diff 能作为正式能力存在

前置完成项：

1. `ArtifactWorkbench` 允许将 `diff` 作为正式类型打开
2. `DiffViewCard` 被整体重写，去掉 merge 后的乱码和损坏模板
3. 后端 `workspace_diff_service.py` 补充：
   - `before`
   - `before_preview`

这一步的目标是先让：

- diff 能正常显示
- diff 能应用
- diff 理论上能支持“撤销”

### 3.2 调整消息卡片分组逻辑

为了让 diff 优先挂在代码文件下面，而不是变成单独主卡，前端做了以下调整：

1. `artifactGroupType(group)` 不再优先返回 `diff`
2. 优先级改为：
   - `webpage`
   - `table`
   - `image`
   - `code`
3. 只有没有这些类型时，才回退到 `diff`

预期是：

同一路径下的：

- `file`
- `code`
- `diff`

最终会组合成一个 `code` 组。

### 3.3 在代码详情下面挂附属 diff

在 `MessageBubble` 中增加了代码详情下的附属区：

- `artifact-attached-diff`
- 内部挂 `DiffViewCard`

同时提供：

- `展示Diff`
- `收起Diff`

这一步的目标是先确保：

即便文件卡片本身只展示代码，至少展开后能看到 diff。

### 3.4 尝试将 diff 摘要做成文件卡片自己的第二行

后续不满足于“展开后再看”，而是继续向用户期望靠近：

希望文件卡片本身多一行，展示：

- `变更`
- `+ / -`
- `展示Diff`
- `撤销`

为此做了多轮结构尝试：

1. 先把 diff 行挂在 `artifact-file-row` 的外层第二块
2. 再挂进 `file-info-stack` 内部
3. 再移动到 `file-main` 的直属下一行

这些尝试的共同目的，是排除：

- 横向布局吞掉第二行
- `justify-content: space-between` 影响布局
- diff 行虽然存在，但看起来不像文件卡片新增的一行

### 3.5 为定位问题增加 debug

为了避免继续只凭截图猜，前端加了多层 debug。

#### A. 分组级 debug

日志名：

- `[AWB DEBUG][MessageBubble] diff-groups`

关注字段：

- `key`
- `type`
- `path`
- `hasFile`
- `hasCode`
- `hasDiff`

这层日志多次显示过：

- `type: 'code'`
- `path: '/workspace/agents/数据分析师/hello.py'`
- `hasFile: true`
- `hasCode: true`
- `hasDiff: true`

说明：

**至少在某些时刻，diff 已经和 `hello.py` 归到同一组。**

#### B. 单组渲染级 debug

日志名：

- `[AWB DEBUG][MessageBubble] diff-render:render-check`

关注字段：

- `expanded`
- `loading`
- `hasCode`
- `hasFile`
- `hasDiff`
- `codePreviewLength`
- `diffLength`
- `diffApplied`
- `groupDom`
- `diffRowDom`

其中最关键的一次证据是：

- `diffRowDom.height: 30`
- `diffRowDom.width: 719`
- `diffRowDom.text: "+1-1展示Diff撤销"`

这说明：

**diff 状态行不是完全没进入 DOM，而是至少一度真实渲染出来了。**

#### C. `DiffViewCard` 组件级 debug

日志名：

- `[AWB DEBUG][DiffViewCard] mounted`
- `[AWB DEBUG][DiffViewCard] element-change`

关键字段：

- `fileName`
- `path`
- `diffLength`
- `parsedLines`
- `canApply`
- `isApplied`

说明：

**完整 diff 组件本身也并不是完全没跑起来。**

## 4. 中途形成过的关键判断与修正

### 4.1 一度判断只是样式不明显

由于 `diffRowDom` 已有真实高度与文本内容，一度认为问题主要是：

- 第二行视觉层级太弱
- 肉眼看起来不像“文件卡片新增一行”

为此尝试过：

1. 红框高亮
2. 粉底 debug
3. 更粗的边框与更大的 padding
4. 强化按钮颜色

但用户最终截图仍然没有出现预期中的变更行。

这说明：

**问题不能只归因于样式。**

### 4.2 一度判断只是 `group.diffElement` 不稳定

后续又怀疑：

- `group.diffElement` 在分组时并不稳定
- 模板直接依赖它不可靠

因此补了：

- `artifactGroupResolvedDiff(group)`

策略是：

1. 先用 `group.diffElement`
2. 如果没有，则按文件路径重新走 `findRelatedArtifactElements(...)`

目的：

即便分组阶段偶发没挂上 diff，也让文件卡片层能再按路径捞回来。

但补完后，用户依然反馈：

**“还是没有”。**

这说明：

**问题不只是 `group.diffElement` 是否丢失。**

### 4.3 进一步怀疑历史 diff 元素结构不统一

继续分析后，又发现前端原先对 diff 的识别过于依赖“标准结构”，默认只认：

- `type === 'diff'`
- `data.path / data.file`
- `data.diff_text / data.diff_stat`

但历史消息或 merge 后消息中的 diff，可能存在结构漂移，例如字段出现在：

- `data.data.path`
- `data.data.file`
- `data.data.diff_text`
- `data.data.diff_stat`
- `data.data.before`
- `data.data.after`

这会导致：

1. 分组时没识别成 diff
2. 按路径回捞时也失败
3. 呈现出“某些阶段日志像有，但最终用户看到又像没有”的现象

## 5. 本轮后段补上的兼容层

为了覆盖这类不统一结构，又补了几层兼容。

### 5.1 `looksLikeDiffElement(el)`

不再只认 `type === 'diff'`，而是只要元素带有以下任一特征，也视为 diff：

- `diff_text`
- `diff_stat`
- `before`
- `after`
- 以及这些字段位于 `data.data` 的情况

### 5.2 路径提取兼容

`elementWorkspacePath(el)`、`diffPath(el)` 等，不再只读：

- `data.path`
- `data.file`

同时也兼容：

- `data.data.path`
- `data.data.file`

### 5.3 文件卡片与展开区统一走解析后的 diff

文件卡片中的：

- `+ / -`
- `展示Diff`
- `撤销`

以及展开区中的 `DiffViewCard`，

都不再死盯 `group.diffElement`，而是优先走：

- `artifactGroupResolvedDiff(group)`

## 6. 当前收敛结果

即使兼容层补到这一步，用户最终仍然反馈：

**“还是没有”。**

因此到本轮结束时，能够确认的事实是：

1. `DiffViewCard` 本体已经可用
2. Workbench 对 diff 的正式支持已经基本打通
3. 前端消息卡片层已经做过多轮：
   - 分组优先级调整
   - 结构位置调整
   - DOM 级 debug
   - diff 回捞兜底
   - 历史 shape 兼容识别
4. 但 “diff 作为代码文件附属项稳定显示在消息卡片中” 这一目标，仍未收口

## 7. 本轮最重要的结论

本轮最重要的沉淀不是“已经修完”，而是：

**已经排除了大量表层猜测。**

到这一刻，后续如果还要继续推进，最值得直接追的应该是：

1. 抓当前这条消息的真实 `message.elements`
2. 逐项确认 diff 元素的最终结构
3. 确认这条消息在最终渲染阶段，diff 是否真的还存在于 `renderedElements`

也就是说，下一轮不应该再从：

- 模板布局
- 卡片样式

重新开始，而应转到：

- **真实消息数据结构**
- **消息到前端元素列表的最终映射**

## 8. 当前状态标记

这轮 diff 收口应标记为：

**已完成大量定位与兼容尝试，但未完成最终收口。**

更准确地说：

- “diff 作为独立能力” 基本已经具备
- “diff 作为代码文件附属项” 仍处于未收口状态

## 9. 一句话总结

这轮并不是“前端完全没接到 diff”，而是：

**diff 在多个中间层证据里都显示“存在过”，但没有稳定地以“代码文件附属项”的形式在消息卡片最终呈现出来。**
