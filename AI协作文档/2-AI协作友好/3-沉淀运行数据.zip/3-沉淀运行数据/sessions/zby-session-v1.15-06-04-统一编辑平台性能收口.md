# Session - WeAgent 统一编辑平台性能收口记录

版本：v1.15
日期：2026-06-04
负责人：zby

## 1. 本轮目标

围绕 `weagent-v1.06` 中统一编辑平台的“打开慢、切换慢、右侧像没出来、树稳定 21 秒”问题，完成一次从现象、对比、定位到代码收口的专项处理。

本轮重点不是继续堆前端体验补丁，而是回答两个更底层的问题：

1. 为什么 `main` 体感更顺？
2. 为什么 `v1.06` 在当前环境里会出现稳定约 21 秒的 tree/raw 访问延迟？

## 2. 过程中的关键判断变化

### 2.1 最初判断

最开始用户感受到的是：

- Workbench 首开慢
- 树出来了，右侧预览不出来
- 图片 / HTML 保存后像又重新加载一轮
- 切换回刚看过的文件也仍然慢

初看像是一个“大而混的 Workbench 性能问题”。

### 2.2 对比 `main` 后的第一轮判断

对比 `WeAgent-main` 与 `weagent-v1.06` 后，先确认了一点：

- 两个分支的 `/files/tree`、`/files/raw`、`/files/download` 原始设计基本同构
- `main` 体感更顺，主要来自前端闭环更完整：
  - `MessageBubble -> Workbench` 入口更直接
  - 保存后会先更新本地 artifact/workbench 状态
  - 更少出现“保存成功但又像重新打开了一次”的感觉

这一阶段的结论是：

- `main` 的优秀之处主要在前端闭环
- 但“21 秒级绝对耗时”未必是组件层能解释的

### 2.3 专项 timing 之后的第二轮判断

补充 perf 日志后，逐步得到如下证据：

- `initialize:preview-ready` 很快
- container 内 `orchestrator.list_tree()` 本身也很快
- browser 侧 `tree:loaded` 却稳定在约 `21s`
- `raw:loaded` 也会出现相同量级

这说明：

- 不是目录遍历本身慢
- 不是 Workbench 初始化本身慢
- 慢点更像集中在：
  - `host -> container /api/files/tree`
  - `host -> container /api/files/raw`

也就是：**host 通过容器内 HTTP 文件接口访问文件/树时，这条桥在当前环境里异常慢。**

## 3. 本轮完成的关键修复

### 3.1 Workbench 交互与本地闭环收口

已完成：

- CSV 解析与加载态修正
- 图片加载态补齐
- HTML 加载态补齐
- HTML 文本清空后编辑控制不再立刻消失
- 图片裁剪改为“先本地显示，再后台写 docker”
- HTML 保存后优先走本地预览，不再强依赖重新读 raw
- Workbench 引入 path 级缓存：
  - `textContent`
  - `tableHeaders`
  - `tableRows`
  - `imageUrl`
  - `htmlPreviewUrl`
- `MessageBubble` 接收 Workbench `saved` 事件并回写本地状态
- Workbench 打开顺序改为“右侧优先，树异步补”

### 3.2 右侧预览死锁修复

曾出现的回归问题：

- loading 为真时真正的 iframe/img 不挂载
- `load` 事件永远不触发
- 右侧永久停在“加载中”

已修正为：

- 先挂载 iframe/img
- 再叠加 loading 覆盖层

### 3.3 气泡预览与 Workbench 预览解耦

后期又确认一个问题：

- 消息气泡里的网页 iframe 还在后台继续请求 `index.html`
- Workbench 里的 iframe 也在请求
- Network 看起来像“还是很慢”
- perf 统计也容易被旧的 `load` 事件串扰

已修正为：

- 同一路径已在 Workbench 打开时，气泡网页 iframe 暂停
- Workbench 的 html/image 预览节点加独立 key
- 切文件时旧节点直接卸载，避免旧事件污染新文件

## 4. 最关键的链路级收口

### 4.1 `/files/raw` 不再优先走容器内 HTTP

将右侧文件读取改为：

- host 直接通过 Docker `get_archive()` 读取容器内目标文件
- 失败才回退旧的容器内 HTTP `/api/files/raw`

适用到：

- code/text/html/csv 原始读取
- 单文件下载
- agent workspace 原始文件读取

### 4.2 `/files/tree` 不再优先走容器内 HTTP

将文件树读取改为：

- host 直接通过 Docker `exec_run()` 在容器内执行树构建脚本
- 返回 JSON 树结果
- 失败才回退旧的容器内 HTTP `/api/files/tree`

这一刀直接把左侧树从稳定 `21s` 降到亚秒级。

## 5. 最终实测结果

在本轮末尾，用户实测得到：

- `initialize:preview-ready`：`7ms`
- `html:ready`：`137ms`
- `tree:loaded`：`522ms`
- `image:ready`：`341ms`
- `raw:loaded hello.py`：`35ms`
- `routeMs hello.py`：`22ms`

这说明统一编辑平台最核心的性能问题已经被拆掉：

1. 左侧树不再稳定 21 秒
2. HTML 预览回到百毫秒级
3. 图片预览回到几百毫秒级
4. 代码文件切换回到几十毫秒级

## 6. 本轮最终结论

这轮可以形成一个比较明确的项目结论：

> 不是“HTTP 协议天然慢”，而是“在当前 Windows + Docker Desktop + WeAgent 宿主/容器桥接环境里，host 通过容器内 HTTP 文件接口访问 tree/raw 文件时存在显著桥接时延”。

因此：

- 对高频文件树与产物预览场景，优先使用 Docker 直读更合适
- 容器内 HTTP 更适合：
  - agent 控制
  - session info
  - orchestrator API
  - 其他不属于高频文件读取的接口

## 7. 对 Phase 3 的影响

本轮结束后，可以认为：

- 统一编辑平台的核心性能痛点已基本收口
- Phase 3 在“统一 Workbench 体验”和“主要性能问题”上已经非常接近验收态

剩余更像收尾项：

- 继续做文件类型边界回归
- 更新 spec / session
- 视需要再补专项验收记录
