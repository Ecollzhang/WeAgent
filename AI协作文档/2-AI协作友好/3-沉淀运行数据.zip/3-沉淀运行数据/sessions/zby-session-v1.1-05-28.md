# Session - 环境部署、Bug修复与产物存储规划

版本 ：v1.1
更新时间：2026.5.28

## 1. 基本信息

- Session 名称：环境部署、Bug修复与产物存储规划
- 日期：2026-05-28
- 参与人类成员：zby（张博阳）
- 参与 AI 角色：AI 协作助手
- 对应负责人：zby
- 对应任务方向：前端数据展示 / 产物存储优化
- 本次记录范围：项目环境部署、Docker镜像构建配置、后端Bug修复、AI协作归档规范建立、产物存储优化方向讨论

## 2. 本轮背景与初始判断

- 张博阳刚接手项目，需要先跑通开发环境
- 项目基于 Flask + Vue2 + Docker 沙箱，需要配置 MySQL、Redis、Docker Desktop
- 之前项目在 main 分支上已有部分代码，但存在一些 bug

## 3. 讨论过程

- 【进展】确认项目结构：3-weagent/WeAgent-main/WeAgent 为主项目目录
- 【进展】创建 opencode.json 和 PROJECT_STRUCTURE.md，用于 AI 协作和项目地图
- 【进展】阅读 5.25 会议纪要，明确张博阳的任务：数据流设计 + 前端 UI 开发
- 【问题】构建 Docker 镜像时拉取 python:3.11-slim 极慢
  - 【解决】添加 Docker registry-mirrors（daocloud、nju 镜像源）
- 【问题】前端 axios 拦截器 `config is not defined` 导致页面报错
  - 【解决】修复 axios.js 错误处理中的 config 引用
- 【问题】沙箱容器 orchestrator 中 `_role_boundary_prompt` 被错误声明为 @staticmethod 却使用了 self
  - 【解决】移除 @staticmethod 装饰器
- 【问题】模型配置不兼容 — Claude Code CLI 只认 Anthropic 协议
  - 【解决】确定使用 DeepSeek 的 Anthropic 兼容 API：https://api.deepseek.com/anthropic
  - 【解决】Settings 页面增加「自定义模型名称」输入字段，支持任意模型名
- 【问题】切换到 feature/multi-agent-and-artifact-v1 分支
  - 【确认】新分支新增了 agent_run、user_model_config 表，sandbox 系统大幅重构
  - 【确认】requirements.txt 新增 docker SDK 依赖
  - 【确认】后端 __init__.py 已有自动迁移逻辑，重启即可建表
- 【收敛】明确后续工作方向：Agent 产物的存储优化（从沙箱 tool_results 提取到 artifacts 表）

## 4. 当前收敛结果

- 项目环境已跑通：后端 Flask 可启动，前端 Vue 可访问，Docker 沙箱镜像已构建
- 模型配置使用 DeepSeek Anthropic 兼容 API，Agent 对话正常
- 所有已知 bug 已修复
- 已切换到 feature/multi-agent-and-artifact-v1 分支，代码已是最新版

## 5. 未解决问题 / 后续建议

- `_mark_agent_message_done_if_active` 中 tool_results 未被利用，需改造以创建 Artifact 记录
- Docker 镜像构建依赖网络环境，后续建议将镜像推送到私有仓库避免重复构建
- WSL2 内存占用较大（VmmemWSL），建议配置 .wslconfig 限制内存

## 6. 可沉淀结果

- 是否值得升级为 `Archive`：是，环境部署过程对后续成员有参考价值
- 可升级为 `Spec`：否
- 可升级为 `Skill`：否
- 可升级为 `Rules`：是 — Docker 构建前需检查 registry-mirrors 配置
