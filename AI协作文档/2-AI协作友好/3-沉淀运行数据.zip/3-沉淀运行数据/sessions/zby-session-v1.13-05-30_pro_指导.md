# Session — 前端产物编辑系统 Phase 1-2 调试与修复

版本 ：v1.13_pro
更新时间：2026.5.29

## 1. 基本信息

- Session 名称：前端产物编辑系统 Phase 1-2 调试与修复
- 日期：2026-05-29
- 参与人类成员：zby（张博阳）
- 参与 AI 角色：AI 协作助手
- 对应负责人：zby
- 对应任务方向：产物前端编辑增强（表格编辑、CSV 解析、写回 API 修复）
- 本次记录范围：Phase 1-2 代码实现后的联调测试、Bug 定位与修复、Docker 镜像重建

## 2. 本轮背景与初始判断

- Phase 1（写回 API）和 Phase 2（表格编辑）已由 AI 编码完成
- 需要在实际运行环境中验证功能
- 前端 dev server 编译成功，运行在 localhost:8080
- 初始判断：后端需要重启以加载新代码，Agent 提示词更新需重建 Docker 镜像

## 3. 讨论过程

### 【Bug 1】前端保存表格报 404 "agent not found for workspace"

- 【定位】`saveTable` 生成的 fallback path 为 `/workspace/agents/default/table_xxx.csv`，但真实 workspace 不是 `default`
- 【分析】`_resolve_agent_id_by_workspace` 匹配失败，因为 `session.agents_config` 在容器恢复时可能为空
- 【修复】在 `routes.py` 中将 `return jsonify({"error": "agent not found"}), 404` 改为 `agent_id = "unknown"`（写入操作不需要 agent_id）

### 【Bug 2】Agent 只上报 file (CSV) 不上报 table

- 【定位】Agent 提示词中 "上报 table 后，必须用 Bash 写入 CSV" 让 Agent 理解为 CSV file 就是 table 载体
- 【第一次修复】改提示词为"两步缺一不可"，要求先 table 后 file
- 【验证】重建 Docker 镜像后仍不生效——Agent 仍只报 file
- 【第二次修复】在后端 `sandbox_event_bridge.py` 新增 `_try_generate_table_from_csv`：检测到 CSV file 元素时，自动从容器读取内容、解析为 table 元素
- 【迭代】Agent 提示词简化为只要求报 CSV file，table 由后端自动生成

### 【Bug 3】CSV 解析数据错位

- 【定位】`_try_generate_table_from_csv` 使用 `split(",")` 解析 CSV，无法正确处理引号包裹的逗号（如 `"Smith, John",30`）
- 【修复】改用 Python 标准库 `csv.reader` + `io.StringIO` 替代手动 split

### 【Bug 4】写回路径错误（副本问题）

- 【定位】`saveTable` 在 `el.data.path` 为空时生成随机路径 `/workspace/agents/default/table_xxx.csv`，写回的是副本而非原文件
- 【修复】当 `el.data.path` 为空时直接报错"无法保存"，不再创建副本
- 【补充】`_try_generate_table_from_csv` 生成 table 元素时确保 `data.path` 正确指向原 CSV 文件

### 【Bug 5】Flash 编辑导致缩进破坏

- 【定位】`sandbox_event_bridge.py` 中 `if element:` 行多了 4 个空格，导致 Python 语法错、整个文件无法 import、沙箱蓝图不注册
- 【修复】修正缩进到正确层级

### 【讨论】Docker 镜像重建

- 需要重建镜像使 `agent.py` 提示词修改在容器内生效
- 使用 `python -c "from app.sandbox import build_image; build_image()"`
- 注意需用 venv 中的 Python，需确保 Flask 依赖正确

### 【讨论】添加大规模 debug 日志

- zby 要求在代码中添加大量 `console.log`/`print` debug
- 建立了 debug 标签规范：`[DEBUG P{N}]`
- 建立了"进入下一 Phase 前删除上一 Phase debug"的纪律
- 记录正常 debug 输出示例和异常诊断表

## 4. 当前收敛结果

- 写回 API 已可用（agent_id fallback 不阻塞写入）
- 表格编辑功能前端可操作，保存链路基本打通
- CSV→table 自动生成逻辑已就绪（`csv.reader` + 诊断日志）
- Agent 提示词已简化：只要求报 CSV file
- 前后端 debug 日志已完善
- 误操作导致的缩进 bug 已修复

## 5. 未解决问题 / 后续建议

- Agent 提示词修改需重建 Docker 镜像 + 新建会话才能生效
- `saveTable` 在 `el.data.path` 为空时的错误提示需验证
- `_try_generate_table_from_csv` 自动生成的 table 是否被前端正确渲染需验证
- 后续 Phase（代码编辑、Diff、图片裁剪）尚未开始

## 6. 可沉淀结果

- 是否值得升级为 `Archive`：是 — 记录了多个关键 Bug 的定位过程和修复方案
- 可升级为 `Spec`：否（方案已在上一轮固化）
- 可升级为 `Skill`：否
- 可升级为 `Rules`：是 — "CSV 解析必须用 csv.reader 而非 split(','); 产物路径必须从 Agent 上报的原始文件中获取，不得生成副本"
