# Session — 2-AI协作资产 Skills 合并与重写讨论

> 版本：v1.0 | 日期：2026-06-09
> 参与：zby + AI

---

## 背景

`2-AI协作资产/skills/` 中包含 12 份 skill 文件。经评审发现，多数 skill 本质上是通用流程描述，缺乏 WeAgent 项目特有的实操价值。需要合并精简，提升质量。

---

## 问题诊断

12 个 skill 分为三类：

- **项目特有的角色定义（2 个）**：Pro架构师、Flash执行者 → 保留
- **来自真实 session 的实操经验（2 个）**：Debug排查、迭代收口 → 有价值但太通用，重写为 WeAgent 专属
- **通用流程（8 个）**：分阶段协作开发、平等评议、AI平等协作、Spec评审改进循环、双AI协作归档、平等协作归档、ProFlash协作 → 合并为 1 个

---

## 合并方案

**12 → 5**

| 最终 skill | 来源 | 处理 |
|-----------|------|------|
| Pro架构师Skill | Pro架构师 | 保留 |
| Flash代码执行者Skill | Flash代码执行者 | 保留 |
| WeAgent排障Skill | Debug排查 + 迭代收口 | 重写：加入 WeAgent 四层链路排查 + 真实案例 |
| 平等协作与评议Skill | 平等评议 + AI平等协作 + Spec评审改进循环 + 双AI归档 + 平等归档 + ProFlash协作 + 分阶段协作开发 | 合并为一份 |
| 迭代收口Skill | 迭代收口 | 保留原样 |

---

## 执行结果

删除的 6 个文件：
- 分阶段协作开发Skill.md
- 平等评议Skill.md
- AI平等协作Skill.md
- Spec评审改进循环Skill.md
- 双AI协作归档Skill.md
- 平等协作归档Skill.md

保留的 6 个文件：
- Pro架构师Skill.md
- Flash代码执行者Skill.md
- Debug排查Skill.md（后续重写）
- 迭代收口Skill.md
- WeAgent排障Skill.md（新增）
- 平等协作与评议Skill.md（新增）
- skill-template.md

## 后续建议

- 淘汰的 6 个 skill 未删除，保留在 `4-沉淀运行数据/skills/` 中作为原始素材
- `2-AI协作资产/skills/` 只保留打磨后的精品
