# Session - desktop 统一工作台修 bug 与导出链路收口

版本：v1.15  
日期：2026-06-05  
负责人：zby

## 1. 本轮记录范围

本轮围绕 desktop 端统一工作台与聊天气泡产物链路做集中修 bug，重点覆盖：

1. 文件打开错误地持续显示为 HTML 内容
2. 图片产物在聊天气泡中不应内嵌预览
3. 下载与导出 ZIP 弹空白窗口 / bridge 不可用
4. 图片裁剪保存失败、canvas tainted
5. CSV 编辑只能加行，删行和改单元格失败
6. ZIP 导出混入内部文件，且需要支持“选择导出”
7. diff 在消息区的呈现方式需要向“文件附属项”方向收口

主要关联路径：

- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/clients/desktop/src/components/ArtifactWorkbench/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/clients/desktop/src/components/MessageBubble.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/clients/desktop/src/components/DiffViewCard/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/clients/desktop/electron/main.cjs`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/clients/desktop/electron/preload.cjs`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/backend/app/sandbox/api/routes.py`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/backend/app/sandbox/host/manager.py`

## 2. 本轮背景与初始判断

用户从 desktop 统一工作台主链路出发，连续反馈了一组真实交互问题。初始判断是这些问题并不是单点 bug，而是同一条“消息气泡产物 -> 工作台 -> sandbox 文件接口 -> Electron 下载”链路上多个环节的耦合问题。

起始时的几个关键判断：

- 文件打开总显示 HTML，不一定是后端读错，更可能是前端预览状态没有正确切换
- 下载弹空白窗，本质是 browser 式下载逻辑还残留在 Electron 桌面端
- 图片裁剪保存失败，典型风险点是跨源图片导致 canvas 污染
- CSV 编辑异常，大概率是表格编辑态字段映射和 CSV 解析/转义逻辑不一致
- ZIP 导出内容异常，不只是前端按钮问题，后端导出策略本身也需要加过滤

## 3. 讨论与实现过程

### 3.1 修正文件打开总停留在 HTML 预览的问题

先定位到工作台在 `initialArtifact / initialPath` 变化时，非 diff 文件存在只更新路径、不重新按类型加载的问题。结果是：

- 上一次如果停在 HTML iframe
- 下一次再点 png/csv/pdf
- UI 仍可能继续显示旧的 HTML 内容

修正思路：

- 工作台路径变化后统一重新执行 `previewFile`
- 图片 / PDF 改成 session raw file 的受权读取
- HTML 仍走 workspace file 路由

这一轮修完后，png/csv/pdf/代码文件都能按类型重新加载。

### 3.2 去掉聊天气泡里的图片内嵌预览

用户明确要求图片不要在消息气泡中直接预览，而应退回为普通文件卡片。于是 desktop 端对 `image` 元素不再走独立图片块，而是和 `file` 卡片共用一套展示：

- 保留文件名、路径、大小
- 点击仍进入工作台
- 工作台内部仍保留图片查看和裁剪能力

### 3.3 改造下载链路为 Electron 原生保存

原逻辑通过 `window.open(..., "_blank")` 触发下载，在 desktop 环境会造成：

- 弹出多余空白窗口
- 不能自然选择保存目录

改造内容：

- `electron/main.cjs` 增加 `weagent-download:save` IPC
- `preload.cjs` 暴露 `window.weagentDesktopDownload.save`
- 前端下载 / ZIP 导出改为调用该 bridge
- 主进程通过 token 带鉴权访问后端，再弹系统“另存为”

后续又补了一层回退：

- 若 bridge 未挂载或当前窗口还运行旧 preload
- 则回退到 renderer 侧抓 blob 下载

### 3.4 修正图片裁剪保存失败

出现过两类问题：

1. `Desktop download bridge is unavailable`
2. `Failed to execute 'toBlob' on 'HTMLCanvasElement': Tainted canvases may not be exported`

第一类归到下载桥接问题。  
第二类定位为图片来源跨源，导致裁剪画布被污染。

处理方式：

- 图片预览改为先带 token 抓取 blob，再转 object URL
- `ImageCropper` 读取的是同源 blob URL，不再直接拿跨源地址
- 裁剪保存后直接通过 `writeFile` 写回 data URL
- 保存完成后重新加载当前文件，而不是只更新内存态 `previewUrl`

### 3.5 重做 CSV 编辑链路

CSV 最初表现为：

- 只能加行
- 删行、改单元格失败
- 编辑列弹出来但内容为空

原因不是单一处，而是三件事叠加：

1. 编辑态列绑定和行对象字段不一致
2. CSV 解析只按简单 `split(',')`，不支持引号和换行规则
3. 保存回写时没有统一做转义

本轮修正：

- 统一编辑态字段为 `col_0 / col_1 / ...`
- 表格列渲染改为 `el-input v-model="scope.row['col_' + index]"`
- 增加删行按钮
- 重写 CSV 解析器，兼容引号转义
- 保存时按标准 CSV 规则对逗号、双引号、换行做转义

### 3.6 收口 ZIP 导出默认内容

用户实际导出后发现 ZIP 中混入了大量不希望对外暴露的内部文件，例如：

- `agent.md`
- `config.json`
- `meta.json`
- `sandbox.log`
- `settings.local.json`
- `latest.txt`
- `previous.txt`
- UUID 命名的 `.jsonl`

后端在 `manager.py` 中补了默认过滤，导出时会排除：

- 隐藏文件
- `CLAUDE.md`
- 上述内部元数据 / 日志 / 配置文件
- UUID 命名的 `.jsonl`

### 3.7 增加“选择导出”

除了默认过滤，用户还希望：

- 只导出自己勾选的文件
- 并保留它们所在的文件夹层级

本轮落地为：

- 前端工作台增加“选择导出”入口
- 弹出可勾选文件树
- 选中文件或文件夹后，前端把 `selected_path` 传给后端
- 后端仅打包所选路径，并保留当前目录结构

中途出现过一个目录判定 bug：

- 保存位置选择无误
- 但后端报 `Selected export requires a directory path`

最终定位为 Docker `get_archive()` 的 `stat.mode` 对目录判定不稳定，于是改成：

- 同时看 `stat.mode`
- 再结合 tar 成员结构推断当前导出根是否是目录

重启后端后，这条链路恢复正常。

### 3.8 收口导出树展示

后续又补了一个小收口：

- `CLAUDE.md` 不应该出现在“选择导出”的文件树里

因此前端导出面板改为使用过滤后的 `exportTreeData`，只对导出树隐藏 `CLAUDE.md`，左侧普通文件树不受影响。

### 3.9 diff 呈现方式进入“附属项”方案讨论

最后一段讨论集中在消息气泡内的 diff 展示形态：

现状是：

- `diff` 仍作为独立卡片
- `file` / `image` 也是独立文件卡片

用户期望改成：

- `hello_world.py` 仍是主文件卡片
- `+1 -1 / 展开 / 撤销` 作为该文件卡片中的下一行
- 默认不直接显示完整 diff
- 点“展开”再看细节

在这一轮中已经完成对现状链路的确认：

- `MessageBubble.vue` 里 `file` 和 `diff` 目前还是分开渲染
- `DiffViewCard` 已具备完整 diff 展示与“应用修改”能力
- 后端 `workspace_diff_service.py` 已经有 `before / before_preview / after / after_preview`

也就是说，做成“文件卡片附属 diff 行”在数据层是可行的，剩下主要是前端分组与渲染改造。

## 4. 当前收敛结果

截至本轮结束，已经明确收敛的结果有：

- desktop 工作台文件类型预览链路恢复正常
- 图片不再在聊天气泡中内嵌预览
- 下载与 ZIP 导出不再走空白窗口
- 图片裁剪保存恢复正常
- CSV 编辑链路恢复正常
- 默认 ZIP 导出已过滤内部文件
- “选择导出”链路可用，且支持目录层级保留
- `CLAUDE.md` 已从导出选择树中隐藏

尚未真正收口完成的点：

- diff 仍未完全改成“文件卡片附属行”
- 相关 UI 交互仍停留在设计与链路确认阶段

## 5. Debug / 验证记录

| # | 验证项 | 结果 | 关键日志 / 备注 |
|---|--------|:---:|----------------|
| 1 | desktop `npm run build` | 通过 | 多次在工作台组件重写后重新编译验证 |
| 2 | Electron 下载 bridge | 通过 | 需在旧窗口场景下兼容 fallback |
| 3 | 图片裁剪保存 | 通过 | 通过 blob URL 规避 tainted canvas |
| 4 | CSV 编辑与回写 | 通过 | 字段映射和 CSV 转义逻辑重写后恢复 |
| 5 | ZIP 默认导出过滤 | 通过 | 重启后端后生效 |
| 6 | 选择导出 | 通过 | 目录判定 bug 修正后恢复 |
| 7 | `CLAUDE.md` 从导出树隐藏 | 通过 | 仅影响导出树，不影响普通文件树 |
| 8 | diff 作为文件附属行 | 未完成 | 进入设计与实现前置确认阶段 |

## 6. 未解决问题 / 后续建议

- 将消息气泡中的 `diff` 与 `file` 按路径聚合，避免 diff 独立出卡
- 把 diff 摘要行做成文件卡片内的第二行，默认只显示：
  - `+ / -`
  - `展开`
  - `撤销`
- `展开` 后再嵌入完整 `DiffViewCard`
- `撤销` 优先直接复用后端已提供的 `before` 内容回写，不再单独推导
- 工作台与消息卡片中残留的部分乱码文案需要再统一清理

## 7. 可沉淀结果

本轮适合继续向上沉淀的内容：

- 可升级为 Archive：
  - desktop 统一工作台修 bug 收口链路
  - Electron 原生下载桥接方案
  - ZIP 默认过滤与选择导出策略
- 可升级为 Rules：
  - desktop 端禁止继续使用 `window.open(..., "_blank")` 做下载
  - 图片编辑统一采用“先抓 blob 再裁剪”的同源策略
- 可升级为 Spec：
  - diff 作为文件卡片附属项的消息卡片结构方案

