# Session - Artifact Workbench 第一阶段升级与代码类型扩展 版本：v1.15
更新时间：2026.06.01

## 1. 基本信息

- Session 名称：Artifact Workbench 第一阶段升级与代码类型扩展
- 日期：2026-06-01
- 协作模式：AI 协作助手 / 人类（zby）
- 对应负责人：zby
- 对应任务方向：前端产物编辑系统 / Artifact 统一工作台
- 本次记录范围：从统一工作台第一版弹窗预览器，推进到带左侧产物树的工作台骨架；同时扩展常见代码文件兼容；收口 AWB / CodeEditor / HtmlPageEditor 的样式统一
- 文件路径：`2-沉淀产物/sessions/zby-session-v1.15-06-01.md`

## 2. 本轮背景与初始判断

- 在前一轮完成 Phase 3-5 的主链后，当前系统已经具备：
  - 代码文件编辑
  - HTML 页面编辑
  - 图片裁剪
  - diff 生成与查看
- 但这些能力仍然分散在各自组件里，缺少统一工作流。
- 因此本轮目标被收敛为：先做 `Artifact Workbench` 的第一阶段，把“统一入口”推进到“统一工作区”的雏形。

## 3. 讨论与实现过程

### 3.1 工作台方向确认

- 先前已经讨论确认：
  - 聊天流应以文件卡片为主，而不是继续堆流式卡片
  - `AWB` 不应只是一个全屏预览弹窗，而应逐步成为统一产物工作区
- 本轮继续明确了结构方向：
  - 左侧：真实 Docker 产物树
  - 中间：当前文件的预览 / 编辑区
  - 右侧：diff 等附属信息

### 3.2 左侧产物树规则确认

- 用户确认了 3 条关键规则：
  1. 隐藏系统文件，如 `.weagent_history`、`.weagent_claude_session`
  2. 普通文件都显示，不可预览的文件也允许显示，但只提示“可下载”
  3. 默认展开到当前智能体目录，并提供回到上级目录的入口

### 3.3 Artifact Workbench 第一阶段升级

- 新版 `ArtifactWorkbench` 从“统一预览壳层”升级为“三栏雏形”：
  - 左侧接入真实 Docker 文件树
  - 中间按文件类型显示预览
  - 右侧保留 diff 详情
- 主要行为：
  - 初始根目录定位到当前产物所属智能体目录
  - 隐藏系统路径
  - 允许回到上级目录
  - 点击左侧文件可切换中间内容区

### 3.4 工作台中的预览与编辑策略

- 本轮实际落地的策略是：
  - 代码文件：支持在 AWB 中间区原地“预览 -> 编辑 -> 保存 -> 回预览”
  - HTML 文件：目前仍以 AWB 中预览为主，点击编辑仍走现有 HTML 编辑器链路
  - 图片文件：在 AWB 中统一预览，裁剪仍复用现有裁剪器
  - 表格文件：在 AWB 中显示完整表格视图
- 这里刻意保守，没有在同一轮里强行把 `HtmlPageEditor` 也深度嵌进 AWB，避免把已经相对稳定的 HTML 编辑链路一次性打散。

### 3.5 顶部按钮与样式收口

- AWB 顶部动作区加入并修正了：
  - 下载
  - 编辑
  - 裁剪
  - 关闭
  - 上级目录
- 期间通过 debug 确认了按钮逻辑本身是通的，问题主要出在布局压缩。
- 后续通过样式调整收口：
  - 左侧信息区允许收缩
  - 文件名省略显示
  - 右侧按钮区固定不收缩
- 同时压掉了 `el-dialog` 默认 header / body 留白，使 AWB、CodeEditor、HtmlPageEditor 的顶部更贴边。

### 3.6 CodeEditor 重写与嵌入支持

- 由于旧版 `CodeEditor` 内部混杂了较多旧文案与结构，不利于嵌入式复用，本轮直接将其重写为更干净的版本。
- 新版 `CodeEditor` 支持两种模式：
  - 弹窗模式：兼容原有调用
  - `embedded` 模式：供 AWB 中间区内嵌使用
- 同时统一了浅色系样式，使其和 AWB、HtmlPageEditor 视觉更一致。

### 3.7 常见代码文件兼容扩展

- 本轮明确提出并开始实现对更多常见代码文件的兼容，而不再局限于 `js/ts/py` 一小批类型。
- 已扩展的典型后缀包括：
  - `.java`
  - `.c/.h`
  - `.cpp/.cc/.cxx/.hpp`
  - `.cs`
  - `.go`
  - `.rs`
  - `.php`
  - `.rb`
  - `.sh/.bat/.ps1`
  - `.kt`
  - `.swift`
  - `.dart`
- 这次不是只改前端正则，而是同步扩展了：
  - 前端文件识别与编辑入口
  - CodeEditor 语言映射
  - 后端代码产物路由
  - diff 文本白名单
  - 工作区路径识别正则

## 4. 当前收敛结果

- `Artifact Workbench` 已不再只是单一全屏预览弹窗，而是具备工作区雏形：
  - 左侧真实文件树
  - 中间类型化内容区
  - 右侧 diff 区
- 代码文件已经能够在 AWB 中原地编辑。
- HTML、图片、表格也已经能统一在 AWB 里进入对应预览流。
- 常见代码文件类型识别范围已明显扩展。

## 5. 关键改动位置

- `3-WeAgent/WeAgent-main/WeAgent/frontend/src/components/ArtifactWorkbench/index.vue`
  - AWB 从统一预览壳层升级为带左侧产物树的工作区雏形

- `3-WeAgent/WeAgent-main/WeAgent/frontend/src/components/CodeEditor/index.vue`
  - 重写
  - 支持弹窗 / 嵌入双模式
  - 浅色主题统一

- `3-WeAgent/WeAgent-main/WeAgent/frontend/src/components/HtmlPageEditor/index.vue`
  - 压掉默认弹窗留白

- `3-WeAgent/WeAgent-main/WeAgent/frontend/src/components/MessageBubble/index.vue`
  - 接入新版 AWB
  - 打开文件卡片进入统一工作台
  - 向 AWB 传递下载 / 编辑 / 裁剪能力信息

- `3-WeAgent/WeAgent-main/WeAgent/backend/app/services/sandbox_event_bridge.py`
  - 常见代码后缀加入代码产物路由与语言映射

- `3-WeAgent/WeAgent-main/WeAgent/backend/app/services/workspace_diff_service.py`
  - 常见代码文件纳入文本 diff 白名单

- `3-WeAgent/WeAgent-main/WeAgent/backend/app/services/message_element_builder.py`
  - 重写清理
  - 工作区路径识别正则扩展

- `3-WeAgent/WeAgent-main/WeAgent/backend/app/services/message_service.py`
  - 工作区文件路径提取正则扩展

## 6. 验证 / 联调记录

| # | 验证项 | 结果 | 备注 |
|---|--------|:---:|------|
| 1 | AWB 能否打开 | 通过 | 文件卡片标题已进入工作台 |
| 2 | AWB 顶部按钮逻辑是否生效 | 通过 | 经 debug 确认逻辑通，后续通过样式修复显示 |
| 3 | AWB 顶部留白是否压掉 | 通过 | 已压缩 dialog 默认留白 |
| 4 | CodeEditor 是否改为浅色系 | 通过 | 与 AWB / HTML 编辑器风格更接近 |
| 5 | HtmlPageEditor 留白是否压掉 | 通过 | 已压缩 dialog 默认留白 |
| 6 | 常见代码文件白名单是否已扩展 | 通过 | 前后端同步扩展 |
| 7 | 代码文件能否在 AWB 中原地编辑 | 初步通过 | 新版骨架已接上，仍需后续继续联调 |

## 7. 未解决问题 / 后续建议

- 当前最明显的未完成项是：
  1. `HTML` 还没有像 `CodeEditor` 那样真正嵌入 AWB 中间区
  2. `svg` 预览问题需要继续观察是否完全收口
  3. `csv` 目前在 AWB 中是完整预览，但表格编辑能力还没有彻底并入工作台
- 产品层面更值得继续推进的，是把 AWB 从“雏形”进一步收成真正主工作流：
  - 代码、HTML、图片、表格都在同一中间区切换预览/编辑
  - 左侧目录切换不再跳出当前工作台
  - 顶部按钮和右侧 diff 继续统一

## 8. 可沉淀结果

- 是否值得升级为 Archive：是，涉及 Artifact Workbench 从概念落地为第一阶段真实工作区雏形
- 可升级为 Spec：是，应同步到 `6-Artifact统一工作台与部署方案.md`
- 可升级为 Rules：可考虑沉淀“文件卡片优先 + 工作台统一打开 + 左侧产物树导航”的交互规则
- 可升级为 Skill：否
