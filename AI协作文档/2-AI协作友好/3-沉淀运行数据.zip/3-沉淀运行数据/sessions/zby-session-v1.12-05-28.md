# Session — Elements Schema 重构与产物数据链条实现

版本 ：v1.12
更新时间：2026.5.28

## 1. 基本信息

- Session 名称：Elements Schema 重构与产物数据链条实现
- 日期：2026-05-28
- 参与人类成员：zby（张博阳）
- 参与 AI 角色：AI 协作助手
- 对应负责人：zby
- 对应任务方向：从代码块到后端信息数据存储与前端展示
- 本次记录范围：Elements 数据结构重构（type+role+subtype 三级分类）、后端沙箱 tool_results → Artifact 记录链路打通、前端多源产物的展示组件移植与 MessageBubble 改版、部署 API 端点创建

## 2. 本轮背景与初始判断

- 已完成上一轮（zby-session-v1.1-05-28）的环境部署和分支切换，feature/multi-agent-and-artifact-v1 分支已就绪
- 上一轮已确认核心任务：Agent 回复中的多源产物（代码、网页、Diff、文档、部署状态等）需要从沙箱 tool_results 中提取，结构化存储并展示
- 旧版项目（WeAgent/）中 zby 已完成 DiffViewCard、WebPreviewCard、DeployStatusCard、DocPreviewCard、ArtifactFullscreenPreview 等组件开发，需要移植到新版分支
- 本轮从 elements 数据结构设计讨论开始，逐步深入到完整实现

## 3. 讨论过程

### 【讨论一】产物存储方案

- 【问题】Agent 回复中产生的文件（HTML/代码/文档等）应该怎么存？存数据库还是只存路径引用？
- 【方案A】只存路径引用 — Artifact 表只存 {path, type, message_id}，内容通过 HTTP 从容器读取
- 【方案B】全量存 — 把文件内容读到 DB 里
- 【方案C】全不存 — 连 Artifact 记录都不建
- 【收敛】zby 倾向于方案 A，认为不存文件内容可以避免大文件开销和同步复杂度
- 【补充】讨论后认为"分层处理"更好：文本类文件（代码/文档/HTML）存内容到 DB，二进制文件（图片）只存路径。这样既保留了结构化数据的完整性（可用于未来 Agent 进化/训练集），又避免了二进制垃圾进 DB
- 【收敛】最终采用分层方案：.html/.css/.js/.py/.md/.txt/.json/.xml/.sql 等文本文件存 content；图片等二进制文件只存 path
- 【结论】Artifact 模型加 path 字段，同时保留 content 字段用于文本文件

### 【讨论二】Elements 数据结构设计

- 【问题】旧版 elements 平铺了 9 种类型（text/code/table/image/file/doc/webpage/diff/deploy_status），未来还会继续扩展（ppt 等），平铺枚举会失控
- 【方案】改为两级分类：type（数据结构和渲染框架）+ subtype（渲染变体）
- 【讨论】原始的 5 个 type（text/code/table/image/file）作为基础框架，新加入的 doc/webpage/diff/deploy_status 作为 subtype
- 【讨论】progress/result/error 与默认文本的区别：不只是视觉样式不同，还有结构差异（progress 有 status 字段有生命周期、error 可快速定位全部报错）。这决定了它们适合用 role 字段控制视觉效果，而非 subtype
- 【讨论】table 默认应该是可编辑的，readonly 才是特例
- 【讨论】deploy 放在 file 下不合理，因为部署是过程跟踪器而不是文件。决定新增第 6 个 type: "deploy"
- 【收敛】最终方案：
  - type: text — role: progress|result|error|doc (subtype)
  - type: code — subtype: highlight(默认)|diff
  - type: table — subtype: editable(默认)|readonly
  - type: image — subtype: preview(默认)
  - type: file — subtype: generic(默认)|webpage|code_preview|deploy_status
  - type: deploy — 新增，用于部署状态卡片

### 【讨论三】Diff 展示改版

- 【问题】旧版 DiffViewCard 只显示完整的 @@ 行级 diff，信息太长不直观
- 【需求】组长要求改成 Codex 模式：文件卡片头 + 修改纪要（一句话描述）+ Diff 统计（+102 -23）
- 【方案】两层展示：默认显示摘要信息，可展开查看完整行级 diff
- 【收敛】`code.subtype=diff` 的 data 结构包含：filename、summary、stat（additions/deletions）、after（完整代码）、diff_text（完整行级 diff）

### 【讨论四】HTML 文件树展示

- 【需求】HTML 产物应该是文件树展示：entry + 依赖文件（css/js），可以独立预览每种文件
- 【方案】file.subtype=webpage 的数据结构包含 files 数组，列出所有相关文件及其语言
- 【方案】前端渲染为双面板：左边文件树（可点击切换），右边预览区（HTML→iframe/CSS→代码高亮/JS→代码高亮）
- 【收敛】文件通过现有 `/api/sandbox/sessions/{id}/workspace/{path}` 代理加载

### 【讨论五】部署方式

- 【任务说明】明确了 4 种部署方式：预览 URL（dev server）、静态站点部署、容器化部署、源码打包下载
- 【方案】新增 type:deploy，subtype 区分 4 种部署方式。后端创建 deploy 端点和表
- 【收敛】同时移植旧版 DeployStatusCard 组件，创建最小 deploy API 后端

## 4. 执行细节

### Phase 1: message_element_builder.py 更新

**改动点：**

1. 新增常量 `HTML_EXTS`、`CODE_PREVIEW_EXTS`
2. `file_event_element()` — 根据文件扩展名返回不同的 subtype：
   - `.html/.htm` → `{type: "file", subtype: "webpage", ...}`
   - `.css/.js/.jsx/.ts/.tsx/.vue` → `{type: "file", subtype: "code_preview", ...}`
   - 图片 → `{type: "image", subtype: "preview", ...}`
   - 其他 → `{type: "file", subtype: "generic", ...}`
3. `progress_element()` — 从 `{type: "progress"}` 改为 `{type: "text", role: "progress"}`
4. `result_element()` — 从 `{type: "result"}` 改为 `{type: "text", role: "result"}`
5. 新增 `error_element()` — `{type: "text", role: "error"}`

### Phase 2: sandbox_event_bridge.py 更新

- `_append_or_replace_progress` 中的类型检查从 `item.get('type') == 'progress'` 改为兼容新旧两种格式：
  ```python
  is_progress = item.get('type') == 'progress' or (item.get('type') == 'text' and item.get('role') == 'progress')
  ```

### message_service.py 更新

- `_display_msg_summary` 中的 `has_result` 检查从 `el.get('type') in ('result', 'error')` 改为兼容新旧格式：
  ```python
  el.get('type') in ('result', 'error') or (el.get('type') == 'text' and el.get('role') in ('result', 'error'))
  ```
- `_mark_agent_message_done_if_active` 中 `has_text` 检查增加排除 role 元素：
  ```python
  el.get('type') == 'text' and not el.get('role')
  ```

### Phase 3: Artifact 模型

- `artifact.py` 新增字段：
  ```python
  path = db.Column(db.String(500), default='')
  ```
- `artifact_type` 枚举新增 `'deploy'`
- `__init__.py` 添加自动迁移：
  ```python
  ALTER TABLE artifacts ADD COLUMN path VARCHAR(500) DEFAULT NULL
  ```

### Phase 4: tool_results 利用

- `_mark_agent_message_done_if_active` 改为接受 `reply_or_result`（兼容 str 和 dict）：
  ```python
  if isinstance(reply_or_result, dict):
      reply = reply_or_result.get('reply', '')
      tool_results = reply_or_result.get('tool_results', [])
  else:
      reply = reply_or_result or ''
      tool_results = []
  ```
- 新增 `_create_artifact_from_tool()` — 遍历 tool_results 创建 Artifact 记录
- 新增 `_guess_artifact_type()` — 按扩展名映射类型
- 新增 `_read_artifact_content()` — 通过沙箱 HTTP API 读取容器内文件内容
- 修改 `_dispatch_single_agent_round` 中的 2 个调用点，传完整 result 而非 `result.get('reply', '')`

### Phase 5: 前端组件移植

从旧项目（WeAgent/frontend）复制到新版项目（WeAgent-main/WeAgent/frontend）：

| 组件 | 文件 | 行数 |
|------|------|------|
| WebPreviewCard | `components/WebPreviewCard/index.vue` | 97 行 |
| DiffViewCard | `components/DiffViewCard/index.vue` | 256 行 |
| DocPreviewCard | `components/DocPreviewCard/index.vue` | 139 行 |
| DeployStatusCard | `components/DeployStatusCard/index.vue` | 188 行 |
| ArtifactFullscreenPreview | `components/ArtifactFullscreenPreview/index.vue` | 593 行（全屏可视化编辑器）|
| deploy.js | `api/deploy.js` | 13 行 |

### Phase 6: MessageBubble 更新

**模板改动：**
- contentElements 渲染区：从 `el.type === 'progress'|'result'|'error'` 改为 `el.type === 'text' && el.role === 'progress'|'result'|'error'`，保留旧格式向后兼容
- artifactElements 渲染区：新增多个 subtype 分支：
  - `code.subtype=diff` → DiffViewCard
  - `file.subtype=webpage` → WebPreviewCard
  - `file.subtype=deploy_status` → DeployStatusCard
  - `file.subtype=code_preview` → 代码高亮卡片
  - `text.subtype=doc` → DocPreviewCard
- 新增全屏预览 dialog：ArtifactFullscreenPreview

**Script 改动：**
- 导入 5 个新组件
- 注册 components
- `contentElements` computed：过滤 `text.role` 有值的元素到正确区域
- `progressElements` computed：兼容新旧格式
- `artifactElements` computed：增加 `text.subtype=doc` 的过滤
- 新增 data: `fullscreenVisible`, `fullscreenData`
- 新增 methods: `openFullscreen()`, `hrefAsSrcdoc()`

### Phase 7: Deploy API

- 新建 `backend/app/services/deploy_service.py` — Deploy 模型 + CRUD
- 新建 `backend/app/controllers/deploy_controller.py` — 4 个端点：POST（创建）、GET（查询）、PUT（更新）、GET by conversation
- `__init__.py` 注册 blueprint `/api/deploys`，添加自动建表逻辑
- `deploys` 表结构：id, conversation_id, agent_id, deploy_type, status, progress, logs(JSON), preview_url, deploy_url, error, meta(JSON)

## 5. 当前收敛结果

- Elements Schema 从平铺枚举重构为三级分类（type + role + subtype），具有良好扩展性

**新增元素类型：**

| type | subtype | role | 渲染组件 |
|------|---------|------|---------|
| text | — | progress | 进度指示器 |
| text | — | result | 执行结果块 |
| text | — | error | 错误信息块 |
| text | doc | — | DocPreviewCard |
| code | diff | — | DiffViewCard |
| code | highlight(默认) | — | 代码高亮卡片 |
| table | editable(默认) | — | Element Table 可编辑 |
| table | readonly | — | Element Table 只读 |
| file | webpage | — | WebPreviewCard（文件树+iframe）|
| file | code_preview | — | 代码高亮卡片 |
| file | generic(默认) | — | 文件卡片 |
| file | deploy_status | — | DeployStatusCard |
| deploy | preview/static/container/download | — | DeployStatusCard |

**数据链路打通：**
```
Agent（容器内） → tool_results（文件列表）
  → _mark_agent_message_done_if_active 接收完整 result
    → _create_artifact_from_tool() 创建 Artifact 记录（文本存 content，二进制存 path）
    → Artifact 关联到 Message（msg.artifact_id）
    → elements 按新 schema 生成
      → MessageBubble 按 type+subtype 路由到对应渲染组件
```

## 6. 未解决问题 / 后续建议

- tool_results 读取容器文件内容依赖 `get_agent_file()`，传入的 agent_id 固定为 'moderator'，多 Agent 场景下需要改为正确的 agent_id
- Deploy API 目前只做了基础的 CRUD，实际的部署流程（启动服务、构建静态站点等）尚未对接
- DeployStatusCard 的轮询目前调用 deploy API，但部署状态的实际更新还没有流水线驱动
- ArtifactFullscreenPreview 的全屏可视化编辑功能依赖 postMessage 通信，需要验证在新分支的兼容性
- 前端 `openFullscreen()` 方法中 `hrefAsSrcdoc()` 目前返回空字符串，需要实现实际的 srcdoc 获取逻辑
- table 的可编辑特性目前只是 schema 层面的定义，前端 el-table 组件尚未实现实际的可编辑功能

## 7. 可沉淀结果

- 是否值得升级为 `Archive`：是 — Elements Schema 重构是本项目的核心架构决策，值得长期保留
- 可升级为 `Spec`：是 — elements 数据结构的完整规范和 type/subtype/role 映射表可以作为正式规范
- 可升级为 `Skill`：否
- 可升级为 `Rules`：是 — 新增元素类型时必须遵循 type (结构框架)+ role (视觉语义)+ subtype (渲染变体) 的三级分类原则，不得平铺枚举
