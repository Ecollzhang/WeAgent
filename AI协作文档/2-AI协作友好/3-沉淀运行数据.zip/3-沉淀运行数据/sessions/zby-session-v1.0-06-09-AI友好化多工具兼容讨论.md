# Session — AI 友好化规则多工具兼容方案讨论

> 版本：v1.0 | 日期：2026-06-09
> 参与：zby + AI

---

## 背景

`3-仓库友好化一期` 的 `.opencode/rules/` 绑定了 OpenCode 一个工具。但项目需要支持多个常见 AI 编程工具（OpenCode、Claude Code、Cursor、Trae、Codex），让评委看到「仓库对任意 AI 工具都友好」。

## 讨论过程

### 问题定义

`.opencode/` 是 OpenCode 的专属目录，Claude Code 读 `.claude/`，Cursor 读 `.cursor/`。当前方案绑定单一工具，不具有统一性。

### 方案一：符号链接

核心思路：规则内容放在 `ai-rules/`，各工具目录通过符号链接指向它。

```
ai-rules/               ← 唯一规则源
.opencode/rules → ../ai-rules
.claude/rules   → ../ai-rules
.cursor/rules   → ../ai-rules
```

结论：**放弃。** Windows 符号链接需要管理员/开发者模式，且不是所有 AI 工具都支持解析符号链接。

### 方案二：各工具独立规则文件 + 统一内容源

核心思路：规则内容放在 `ai-rules/`，各工具目录下放 README 指引 AI 去读 `ai-rules/`。

结论：**有问题。** AI 工具不会主动「读 README 再跳去另一份文件」。入口文件如果只写指引不写实际内容，AI 可能不执行。

### 关键发现：OpenCode 的 instructions 机制

查阅 OpenCode 文档后发现，`opencode.json` 支持 `instructions` 字段，可以用 glob 模式直接加载任意路径的 `.md` 文件：

```json
{
  "instructions": ["AI/rules/*.md"]
}
```

这意味 OpenCode 是唯一能**原生直接加载外部路径**的工具。其他工具（Claude Code、Cursor）需要在自己目录下放实际文件，或者靠 AI 主动 Read。

### Claude Code 的加载机制

Claude Code 的 `.claude/rules/` 目录下放 `.md` 文件会被**自动加载到上下文**。如果在里面放一个入口文件写「请阅读 AI/rules/ 下的文件」，AI 基本会执行 Read 操作。但不如 OpenCode 的 instructions 机制可靠。

### 最终方案：各工具各显神通，不搞同步

```
AI/rules/                           ← 唯一规则源
  ├── repository-overview.md
  ├── tech-stack.md
  ├── module-boundary.md
  ├── code-style.md
  └── collaboration.md
```

| 工具 | 加载方式 | 说明 |
|------|---------|------|
| OpenCode | `opencode.json` → `instructions: ["AI/rules/*.md"]` | 原生支持，最干净 |
| Claude Code | `.claude/rules/00-welcome.md` → 指引 AI 读 `AI/rules/` | 入口文件自动加载，AI Read 执行 |
| Cursor | `.cursor/rules/00-welcome.md` → 指引 AI 读 `AI/rules/` | 同上 |
| Trae | 按 Trae 机制适配 | 待确认 |
| Codex | 按 Codex 机制适配 | 待确认 |

### 关于同步的讨论

提出过「从 `AI/rules/` 同步到各工具目录」的方案，但被认为很蠢——规则改动一次要同步多处，维护成本高，容易不一致。

最终共识：**不搞同步，每份配置指向同一个源头**。规则只改 `AI/rules/` 一处，各工具的配置文件本身不随规则变化而修改。

## 收敛结果

1. ~~创建 `AI/rules/` 作为唯一规则源~~ → **根目录放 `AI/`，直接放多个规则文件**
2. ~~OpenCode 通过 `opencode.json` 的 `instructions` 直接加载~~ → 同上，instructions 加载 `AI/*.md`
3. ~~Claude Code、Cursor 等通过自动加载的入口文件指引 AI 去读 `AI/rules/`~~ → **不再做多工具适配，规则以纯 markdown 形式开放存放，任何 AI 工具都能读**
4. **放弃符号链接、同步脚本、多目录方案**
5. 不再额外适配 .opencode、.claude、.cursor 等工具专属目录

### 最终决策

```
WeAgent/
  ├── AI/                          ← AI 规则（唯一源，纯 markdown）
  │   ├── repository-overview.md
  │   ├── tech-stack.md
  │   ├── module-boundary.md
  │   ├── code-style.md
  │   └── collaboration.md
  ├── opencode.json
  │   → "instructions": ["AI/*.md"]
  └── 协作资产/                     ← 团队正式规范资产
```

核心理念：**规则本身是纯 markdown，任何 AI 工具都能读。不需要为每个工具单独适配。**

## 未解决问题

- Trae 和 Codex 的具体加载机制需要进一步确认
- 入口文件指引 AI Read 的可靠性需要通过实测验证
- `AI/rules/` 的最终位置（项目根目录 vs 其他位置）待确定

## 建议升级方向

- 本 session 可升级为 `spec/多工具AI友好化方案.md`
- 各工具配置方式稳定后，可沉淀为 `rules/ai-tool-config-rules.md`
