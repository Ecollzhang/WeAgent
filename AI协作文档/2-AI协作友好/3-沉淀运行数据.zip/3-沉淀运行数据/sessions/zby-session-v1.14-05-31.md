# Session — Phase 2.5 统一卡片生成框架 + Debug 体系建立

版本 ：v1.14
更新时间：2026.5.31

## 1. 基本信息

- Session 名称：Phase 2.5 统一卡片生成框架 + Debug 日志体系建立
- 日期：2026-05-31
- 参与人类成员：zby（张博阳）
- 参与 AI 角色：AI 协作助手
- 对应负责人：zby
- 对应任务方向：产物卡片自动生成基建、Debug 日志分级体系、编码安全
- 本次记录范围：设计统一卡片路由框架 → 重构 sandbox_event_bridge.py → 建立 [LOG] / [DEBUG P{N}] 两级日志 → 创建 debug.log 独立文件 → 两次编码损坏修复 → 卡片推送缺失定位

## 2. 本轮背景与初始判断

- Phase 1（写回 API）和 Phase 2（表格编辑）已完成联调，发现多个问题
- zby 提出"统一卡片生成框架"需求：所有从 Docker 流式过来的 file 元素，经统一入口自动路由到对应卡片生成器
- [LOG] 日志终端输出太乱，需要独立文件 + 分级机制
- 最终"让flash能看懂"是核心目标

## 3. 讨论过程

### 【讨论一】统一卡片框架设计

- 【初始】zby 希望"表格那种体验"扩展到所有产物类型
- 【纠正】代码/HTML 不适合内嵌编辑，但文件卡片+内容卡片的分层架构值得推广
- 【收敛】设计 `CARD_ROUTES` 路由表（40+ 扩展名 → 4 种卡片类型）+ `_enrich_file_element` 统一入口

### 【讨论二】Debug 日志分级

- 【问题】`print()` 散落在 Flask 终端中太乱
- 【第一次方案】推送到浏览器 Console → zby 认为不需要
- 【第二次方案】独立终端 `tail -f` → zby 认可
- 【收敛】创立两级日志：
  - `[LOG *]` 留存期（`card_log`/`write_log` → `debug.log`）
  - `[DEBUG P{N}]` 开发期（Phase 结束删除）
  - 新建 `app/utils/debug_logger.py`，通过 `_find_project_root()` 定位 LOG_DIR

### 【讨论三】编码损坏事件

- 【问题】`Set-Content -NoNewline` 破坏了 `sandbox_event_bridge.py` 中文注释，`git checkout` 后丢失了 Phase 2.5 全部改动
- 【教训】PowerShell 的 `Set-Content` 不要用于 Python 源码文件
- 【解决】全部通过 `edit` 工具逐块重建，确保 UTF-8 完整性
- 【第三次】恢复后又用 `Set-Content` 替换文本 → `routes.py` 中文再次损坏
- 【最终】改用 `edit` 工具单次精确匹配替换，不再使用 `Set-Content`

### 【讨论四】卡片推送缺失

- 【问题】`debug.log` 显示"generated table"但前端无显示
- 【根因1】`for c in CARD_ROUTES:` 缺少 `self.` → NameError → 方法静默失败
- 【根因2】重构时漏掉了 `_emit_element()` 推送调用，卡片只在 Python 内存中，未推送到前端

### 【调试】debug.log 实时查看

- `Get-Content .\debug.log -Wait -Tail 30` 在独立终端实时跟踪
- 通过 `__init__.py` 强制导入触发启动日志验证路径正确

## 4. 当前收敛结果

- `CARD_ROUTES` 路由表 + `_enrich_file_element` 统一入口已部署
- `_generate_table_card` 已完善（csv.reader），`_gen_code` / `_gen_webpage` / `_gen_image` 为 stub
- `debug_logger.py` 正常工作（通过 `_find_project_root` 定位）
- `debug.log` 独立文件正常写入，`card_log()` / `write_log()` 语义明确
- 两次编码损坏已修复
- `self.CARD_ROUTES` NameError 已修复

## 5. 未解决问题 / Flash 移交

- `_enrich_file_element` 缺少 `_emit_element()` 推送（Flash 需修复，见 `.opencode/flash-handoff-2026-05-31.md`）
- 需加 `conversation_id, run, agent_id` 三个参数并传入
- `file_write` 处理器中 `db.session.commit()` 时序需确认

## 6. 可沉淀结果

- 是否值得升级为 `Archive`：是 — 统一卡片框架 + 日志分级是架构级决策
- 可升级为 `Spec`：Phase 2.5 已在 spec 中
- 可升级为 `Skill`：否
- 可升级为 `Rules`：是 — "禁止用 Set-Content 修改 Python 文件"、"类变量必须加 self."
