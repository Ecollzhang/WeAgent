﻿# Session — Desktop 工作台功能补齐与 Phase 3 收口

版本：v1.1
更新时间：2026.06.06

## 1. 基本信息

- Session 名称：Desktop 工作台功能补齐与 Phase 3 收口
- 日期：2026-06-05 ~ 2026-06-06
- 协作模式：执行者（Codex）+ 人类（zby）
- 通信目录：2-沉淀产物/AI_Sync/
- 对应负责人：zby
- 对应任务方向：Desktop 统一工作台迁移方案实施 — ImageCropper 裁剪 + CSV 表格 + 编译修复
- 本次记录范围：Phase 3 收尾遗留问题修复、ImageCropper 迁移、CSV 表格渲染、多轮编译问题排查
- 文件路径：2-沉淀产物/sessions/zby-session-v1.2-06-06.md
- 上轮 Handoff：zby-session-v1.1-06-05.md（Phase 3 死代码清理完成）

## 2. 本轮背景与初始判断

上一轮已完成 Phase 3 收口（移除 Conversations.vue 中 191 行旧 workspace modal 死代码），但用户反馈存在以下工作台问题：

1. PNG 图像不可编辑（缺少裁剪功能）
2. CSV 文件未以表格形式呈现
3. 消息气泡缺乏产物预览（该需求随后被用户暂缓）

初始判断：将 Web 端 ArtifactWorkbench 中的 ImageCropper 组件和 CSV/table 渲染逻辑迁移到 Desktop 端即可解决前两个问题。当时未充分评估 Web 端组件与 Desktop 端架构的差异（currentKind vs previewType、slot-scope 语法兼容性、Role 构成差异等）。

## 3. 讨论过程

【进度】ImageCropper 组件文件复制
- 将 frontend/src/components/ImageCropper/ 复制到 desktop/src/components/ImageCropper/
- 组件本身是自包含的 595 行单文件组件，无需修改即可用

【进度】初版修复：给 desktop ArtifactWorkbench 打补丁
- 添加 ImageCropper 导入、canCrop 计算属性、enterCropMode/exitCropMode/onCropSaved 方法
- 添加 CSV 检测逻辑、parseCsv/loadTable/saveTable 方法
- 添加表格渲染模板（el-table + table编辑模式）

【错误探索】Python 语法混入问题
- 打补丁时 Python 脚本混入了 Python 语法（lambda、enumerate、dict() 等）
- 修复：用 JavaScript 语法重写方法体
- 结果：编译通过（454 modules），但文件状态不稳定

【问题】多次 patch 导致文件损坏
- 后续的 Python 补丁脚本因 PowerShell 引号转义问题，替换操作未正确执行
- 文件出现重复行、未闭合标签、行号偏移等问题
- 构建失败：vite:build-import-analysis 报 (53:28) 解析错误

【修补】尝试复制 Web 端完整 ArtifactWorkbench
- 将 frontend/src/components/ArtifactWorkbench/index.vue 覆盖 desktop 版本
- 仅修改导入路径（@/api/sandbox → @/services/sandbox）
- 编译通过（880 modules），但运行时所有文件均显示为 HTML

【困惑】"所有文件显示为 HTML" 原因排查
- Web 端使用 currentKind 进行文件类型判断，desktop 原版用 previewType
- selectFile() 方法按扩展名判断文件类型（image → csv → html → code → text → binary）
- getExt() 和正则匹配逻辑正确，理论上不会全部判为 html
- 用户使用树目录点击触发 handleNodeClick → selectFile(node.path) 应正常
- 怀疑是 hydrateFromCacheOrArtifact 从缓存恢复时错误设置了 currentKind
- 最终未确定根因即转入重写方案

【重写】基于原始 desktop 逻辑重写 ArtifactWorkbench
- 保留 previewType 文件类型判断体系（而不是 currentKind）
- 加入 ImageCropper、CSV 表格相关模板和方法
- 避免嵌套 <template slot-scope>（该语法触发 Vite import analysis 报错）

【错误探索】Babel 编译错误
- 使用 chr() 函数避免模板中的中文字符引起 PowerShell 引号问题
- 模板中混入了 Python 运算符（or、and、not），Babel parseCallExpressionArguments 报错
- 修复 or→||、and→&&、not→! 后，Babel parseParenAndDistinguishExpression 继续报错
- 提示：Vue 模板编译后的 render 函数仍存在 Babel 无法解析的表达式

【终止】用户打断修复循环，要求暂停 MessageBubble 产物渲染工作，仅聚焦工作台问题

## 4. 当前收敛结果

- ImageCropper 组件已就绪（desktop/src/components/ImageCropper/）
- CSV 表格的 parseCsv/addTableRow/saveTable 等逻辑已编写
- Canvas 裁剪模式和表格编辑模式已在模板中定义
- Electron GPU 加速问题已修复（main.cjs + disableHardwareAcceleration）
- Phase 3 dead code 清理已完成并验证
- spec 文档 Phase 3 状态已更新为"完成"

当前阻塞项：
- ArtifactWorkbench/index.vue 构建失败，@babel/parser 无法解析 Vue 模板编译后的 render 函数
- 根因推测是模板中表达式在 Vue 编译后产生的 JavaScript 不符合 Babel 预期
- 需要一份干净、无历史 Patch 残留的 ArtifactWorkbench 文件

## 5. Debug / 验证记录

| # | 验证项 | 结果 | 关键日志 / 备注 |
|---|--------|:---:|----------------|
| 1 | ImageCropper 组件复制 | ✅ | desktop/src/components/ImageCropper/index.vue 595行 |
| 2 | GPU 加速禁用 | ✅ | main.cjs: app.disableHardwareAcceleration() |
| 3 | Phase 3 死代码清理 | ✅ | Conversations.vue 1486 → 1295 行，移除191行 |
| 4 | spec 文档更新 | ✅ | §13.2/13.3 Phase 3 标记完成 |
| 5 | Web 版 AWB 替换（初版） | ⚠️ | 编译880模块，运行时"全显示为 HTML" |
| 6 | 重写版 AWB 构建 | ❌ | Babel parseParenAndDistinguishExpression 错误 |
| 7 | MessageBubble 产物渲染 | ⏸️ | 用户要求暂缓 |

## 6. 未解决问题 / 后续建议

### 关键问题
- ArtifactWorkbench/index.vue 构建失败：Babel parser 无法解析 Vue 模板编译后代码
  - 建议方案：从 2-code/ 目录中找一份已知可工作的原始 desktop ArtifactWorkbench，只增量添加 ImageCropper 和 CSV
  - 或者：直接使用 Web 端 ArtifactWorkbench 的 currentKind 体系，彻底放弃 previewType 方式

### 次要问题
- "所有文件显示为 HTML" 根因未查明
- 表格编辑模式缺少 inline input 和 delete 按钮（slot-scope 语法与 Vite 构建冲突）
- CSV 表格列的 inline editing 需要找替代方案（不用 template slot-scope）

### 后续节奏建议
- 优先保障编译通过，再验证运行时效果
- 每次修改后先 build 确认，避免多次 Patch 叠加导致文件损坏
- 对于跨端（Web → Desktop）组件迁移，尽量做完整文件替换而非增量 patch

## 7. 可沉淀结果

- 是否值得升级为 Archive：是，跨端组件迁移经验可归档
- 可升级为 Spec：否，未产生新的完整任务定义
- 可升级为 Skill：是，"Web-to-Desktop 组件迁移检查清单"可作为技能沉淀
- 可升级为 Rules：是，规则需要包括：① 迁移前确认构建工具兼容性 ② 每次修改后需 build 验证 ③ 避免 Python patch 脚本因 PowerShell 编码问题破坏文件

（EOF）
