# Archive — 前端产物编辑系统 Phase 1-2 联调 Bug 定位与修复

版本 ：v1.0_pro
更新时间：2026.5.29

## 1. 归档信息

- 归档名称：前端产物编辑 Phase 1-2 联调 — Bug 定位与修复记录
- 归档日期：2026-05-29
- 归档人：zby
- 对应 session：zby-session-v1.13-05-29_pro.md
- 对应 session 记录范围：Phase 1-2 联调测试 → 5 个 Bug 定位与修复 → Docker 重建 → 大规模 debug 日志注入

## 2. 归档原因

本次对话触发归档的原因：

- 记录了前后端联调中 5 个关键 Bug 的完整诊断—修复链路
- 明确了"后端自动生成 table 替代 Agent 手动上报"的架构决策
- 建立了 debug 日志规范和 Phase 间清理纪律
- 产出了可复用的 CSV 解析最佳实践

## 3. 对话主题

本轮对话主要主题为：

- 写回 API 404 定位与修复（agent_id fallback）
- Agent 上报 table 缺失问题的两次修复迭代
- CSV 解析数据错位的根因分析与修复
- 文件副本问题的定位与修复
- 代码合并导致缩进破坏的修复
- Debug 日志体系建立（标签规范 + 输出示例 + 异常诊断表）
- Spec 文档更新（debug 规范、Phase 调试说明）

## 4. 归档提炼

### Bug 总结

| # | Bug | 根因 | 修复 | 文件名:行号 |
|---|-----|------|------|------------|
| 1 | 404 agent not found | `saveTable` fallback 用 `default` workspace，不匹配真实名称 | `agent_id = "unknown"` fallback | routes.py:478-479 |
| 2 | 表格不显示 | Agent 只报 file 不报 table | 后端自动从 CSV 生成 table | sandbox_event_bridge.py:395-443 |
| 3 | CSV 数据错位 | `split(",")` 不支持引号逗号 | 改用 `csv.reader` | sandbox_event_bridge.py:416 |
| 4 | 文件副本 | `saveTable` path 为空时随机生成路径 | path 为空时直接报错 | index.vue:920-925 |
| 5 | CSV→table 再次失效 | 缩进错误致 `if element:` 语法错 | 修正缩进 | sandbox_event_bridge.py:158 |
| 6 | 双进程占端口 | 旧进程未杀 | taskkill 后重开 | — |

### 架构决策

1. **CSV→table 自动生成**：Agent 不需要手动上报 `type=table`，后端从 CSV 文件自动生成。数据源唯一、path 始终正确。
2. **csv.reader 强制使用**：任何 CSV 解析都必须用 Python 标准库 `csv` 模块。
3. **产物路径获取**：必须从 Agent 上报的原始 file path 中获取，不得在前端或后端生成随机路径。
4. **agent_id 非必须**：`write_workspace_file` 通过 Docker SDK 直接写入容器文件系统，不需要 agent_id。

### Debug 规范

| 标签 | 含义 | 清理时机 |
|------|------|---------|
| `[DEBUG P{N}]` | Phase N 开发 debug | 进入 Phase N+1 前删除 |

详细正常/异常输出示例见 `.opencode/plans/5-前端产物编辑系统.md` 各 Phase 末尾。

## 5. 已形成成果

- `sessions/zby-session-v1.13-05-29_pro.md` — 协作过程记录
- `.opencode/plans/5-前端产物编辑系统.md` — Spec（含 debug 规范、各 Phase 调试说明）
- `2-沉淀产物/spec/5-前端产物编辑系统-开发方案.md` — Spec 副本
- 代码修复：
  - `routes.py` — agent_id fallback + debug 日志
  - `sandbox_event_bridge.py` — `_try_generate_table_from_csv` + `csv.reader` + 诊断日志
  - `agent.py` — 提示词简化为只报 CSV file
  - `index.vue` — saveTable 拒绝无 path、debug 日志
- 本归档记录

## 6. 后续去向

- `spec/` — 开发方案已更新（debug 规范 + 各 Phase 调试说明）
- `rules/` — "CSV 解析必须用 csv.reader"、"产物路径不可生成随机副本"、"agent_id 不做阻塞检查" 可作为规则
- 仅保留在归档记录中 — Bug 诊断链路、修复迭代过程等上下文

## 7. 备注

- Agent 提示词修改需重建 Docker 镜像 + 新建会话才能生效
- `_try_generate_table_from_csv` 的正确性取决于 `get_raw_file()` 能否正确读取容器内 CSV 文件
- 后续 Phase（代码编辑、Diff、图片裁剪）尚未开始，届时需遵循相同 debug 规范
