# Archive — 新分支摸底与前端产物编辑系统架构决策

版本 ：v1.0
更新时间：2026.5.29

## 1. 归档信息

- 归档名称：前端产物编辑系统 — 架构决策与技术选型
- 归档日期：2026-05-29
- 归档人：zby
- 对应 session：zby-session-v1.13-05-29.md
- 对应 session 记录范围：阅读新分支代码 → 架构决策讨论 → 前端产物编辑系统方案设计

## 2. 归档原因

本次对话触发归档的原因：

- 确定了产物管理从"DB 存储"到"文件驱动"的架构转型方向
- 选定了前端编辑增强的技术栈：CodeMirror（代码）、cropperjs（图片）、CSV（表格）
- 产出了可直接指导实施的完整开发方案，覆盖 6 个 Phase
- 这些决策是后续前端开发的基础，需长期保留供参考

## 3. 对话主题

本轮对话主要主题为：

- `bugfix/partipant_num_and_msg_time_fix` 分支代码摸底
- 产物架构决策：文件驱动 vs DB 存储
- 前端编辑写回机制设计（写回 API）
- 代码编辑器选型（CodeMirror vs Monaco）
- HTML 低代码编辑器选型（GrapesJS 替代手写 ArtifactFullscreenPreview）
- 图片裁剪方案（cropperjs vs 原生 Canvas）
- Diff 生成方案（git / 模型记忆 / 历史文件夹 三选一）
- 表格编辑 → CSV 文件存储方案
- 完整开发方案 Spec 撰写

## 4. 归档提炼

从原始对话中提炼出的有效内容：

### 核心架构决策
1. **废弃 Artifact 表**：Docker 容器文件系统是产物内容的唯一真相源
2. **写回 API**：`PUT /api/sandbox/sessions/{sid}/files/write`，从 path 解析 agent workspace
3. **方案 B（小文本嵌入）**：text/code/table/diff 的 content 嵌入元素 JSON，图片只存 path
4. **Diff 方案 B（模型记忆）**：Agent 靠上下文生成 unified diff，宿主端不做 difflib
5. **保存即覆盖**：前端编辑后直接覆盖容器文件，Agent 后续对话看到编辑后的版本

### 技术选型
| 功能 | 选型 | 体积 | 理由 |
|------|------|------|------|
| 非 HTML 代码编辑 | CodeMirror + vue-codemirror | ~100KB gzip | 语法高亮好，比 Monaco 轻量 |
| HTML 可视化编辑 | GrapesJS | ~200KB gzip | 内置拖拽/源码/层次树/属性面板，替代手写 593 行组件 |
| 图片裁剪 | cropperjs + vue-cropperjs | ~40KB gzip | 内置拖拽/缩放/比例锁定/旋转/翻转/预览 |
| 表格保存 | CSV 格式 | — | 简单通用，Agent 直接可读写 |
| Diff 来源 | 模型记忆（方案 B）| — | 零基础设施，先验证可行性 |

> **关于 CodeMirror 重复**：GrapesJS 内联打包了自己的 CodeMirror（用于源码面板），与独立安装的 `codemirror` npm 包互不冲突。独立 CodeMirror 用于非 HTML 文件的编辑（.py/.js/.css/.md 等），两者各司其职。

### 流式产物链路（已摸清，不改动）
```
Agent → weagent-report → orchestrator.py → push_event("agent_report_element")
  → events.py (JSONL + HTTP POST) → host /api/sandbox/events
  → SandboxEventBridge → message_element_builder → message.elements
  → Socket.IO → MessageBubble 按 type 渲染
```

## 5. 已形成成果

本次归档已经形成的成果包括：

- `sessions/zby-session-v1.13-05-29.md` — 协作过程记录
- `.opencode/plans/5-前端产物编辑系统.md` — 完整开发方案 Spec（含 6 Phase、完整代码、验收标准）
- 本归档记录

## 6. 后续去向

本次归档内容后续应落入：

- `spec/` — 开发方案已产出，应复制到 `2-沉淀产物/spec/5-前端产物编辑系统-开发方案.md`
- `rules/` — "产物编辑后一律写回 Docker 文件，不经过 DB 中转" 可作为规则
- 仅保留在归档记录中 — 技术选型理由、架构讨论过程等上下文参考信息

## 7. 备注

- HTML 编辑采用 GrapesJS 低代码编辑器（~200KB），替代旧版手写的 ArtifactFullscreenPreview（593 行），交付物更稳定成熟
- Diff 方案 B 需实际测试验证 Agent 是否能可靠根据上下文生成正确 diff
- 写回 API 的 agent_id 解析逻辑需在实际开发时验证 workspace_name 与 participant_name 映射
- GrapesJS 与 Element UI 的 z-index 可能冲突，需在 init 后设置面板 appendTo
