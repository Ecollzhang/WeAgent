# 11-WeAgent云服务器部署方案（小白版）

版本 ：v1.0
更新时间：2026.06.07

## 1. 基本信息

- 名称：WeAgent 云服务器部署方案（小白版）
- 日期：2026.06.07
- 负责人：待项目成员填写

## 2. 本轮目标

本方案希望解决的问题是：

- 把当前主版本 `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/` 部署到一台云服务器上
- 让外部用户可以通过浏览器访问 Web 版 WeAgent
- 让系统的前端、后端、MySQL、Redis、Docker Sandbox 能够协同工作
- 让技术基础较弱的成员也能按步骤完成部署、排查基本问题

## 3. 范围

本轮明确包含：

- 明确当前应该部署的项目目录
- 明确服务器需要安装的软件
- 明确前端、后端、数据库、Redis、Docker 的关系
- 明确最推荐的部署架构
- 给出适合新手执行的逐步部署流程
- 给出上线后的验证方法
- 给出常见报错和排查建议

本轮明确不包含：

- Android 客户端打包与发布
- Electron 桌面端打包与分发
- Kubernetes、容器编排、自动扩缩容等复杂生产方案
- 高并发、分布式、多机房部署
- 域名备案、SSL 证书购买等平台外事务细节

## 4. 输入条件

当前已知输入包括：

- 当前主部署对象应以 `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/` 为准，而不是旧版本目录
- 后端为 Flask + Flask-SocketIO，启动入口为 `backend/run.py`
- 后端默认监听 `0.0.0.0`，端口默认为 `5002`
- 前端为 Vue 2，生产环境可执行 `npm run build` 构建静态文件
- 前端接口使用相对路径 `/api`，Socket 使用相对路径 `/socket.io`
- 后端依赖 MySQL、Redis
- 后端会调用本机 Docker，为每个正式会话动态创建沙箱容器
- Sandbox 镜像名为 `weagent-sandbox:latest`

## 5. 期望输出

本轮完成后期望产出：

- 一套能够指导小白完成部署的书面方案
- 一套推荐的服务器架构
- 一套从买服务器到上线访问的执行顺序
- 一份风险清单，避免部署时踩大坑

## 6. 验收标准

满足以下条件可认为本轮目标基本完成：

- 小组成员能够明确“该部署哪个目录”
- 小组成员能够明确“服务器上要安装哪些软件”
- 小组成员能够按步骤完成前端和后端启动
- 浏览器能够通过域名或 IP 打开页面
- `/api/health` 能返回健康状态
- 登录后，普通页面和接口可正常使用
- 已登录用户在 Settings 中配置模型后，可以正常发起 Agent 对话

## 7. 风险与限制

当前已知风险、依赖或限制：

- 本项目不是纯静态网站，不能只传前端页面就上线
- 本项目强依赖 Docker Sandbox，如果服务器无法运行 Docker，则正式 Agent 对话无法工作
- 服务器配置过低时，多个对话容器会占满内存
- 若 Nginx 没有正确代理 `/socket.io`，聊天流式输出可能异常
- 若 MySQL、Redis、后端、Nginx 任意一环未启动，系统就会部分不可用
- 若模型配置未在系统设置页填写，Agent 容器虽然能创建，但模型调用会失败

## 8. 总体结论

### 8.1 应该部署哪个目录

本项目当前最应该部署的目录是：

- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/`

原因：

- `PROJECT_STRUCTURE.md` 已把该目录定义为“当前合并版主参考目录”
- 该目录同时包含前端、后端、Sandbox、Artifact 编辑能力和多端支持代码
- 这比旧版本目录更适合作为最终展示和比赛答辩版本

### 8.2 最推荐的部署方式

对当前项目来说，最推荐的不是一上来就全 Docker Compose 化，也不是拆成很多机器，而是：

- 一台 Linux 云服务器
- 前端静态文件交给 Nginx
- 后端 Flask 服务直接跑在宿主机
- MySQL 和 Redis 跑在宿主机
- Docker Engine 跑在宿主机，供后端创建 Agent 沙箱容器

这样做的原因是：

- 结构清晰，最适合技术小白
- 便于调试问题
- 避免“容器里再操作 Docker”的复杂权限问题
- 更接近当前代码的原始设计方式

## 9. 推荐服务器配置

### 9.1 操作系统

推荐：

- Ubuntu 22.04 LTS

也可以：

- Ubuntu 24.04 LTS

不推荐新手首发就用：

- Windows Server
- CentOS 老版本
- 过度精简的容器运行环境

### 9.2 最低配置建议

最低可尝试：

- 2 核 CPU
- 4 GB 内存
- 40 GB 系统盘

更稳的建议：

- 4 核 CPU
- 8 GB 内存
- 60 GB 以上磁盘

原因：

- 后端本身不算重
- 但 Docker Sandbox 会为会话创建容器
- 每个沙箱容器代码中限制了 `1g` 内存，多个对话会吃掉很多内存

### 9.3 网络与安全组

安全组建议开放：

- `22`：SSH 远程登录
- `80`：HTTP
- `443`：HTTPS

不建议直接对公网开放：

- `5002`：后端端口
- `3306`：MySQL
- `6379`：Redis

这些内部服务最好只允许本机访问。

## 10. 部署前先理解整体结构

部署前，先把系统理解成下面这张关系图：

```text
浏览器
  ↓
Nginx
  ├─ /            -> 前端静态页面
  ├─ /api         -> Flask 后端
  ├─ /uploads     -> Flask 后端
  └─ /socket.io   -> Flask-SocketIO

Flask 后端
  ├─ 连接 MySQL
  ├─ 连接 Redis
  └─ 调用 Docker Engine
         └─ 创建会话沙箱容器 weagent-sandbox
```

如果你记不住所有细节，只记一句也够：

- Nginx 对外接流量，Flask 处理业务，MySQL 存数据，Redis 做缓存/状态，Docker 负责 Agent 沙箱

## 11. 服务器需要安装的软件

在云服务器上，需要安装以下软件：

- Git
- Python 3.10+
- Python 虚拟环境工具 `python3-venv`
- Node.js 18+ 和 npm
- MySQL 8
- Redis 7
- Docker Engine
- Nginx

可选但推荐安装：

- `curl`
- `vim` 或 `nano`
- `ufw`

## 12. 推荐目录规划

为了避免后面找不到文件，推荐服务器上采用统一目录：

```text
/srv/weagent/
├── WeAgent/          # 项目代码
├── logs/             # 日志
└── backup/           # 备份
```

推荐把项目代码放在：

- `/srv/weagent/WeAgent`

## 13. 从零开始部署的执行步骤

### 13.1 第一步：登录云服务器

在本机终端执行：

```bash
ssh root@你的服务器公网IP
```

如果你不是 root 用户，就换成自己的用户名。

### 13.2 第二步：更新系统

```bash
sudo apt update
sudo apt upgrade -y
```

这一步是为了避免系统软件太旧。

### 13.3 第三步：安装基础软件

```bash
sudo apt install -y git curl nginx redis-server mysql-server python3 python3-pip python3-venv
```

### 13.4 第四步：安装 Node.js

如果系统自带 Node 版本过低，推荐使用 NodeSource 安装 18 或 20。

示例：

```bash
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs
```

安装后检查：

```bash
node -v
npm -v
```

### 13.5 第五步：安装 Docker

最简方式可参考官方脚本或 apt 仓库方式安装。安装完成后检查：

```bash
docker version
docker info
```

如果这两条命令都能正常输出，说明 Docker 基本可用。

### 13.6 第六步：启动基础服务

```bash
sudo systemctl enable --now nginx
sudo systemctl enable --now redis-server
sudo systemctl enable --now mysql
sudo systemctl enable --now docker
```

检查状态：

```bash
sudo systemctl status nginx
sudo systemctl status redis-server
sudo systemctl status mysql
sudo systemctl status docker
```

如果看到 `active (running)`，一般表示服务已启动。

### 13.7 第七步：上传或拉取项目代码

推荐做法是：

- 先把本地仓库推到 Git 仓库平台
- 再在服务器上 `git clone`

目标目录建议：

```bash
sudo mkdir -p /srv/weagent
sudo chown -R $USER:$USER /srv/weagent
cd /srv/weagent
```

然后把代码放进来，并确保最终项目根目录是：

- `/srv/weagent/WeAgent`

注意：

- 这里的 `WeAgent` 指的是 `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/` 这一级目录内容
- 不要把整个比赛总仓库原样丢上去后又找不到真正入口

### 13.8 第八步：初始化 MySQL 数据库

先进入 MySQL：

```bash
sudo mysql
```

执行：

```sql
CREATE DATABASE weagent DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'weagent'@'localhost' IDENTIFIED BY '请替换成强密码';
GRANT ALL PRIVILEGES ON weagent.* TO 'weagent'@'localhost';
FLUSH PRIVILEGES;
EXIT;
```

然后导入表结构：

```bash
cd /srv/weagent/WeAgent
mysql -uweagent -p weagent < backend/sql/init.sql
```

### 13.9 第九步：准备后端环境

```bash
cd /srv/weagent/WeAgent/backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 13.10 第十步：配置后端环境变量

复制模板：

```bash
cp .env.example .env
```

然后编辑 `.env`，建议至少改成下面这样：

```env
FLASK_ENV=production

MYSQL_HOST=127.0.0.1
MYSQL_PORT=3306
MYSQL_USER=weagent
MYSQL_PASSWORD=这里填你刚才设置的数据库密码
MYSQL_DB=weagent

REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_DB=0
REDIS_PASSWORD=

JWT_SECRET_KEY=这里换成很长很随机的字符串
SECRET_KEY=这里也换成很长很随机的字符串

SOCKETIO_CORS_ALLOWED_ORIGINS=https://你的域名
PORT=5002
```

说明：

- `FLASK_ENV` 上线时要用 `production`
- `MYSQL_HOST` 和 `REDIS_HOST` 如果都在本机，就用 `127.0.0.1`
- `JWT_SECRET_KEY` 和 `SECRET_KEY` 不要继续用示例值
- 如果暂时没有域名，可先把 `SOCKETIO_CORS_ALLOWED_ORIGINS` 设成实际访问地址，后续再改

### 13.11 第十一步：构建 Agent 沙箱镜像

这一部非常关键，因为正式 Agent 对话依赖它：

```bash
cd /srv/weagent/WeAgent/backend
docker build -t weagent-sandbox:latest -f app/sandbox/Dockerfile app/sandbox
```

如果这一步失败，后续普通页面可能还能打开，但 Agent 聊天基本无法正常工作。

### 13.12 第十二步：手工启动后端做第一次验证

```bash
cd /srv/weagent/WeAgent/backend
source venv/bin/activate
python run.py
```

成功后，后端会监听：

- `http://0.0.0.0:5002`

这时候另开一个终端，执行：

```bash
curl http://127.0.0.1:5002/api/health
```

如果返回健康状态，说明后端基本正常。

### 13.13 第十三步：构建前端

```bash
cd /srv/weagent/WeAgent/frontend
npm install
npm run build
```

构建完成后，会生成：

- `/srv/weagent/WeAgent/frontend/dist`

这就是要交给 Nginx 的静态文件目录。

### 13.14 第十四步：配置 Nginx

推荐 Nginx 使用统一域名代理：

- `/` 给前端页面
- `/api/` 给后端
- `/uploads/` 给后端
- `/socket.io/` 给后端 WebSocket

示例配置如下：

```nginx
server {
    listen 80;
    server_name 你的域名或服务器公网IP;

    root /srv/weagent/WeAgent/frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:5002;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /uploads/ {
        proxy_pass http://127.0.0.1:5002;
        proxy_set_header Host $host;
    }

    location /socket.io/ {
        proxy_pass http://127.0.0.1:5002/socket.io/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

配置完成后：

```bash
sudo nginx -t
sudo systemctl reload nginx
```

### 13.15 第十五步：把后端做成常驻服务

手工运行只适合测试，不适合正式上线。正式部署推荐使用 `systemd`。

服务文件示例：

```ini
[Unit]
Description=WeAgent Backend
After=network.target mysql.service redis-server.service docker.service

[Service]
User=root
WorkingDirectory=/srv/weagent/WeAgent/backend
Environment="PATH=/srv/weagent/WeAgent/backend/venv/bin"
ExecStart=/srv/weagent/WeAgent/backend/venv/bin/python run.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

说明：

- 这里使用 `root` 的主要原因是当前后端需要直接调用宿主机 Docker
- 后续如果要更规范，可以再细化 Docker 权限

启用方式：

```bash
sudo systemctl daemon-reload
sudo systemctl enable weagent
sudo systemctl start weagent
sudo systemctl status weagent
```

## 14. 上线后的验证顺序

建议严格按这个顺序验证，不要一上来就测最复杂功能。

### 14.1 第一级验证：基础服务

检查：

- `nginx` 是否在运行
- `mysql` 是否在运行
- `redis-server` 是否在运行
- `docker` 是否在运行
- `weagent` 后端服务是否在运行

### 14.2 第二级验证：后端健康接口

浏览器或命令行访问：

```bash
curl http://127.0.0.1:5002/api/health
```

如果这里不通，先别测前端。

### 14.3 第三级验证：前端首页

浏览器打开：

- `http://你的域名`

如果首页打不开，优先检查 Nginx 配置和前端 `dist` 目录。

### 14.4 第四级验证：注册和登录

测试：

- 是否能打开注册页
- 是否能完成注册
- 是否能登录成功

### 14.5 第五级验证：普通接口

登录后测试：

- 会话列表是否能加载
- Agent 列表是否能加载
- 设置页是否能打开

### 14.6 第六级验证：Socket 实时通信

观察：

- 发消息时是否有实时流式效果
- 浏览器控制台是否出现 Socket 连接失败

若实时流失败，而普通接口正常，通常优先检查：

- Nginx 的 `/socket.io/` 代理
- WebSocket 升级头

### 14.7 第七级验证：正式 Agent 聊天

先在 Settings 中填写模型配置，再测试：

- 创建对话
- 发送一条简单消息
- 查看是否能收到 Agent 输出

如果这里失败，常见原因是：

- 沙箱镜像没构建成功
- Docker 服务没启动
- 模型 Key 没配置
- 外网无法访问模型服务地址

## 15. 为什么不推荐小白第一版就全容器化

虽然很多项目会直接写 Docker Compose，但对当前项目，新手第一版不建议这样做。

原因：

- 当前后端本身就要控制 Docker 沙箱
- 如果把后端再放进容器，会增加 Docker Socket 权限问题
- 会多出宿主机路径、Docker in Docker、网络桥接等额外复杂度
- 出问题后更难判断是代码错、容器错、代理错，还是权限错

因此，本方案优先追求：

- 能跑起来
- 容易排查
- 适合答辩演示

## 16. 常见问题与排查建议

### 16.1 页面能打开，但登录失败

优先检查：

- 后端是否启动
- MySQL 是否正常
- `.env` 中数据库用户名密码是否正确

### 16.2 接口能调通，但聊天没有流式输出

优先检查：

- Nginx 是否正确代理 `/socket.io/`
- 浏览器控制台是否有 WebSocket 报错
- 后端日志里是否有 Socket 相关错误

### 16.3 普通功能正常，但 Agent 对话失败

优先检查：

- `docker info` 是否正常
- `weagent-sandbox:latest` 是否存在
- Settings 页面是否填写模型配置
- 服务器能否访问对应模型服务

### 16.4 前端构建成功，但刷新页面 404

优先检查：

- Nginx `location /` 是否使用了 `try_files $uri $uri/ /index.html;`

因为 Vue 单页路由刷新时需要回退到 `index.html`。

### 16.5 后端启动时报 Redis 连接错误

优先检查：

- Redis 是否启动
- `.env` 中 `REDIS_HOST`、`REDIS_PORT` 是否正确
- Redis 是否设置了密码但 `.env` 没填

### 16.6 Docker 正常，但创建容器失败

优先检查：

- 后端运行用户是否有权限访问 Docker
- Sandbox 镜像是否已构建
- 服务器内存是否不足

## 17. 对比赛演示最重要的上线建议

如果目标是比赛演示而不是正式商业化生产，最重要的是稳定、可展示、可恢复。

建议：

- 先上单机版，不要一开始追求复杂架构
- 准备一个固定演示账号
- 提前在数据库里保留基础测试数据
- 提前在 Settings 中配置好可用模型
- 提前构建好 `weagent-sandbox:latest`
- 演示前重启一次 `nginx`、`mysql`、`redis-server`、`docker`、`weagent`
- 演示前做一次完整链路自测

## 18. 建议的执行顺序总结

如果只想记最短版本，可以记下面这 10 步：

1. 买一台 Ubuntu 云服务器
2. 安装 Python、Node、MySQL、Redis、Docker、Nginx
3. 上传 `combineartifact_editing_system(base_v1.08)/WeAgent/` 代码
4. 创建 `weagent` 数据库并导入 `backend/sql/init.sql`
5. 配置 `backend/.env`
6. 安装后端依赖
7. 构建 `weagent-sandbox:latest`
8. 构建前端 `dist`
9. 用 Nginx 代理前端和后端
10. 用 `systemd` 守护后端并做完整验证

## 19. 下一步

本轮结束后建议继续推进：

- 基于本方案补一份真正可执行的 `DEPLOY.md`
- 在项目里补充 `nginx.conf` 示例文件
- 在项目里补充 `weagent.service` 示例文件
- 如需降低新手部署难度，可后续再补一份 `docker-compose` 版本方案

