﻿# Spec: WeAgent 双版本多源数据链路合并方案
版本：v1.4
日期：2026-06-04
负责人：zby

## 1. 基本信息

- 名称：WeAgent 双版本多源数据链路合并方案
- 日期：2026-06-04
- 负责人：zby

## 2. 本轮目标

在保留 `weagent-v1.06` 当前正式聊天主链路的前提下，将 `WeAgent-main` 中已经实现的多源数据处理能力迁移合并过去，形成一条统一、可维护、可继续扩展的：

`消息 -> 文件/产物 -> 元素卡片 -> 预览/编辑/导出`

完整链路。

本轮不是简单代码覆盖，而是明确：

- 哪个版本作为主干
- 多源数据能力具体落在哪些文件
- 哪些能力必须先迁，哪些能力可以后迁
- 合并后如何验收，避免破坏 `v1.06` 现有 direct round 与正式聊天能力

## 3. 范围

本轮明确包含：

- 对 `3-WeAgent/WeAgent-main/WeAgent/` 与 `3-WeAgent/weagent-v1.06/WeAgent/` 做结构级和关键模块级比对
- 梳理多源数据链路涉及的后端、沙箱、前端组件和依赖
- 确定以 `weagent-v1.06` 为主干的合并策略
- 输出分阶段迁移方案、文件级迁移建议、风险和验收标准
- 将方案沉淀到 `2-沉淀产物/spec/`

本轮明确不包含：

- 直接执行整仓覆盖式合并
- 直接做数据库结构重构
- 对无关模块做风格性整理

## 4. 输入条件

当前已知输入包括：

- `3-WeAgent/WeAgent-main/WeAgent/`
  - 已具备较完整的多源数据增强能力：
    - 文件写回 API
    - ZIP 导出
    - workspace diff 历史快照
    - `file_write -> code/table/webpage/image/diff` 卡片增强
    - Artifact Workbench
    - CodeEditor / HtmlPageEditor / DiffViewCard / ImageCropper

- `3-WeAgent/weagent-v1.06/WeAgent/`
  - 已具备当前最新的正式聊天主链路：
    - `@Agent` mention 选择
    - `target_agent_ids` 定向派发
    - direct round
    - `raw_output + elements + meta.events` 持久化展示模型
    - 当前稳定的 `sandbox_event_bridge`

- 相关沉淀规范：
  - `2-沉淀产物/archive-schema.md`
  - `2-沉淀产物/spec/4-多模态数据流-开发方案.md`
  - `2-沉淀产物/spec/5-前端产物编辑系统-开发方案.md`
  - `2-沉淀产物/spec/6-Artifact统一工作台与部署方案.md`

## 4.1 当前推进状态（更新于 2026-06-04）

这份 spec 最初是纯计划文档。到 2026-06-04 为止，已经有以下实际推进结果，需要作为当前状态写入：

### 已完成：Phase 1

- `workspace_diff_service.py` 已迁入 `weagent-v1.06`
- 已补齐：
  - `PUT /api/sandbox/sessions/{sid}/files/write`
  - `GET /api/sandbox/sessions/{sid}/files/export-zip`
- 前端 `sandbox.js` 已补：
  - `writeFile`
  - `getSessionZipExportUrl`
- 已经通过实际联调验证：
  - `files/write`
  - `files/download`
  - `files/export-zip`

说明：
- 这一阶段已经不是“计划迁移”，而是“代码已落地并验证通过”

### 已完成：Phase 2 后端主链路

- `sandbox_event_bridge.py` 已基于 `v1.06` 增量合并完成：
  - `CARD_ROUTES`
  - `_enrich_file_element()`
  - `_build_diff_element()`
- 当前 `file_write` 后已经可以在后端生成：
  - `file`
  - `diff`
  - `code`
  - `table`
  - `webpage`
  - `image`

说明：
- 当前后端 enrich 走的是 `v1.06` 主链路，不是直接用 `main` 覆盖
- `diff` 已切换为基于真实工作区文件历史快照的方案

### 已完成：多 Agent 路径修正

已经确认并修正：

- 沙箱事件上报的文件路径经常是相对路径，例如：
  - `agents/数据分析师/hello.py`
- 当前后端已统一标准化为：
  - `/workspace/agents/数据分析师/hello.py`

并且修正策略不是写死 `数据分析师`，而是按通用结构处理：

- `agents/<workspace_name>/<rest...>`

同时元素层已经补充：

- `workspace_name`
- `agent_id`
- `agent_name`
- `agent_avatar`
- `agent_color`

说明：
- 这一步是多 Agent 场景下后续 Workbench 能正确识别文件归属的前提

### 已完成：Phase 2 前端最小过渡显示

为了先验证链路，目前前端已补最小展示而不是最终 Workbench：

- `diff` 卡片已可见
- `code` 卡片可见
- `table / image / webpage` 当前仍走气泡卡片形态作为过渡展示

说明：
- 这不是最终 UI 终态
- 当前这些卡片的作用是先证明后端 enrich 已通
- 下一步会进入 Workbench 收口阶段

### 下一步：正式进入 Phase 3

下一步的工作重点不再是继续堆更多气泡卡片，而是：

- 让 `MessageBubble` 里的文件型产物统一打开 `ArtifactWorkbench`
- 先解决：
  - 统一打开
  - 统一预览
  - 统一切换文件
- 再逐步把：
  - `code`
  - `html/webpage`
  - `table`
  - `image`
  - `diff`
  接进 Workbench 内部

### 已完成：Phase 3 第一阶段骨架迁入（按 `main` 对齐）

为了避免在 `v1.06` 中继续临时手写一套新的 Workbench 逻辑，当前已改为直接参考 `WeAgent-main` 的组织方式，把前端工作台骨架迁入 `weagent-v1.06`。

已迁入：

- `frontend/src/components/ArtifactWorkbench/index.vue`
- `frontend/src/components/CodeEditor/index.vue`
- `frontend/src/components/HtmlPageEditor/index.vue`
- `frontend/src/components/DiffViewCard/index.vue`
- `frontend/src/components/ImageCropper/index.vue`

同时已补前端依赖：

- `codemirror`
- `vue-codemirror`

当前实现特点：

- `ArtifactWorkbench` 已不再只是只读预览壳层
- 已改成与 `main` 一致的“Workbench 统一壳 + 内部挂接编辑器组件”的模式
- `code / html / table / image / diff` 已有明确的组件承载位
- 这一步优先保证结构对齐 `main`，而不是继续在旧版 Workbench 上追加零散逻辑

说明：

- 这一步完成的是“Phase 3 主体骨架迁入”
- 还不等于整个 Phase 3 已完全联调结束
- 后续仍需继续做 `MessageBubble -> Workbench` 交互收口、保存后刷新、构建验证与专项联调


### 已补充：统一编辑平台速度问题专项对比（`main` vs `v1.06`）

围绕“Workbench 打开慢、右侧预览慢、保存后像又重新加载一次”的问题，当前已经形成如下专项判断：

1. 后端基础文件链路没有本质代差
   - 两个分支的 `/files/tree`、`/files/raw`、`/files/download` 基本一致，都是 browser -> host route -> host client -> container `/api/files/*` -> `orchestrator.*`
   - 因此“绝对耗时慢”不能简单归因为 `main` 的后端更快。

2. `main` 体感更顺，主要来自前端闭环更完整
   - `main` 更早形成了 `artifact card -> local workbench -> local state update` 的闭环。
   - 保存后会优先更新本地 artifact/workbench 状态，例如：
     - `codeContent`
     - `imageUrl`
     - `_imageVersion`
     - `_htmlVersion`
   - 因此更少出现“明明已经保存，还要再打开一次才能看到新内容”的体感问题。

3. `v1.06` 在迁入 Workbench 骨架后，结构已接近 `main`，但原先仍残留旧的打开与刷新习惯
   - 打开入口和状态持有路径更绕。
   - html/image 的回显更依赖重新拉取资源。
   - 因此更容易给用户造成“又加载了一轮”的感觉。

4. 当前确认的一个具体回归：`v1.06` 新 Workbench 的 html/image 预览曾出现 loading 死锁
   - 现象：左侧文件树已经出现，但右侧预览长时间停在“加载中”。
   - 根因：补 loading 时把 iframe/img 写成了 `v-if loading -> spinner / v-else-if -> preview`。
   - 结果：当 `loading=true` 时，真正的 iframe/img 根本没有挂载，浏览器不会触发 `load` 事件，loading 永远无法结束。
   - 这个问题不是 `main` 原有问题，而是迁入后在 `v1.06` 上补体验时引入的回归。

5. 当前修正策略：吸收 `main` “先挂载预览，再覆盖状态层”的优点
   - html/image 改为始终先挂载 iframe/img
   - loading 以覆盖层形式叠加在预览区域上
   - 由 `load` 事件关闭 loading
   - 这样既保留了“正在加载中”的明确反馈，也避免了预览节点根本不挂载的死锁问题。

5.1 当前已继续推进的 Phase 3 收口项
   - `ArtifactWorkbench` 已加入 path 级缓存：
     - `textContent`
     - `tableHeaders`
     - `tableRows`
     - `imageUrl`
     - `htmlPreviewUrl`
   - `MessageBubble` 已开始接收 Workbench 的 `saved` 事件，并把保存结果回写到本地 artifact/workbench 状态
   - 图片裁剪已改为“先本地显示，再后台写 docker”
   - HTML 保存后已改为优先使用本地 blob 预览，不再强依赖重新读 raw 才可见
   - Workbench 打开顺序已开始从“先树后右侧”调整为“右侧优先，树异步补”
   - 针对 HTML 卡片，`MessageBubble -> Workbench` payload 已补充 `previewUrl`，用于首开时优先复用气泡中的现成预览
   - `MessageBubble` 中网页卡片与 Workbench 预览已做解耦：同一路径在 Workbench 打开时，气泡 iframe 暂停，避免双重请求与统计串扰
   - Workbench 的 html/image 预览节点已加独立 key，旧预览节点会在切文件时直接卸载，避免旧 `load` 事件污染新文件计时

5.2 当前新增确认：21 秒慢点的主要根因不是前端，而是 host -> container 文件 HTTP 桥

基于本轮专项联调，已经确认：

1. 原先的慢链路主要是：
   - `browser -> host route -> host client -> container /api/files/tree|raw -> orchestrator`
   - 在当前 Windows + Docker Desktop + WeAgent 宿主/容器桥接环境中，这条“host 调用容器内 HTTP 文件接口”的链路会出现稳定的约 21 秒级延迟

2. 这一延迟不是 tree 遍历本身慢：
   - container 内 `orchestrator.list_tree()` 本身很快
   - 但 browser 侧 `tree:loaded` 曾稳定在约 21 秒
   - 说明慢点主要不在目录遍历，而在 host 到 container 文件接口这一层桥接

3. 改为 Docker 直读后，性能出现数量级改善：
   - `/files/raw` 改为 host 直接通过 Docker `get_archive()` 读取文件
   - `/files/tree` 改为 host 直接通过 Docker `exec_run()` 在容器中生成树结果
   - 同时保留原容器 HTTP 方案作为 fallback

4. 当前实测结果：
   - `tree:loaded`：约 `522ms`
   - `html:ready`：约 `137ms`
   - `image:ready`：约 `341ms`
   - `raw:loaded hello.py`：约 `35ms`，其中 `routeMs` 约 `22ms`

结论：

- 不能简单说“HTTP 协议天然慢”
- 更准确的表述应是：
  - 在本项目当前运行环境中，**host 通过容器内 HTTP 文件接口访问 tree/raw 文件时存在显著桥接时延**
  - 对于高频文件树与产物预览场景，**host 直接通过 Docker SDK 读取容器文件/执行目录树枚举明显更合适**

6. 对速度问题的判断需要拆成两类
   - “体感慢”：
      - 主要来自前端闭环不完整、保存后状态未及时回写、资源刷新需要重新取
     - 这一部分应优先参考 `main` 的卡片闭环与本地状态更新方式
   - “绝对耗时慢”：
      - 本轮已经进一步收敛：高频文件 tree/raw 慢点的核心原因，是 host 调容器内 HTTP 文件接口的桥接时延
      - 因此后续对于高频文件访问，应优先采用 Docker 直读；容器内 HTTP 更适合 agent 控制、session info、工具执行等 orchestrator API

7. 对 Phase 3 的实际指导
   - 应吸收 `main` 的地方：
      - Workbench 在 `MessageBubble` 内就地打开
     - 保存后的本地 artifact 状态回写
      - code/html/image/table/diff 的统一入口闭环
      - 气泡与 Workbench 之间对同一路径预览状态的互相让位
   - 不应回退的地方：
       - 不能破坏 `v1.06` 正式聊天主链路
       - 下载链路不应回退；当前 `v1.06` 单文件下载已进一步优化为优先直取 Docker archive

8. Phase 3 的下一阶段建议
   - 当前统一编辑平台性能主问题已基本收口，下一阶段不再把重点放在“21 秒卡顿排查”本身
   - 下一阶段建议转向：
      - Phase 3 剩余稳定性与交互专项回归
      - Workbench 其他文件类型与边界场景补验
      - 文档同步与验收标准更新
   - 如后续再次出现高耗时，应优先区分：
      - 是否仍走了容器内 HTTP 文件链路
      - 是否属于气泡预览与 Workbench 预览重复请求
      - 是否只是 perf 埋点口径失真

## 5. 现状判断

### 5.1 主干选择

建议明确：

- 以 `weagent-v1.06` 为主干
- 以 `WeAgent-main` 作为多源数据增强能力来源

原因：

- `v1.06` 已集成最新的正式聊天链路和 direct round 逻辑
- `v1.06` 已支持 `target_agent_ids`
- `v1.06` 的 `ChatWindow`、`Dashboard`、`message_service` 已围绕定向派发做过收敛
- `main` 的强项不是正式聊天主链路，而是产物处理与编辑增强链路

### 5.2 必须保留的 v1.06 能力

- `frontend/src/components/ChatWindow/index.vue`
  - 已支持 mention 菜单和 `@Agent` 定向输入
- `frontend/src/views/Dashboard.vue`
  - 已支持把 `payload.target_agent_ids` 送入发送链路
- `backend/app/controllers/message_controller.py`
  - 已接收 `target_agent_ids`
- `backend/app/services/message_service.py`
  - 已包含：
    - `_normalize_target_agent_ids`
    - `_parse_mentioned_agent_ids`
    - `_dispatch_direct_agent_round`
    - `_run_direct_agent_task`

这些逻辑不应被 `main` 回退覆盖。

### 5.3 主要需要迁移的 main 能力

#### A. 后端基础能力

- `backend/app/services/workspace_diff_service.py`
- `backend/app/sandbox/host/manager.py`
  - `export_zip()`
  - `write_workspace_file()`
- `backend/app/sandbox/api/routes.py`
  - `GET /sessions/<id>/files/export-zip`
  - `PUT /sessions/<id>/files/write`

#### B. 事件增强层

- `backend/app/services/sandbox_event_bridge.py`
  - `CARD_ROUTES`
  - `_enrich_file_element()`
  - `_build_diff_element()`
  - `file_write` 后自动生成：
    - `table`
    - `code`
    - `webpage`
    - `image`
    - `diff`

#### C. 前端产物编辑与工作台

- `frontend/src/components/ArtifactWorkbench/index.vue`
- `frontend/src/components/CodeEditor/index.vue`
- `frontend/src/components/HtmlPageEditor/index.vue`
- `frontend/src/components/DiffViewCard/index.vue`
- `frontend/src/components/ImageCropper/index.vue`
- `frontend/src/api/sandbox.js`
  - `getSessionZipExportUrl`
  - `writeFile`

#### D. 前端气泡增强

- `frontend/src/components/MessageBubble/index.vue`
  - artifact 卡片聚合
  - code/html/table/image/diff 入口
  - 打开 Workbench 的统一跳转入口

### 5.4 不建议直接照搬的 main 逻辑

- `frontend/src/views/Dashboard.vue`
  - `main` 相比 `v1.06` 缺少最新 direct send 收敛，不适合覆盖
- `frontend/src/components/ChatWindow/index.vue`
  - `v1.06` 已具备 mention 功能，应保留
- `backend/app/utils/debug_logger.py`
  - 更偏临时调试资产，不适合作为合并必需项
- `sandbox_event_bridge.py`
  - 不能整文件覆盖，必须基于 `v1.06` 增量合并

## 6. 期望输出

本轮完成后期望产出：

- 一份明确的双版本合并方案
- 一份迁移顺序清单
- 一份文件级迁移建议
- 一套验收标准，覆盖：
  - 正式聊天链路不回退
  - 多源数据卡片增强生效
  - 文件编辑与导出链路打通

## 7. 推荐实施方案

### Phase 1：先补后端基础设施

目标：

- 先让 `v1.06` 获得“写回容器文件”和“导出 ZIP”的能力
- 为后续前端编辑与工作台打底

建议迁移：

- 从 `main` 迁移 `workspace_diff_service.py`
- 给 `v1.06` 的 `backend/app/sandbox/host/manager.py` 增加：
  - `export_zip()`
  - `write_workspace_file()`
- 给 `v1.06` 的 `backend/app/sandbox/api/routes.py` 增加：
  - `/files/export-zip`
  - `/files/write`
- 给 `v1.06` 的 `frontend/src/api/sandbox.js` 增加：
  - `getSessionZipExportUrl`
  - `writeFile`

当前状态：

- 已完成
- 已通过实际接口联调验证

完成标准：

- 后端可导出指定 workspace 子目录
- 前端可通过统一接口把文本或 base64 内容写回容器文件

### Phase 2：迁移 `file_write -> 多源卡片增强`

目标：

- 让 `v1.06` 在保持现有消息持久化模型不变的前提下，补齐多源卡片自动生成能力

建议迁移：

- 基于 `v1.06` 的 `sandbox_event_bridge.py` 做增量改造
- 引入 `main` 中的：
  - `CARD_ROUTES`
  - `_enrich_file_element()`
  - `_build_diff_element()`
- 保留 `v1.06` 当前已有的：
  - `raw_output`
  - `elements`
  - `meta.events`
  - `flag_modified(message, "elements")`
  - `flag_modified(message, "meta")`

合并原则：

- 不改现有持久化展示模型
- 不改 direct round 主流程
- 只增强 `file_write` 事件后的产物构建能力

当前状态：

- 后端已完成
- 前端已补最小可见性修复
- 当前仍处于“过渡态卡片展示”，尚未进入统一 Workbench

完成标准：

- `file_write` 后，消息中能稳定看到 file/image/table/code/webpage/diff 元素
- 刷新页面后，这些 elements 能从数据库恢复

### Phase 3：迁移前端编辑器与 Workbench

目标：

- 在 `v1.06` 中引入可编辑的统一产物工作台

建议迁移：

- 先补依赖：
  - `codemirror`
  - `vue-codemirror`
- 再迁移组件：
  - `CodeEditor`
  - `HtmlPageEditor`
  - `DiffViewCard`
  - `ImageCropper`
  - `ArtifactWorkbench`

前端接入顺序建议：

1. 先让 `MessageBubble` 支持统一打开 Workbench
2. 再接 code 编辑
3. 再接 html 编辑
4. 再接 table 编辑
5. 最后接 image 和 diff

当前状态：

- Workbench 主体骨架已按 `main` 结构迁入 `v1.06`
- `CodeEditor / HtmlPageEditor / DiffViewCard / ImageCropper / ArtifactWorkbench` 已落到 `v1.06`
- `frontend/package.json` 已补 `codemirror`、`vue-codemirror`
- 当前仍未完成的部分主要是：
  - 前端依赖安装与构建验证
  - `MessageBubble` 与 Workbench 的进一步交互收口
  - 保存/裁剪/diff 应用后的专项联调与回显确认

完成标准：

- 点击 artifact 卡片可进入统一工作台
- code/html/table/image 各自能完成预览与保存
- diff 可查看并应用

### Phase 4：收口 UI，避免双套入口并存

目标：

- 避免 `MessageBubble` 与 `ArtifactWorkbench` 长期双套编辑入口并存

建议：

- 中长期以 `ArtifactWorkbench` 为主工作区
- `MessageBubble` 负责轻量展示与跳转
- 复杂编辑能力不再长期分散在气泡内部

当前状态：

- 已开始第一步收口
- `MessageBubble` 中网页、图片、代码产物已进一步统一为以 `ArtifactWorkbench` 为主入口
- 原有气泡内代码预览弹窗、图片预览弹窗已移除，不再与 Workbench 并存
- 当前仍未完全完成：
  - 其余历史轻量入口是否继续保留，仍需按实际使用频率再收一轮
  - 需要结合一次完整构建/联调确认 UI 收口后没有引入新交互回退

## 8. 文件级迁移建议

### 8.1 可直接新增或整体迁移

- `backend/app/services/workspace_diff_service.py`
- `frontend/src/components/ArtifactWorkbench/index.vue`
- `frontend/src/components/CodeEditor/index.vue`
- `frontend/src/components/HtmlPageEditor/index.vue`
- `frontend/src/components/DiffViewCard/index.vue`
- `frontend/src/components/ImageCropper/index.vue`

### 8.2 以 v1.06 为主，做增量合并

- `backend/app/services/sandbox_event_bridge.py`
- `backend/app/sandbox/host/manager.py`
- `backend/app/sandbox/api/routes.py`
- `frontend/src/api/sandbox.js`
- `frontend/src/components/MessageBubble/index.vue`

### 8.3 明确保留 v1.06，不要覆盖

- `frontend/src/views/Dashboard.vue`
- `frontend/src/components/ChatWindow/index.vue`
- `backend/app/services/message_service.py`
- `backend/app/controllers/message_controller.py`

## 9. 验收标准

满足以下条件可认为本轮目标基本完成：

- `weagent-v1.06` 原有 `@Agent` mention 和 direct round 能力不回退
- `file_write` 后可生成并展示多源 elements
- 前端可对代码、HTML、表格、图片执行编辑或裁剪
- 编辑后的内容能写回容器文件
- 可导出 ZIP
- diff 基于真实工作区文件历史生成，而不是纯前端假数据
- 刷新页面后，历史消息中的多源卡片不丢失

## 10. 风险与限制

- `sandbox_event_bridge` 是高风险文件
  - 一旦粗暴覆盖，容易破坏 `v1.06` 当前稳定的消息持久化链路
- `MessageBubble` 已经较重
  - 继续叠加功能可能导致组件复杂度失控
- `ArtifactWorkbench` 引入后会形成新的中心交互
  - 需要避免和气泡内编辑入口冲突
- `grapesjs`、`codemirror` 迁入后需要重新验证前端构建
- `workspace_diff_service` 依赖 `write_workspace_file`
  - 如果 Phase 1 基础能力未打稳，后续 diff 能力会整体失效

## 11. 下一步

建议按以下顺序继续推进：

1. 保持 Phase 1、Phase 2 当前已完成状态不回退
2. 在 `weagent-v1.06/frontend` 安装新增依赖并完成一次构建验证
3. 继续收口 `MessageBubble -> ArtifactWorkbench`：
   - 统一打开
   - 统一预览
   - 统一切换文件
4. 针对以下能力补专项联调：
   - code 保存
   - html 保存与预览刷新
   - table 保存
   - image 裁剪保存
   - diff 查看与应用
5. 最后补专项测试：
   - sandbox event 持久化测试
   - write/export API 测试
   - MessageBubble / Workbench 联调测试

