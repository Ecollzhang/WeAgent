# 多工具 AI 友好化方案 — Spec

> 版本：v1.0 | 最后更新：2026-06-09
> 本文档定义 `3-仓库友好化一期` 中 AI 规则从单工具绑定升级为多工具兼容的目标、范围与落地方案。

---

## 背景

当前仓库中的 AI 规则主要放在 `.opencode/rules/`，天然偏向 OpenCode。

但项目在展示和答辩时，需要让评委能够直观看到：该仓库并不依赖单一 AI 工具，而是能够同时兼容 OpenCode、Claude Code、Cursor、Codex 等常见 AI 编程工具。

现有问题主要有三类：

- 规则入口绑定单一工具，不利于体现“通用 AI 友好仓库”。
- 如果把规则复制到多个目录，后续维护容易不一致。
- 如果只在各工具目录写“请去读另一份文件”，工具是否继续读取并不稳定。

---

## 目标

建立一套“单一规则源 + 多工具适配入口”的结构，使同一份 AI 规则可以被多种工具消费，同时避免人工同步和平台相关依赖。

---

## 用户故事

```text
作为项目维护者，
我希望仓库中的 AI 规则只有一份真实来源，
以便在支持多个 AI 工具的同时，降低维护成本并提升展示效果。
```

```text
作为竞赛评委，
我希望打开仓库后能快速看出它支持多种 AI 工具协作，
以便判断团队是否具备结构化的 AI 工程实践能力。
```

---

## 范围

本次方案包含：

- 统一规则源目录设计。
- OpenCode、Claude Code、Cursor、Codex 的入口适配方案。
- 面向评委展示的目录结构建议。
- 风险、验证方式和后续迭代方向。

本次方案不包含：

- 各工具真实联调与自动化验证脚本实现。
- Trae 的最终适配落地。
- 对业务代码目录的改造。

---

## 方案结论

### 1. 统一规则源

建立 `AI/rules/` 作为唯一规则源，所有长期维护的 AI 协作规则都放在这里。

建议初始文件如下：

```text
AI/rules/
├── repository-overview.md
├── tech-stack.md
├── module-boundary.md
├── code-style.md
└── collaboration.md
```

### 2. 各工具使用超薄适配层

不同工具不共享自己的配置目录，但它们都应指向同一个规则源。

| 工具 | 适配方式 | 说明 |
|------|----------|------|
| OpenCode | `opencode.json` 使用 `instructions: ["AI/rules/*.md"]` | 原生支持外部路径加载，最可靠 |
| Claude Code | `CLAUDE.md` 或 `.claude/rules/00-welcome.md` | 自动加载入口，再指向 `AI/rules/` |
| Cursor | `.cursor/rules/00-welcome.md` | 放入口文件，再指向 `AI/rules/` |
| Codex | `AGENTS.md` | 使用仓库级协作入口，补充指向 `AI/rules/` |
| Trae | 待确认 | 暂留扩展位 |

### 3. 入口文件不能只写“跳转”

各工具入口文件不应只写“请去读 `AI/rules/`”。更稳妥的做法是：

- 在入口文件中保留最关键的 5 到 10 条硬规则。
- 在末尾补充“详细规则见 `AI/rules/`”。

这样即使某个工具未继续读取外部文件，也能拿到最小必要约束。

### 4. 不使用符号链接，不做人工同步

不采用符号链接方案，也不采用手工复制同步方案。

原因：

- Windows 符号链接对环境有要求，答辩和复现不稳定。
- 多目录同步会制造重复事实来源，长期容易漂移。
- 配置文件应保持稳定，规则正文只维护在 `AI/rules/`。

---

## 推荐目录结构

```text
3-仓库友好化一期/
├── AI/
│   └── rules/
│       ├── repository-overview.md
│       ├── tech-stack.md
│       ├── module-boundary.md
│       ├── code-style.md
│       └── collaboration.md
├── CLAUDE.md
├── AGENTS.md
├── .claude/
│   └── rules/
│       └── 00-welcome.md
├── .cursor/
│   └── rules/
│       └── 00-welcome.md
└── opencode.json
```

说明：

- `AI/rules/` 是唯一规则源。
- `CLAUDE.md` 和 `AGENTS.md` 同时承担“通用入口”和“评委可见入口”的作用。
- `.claude/`、`.cursor/`、`opencode.json` 体现对具体工具的适配能力。

---

## P0 / P1 / P2

| 等级 | 内容 |
|------|------|
| P0 | 建立 `AI/rules/` 唯一规则源，并确定 OpenCode / Claude / Cursor / Codex 的入口策略 |
| P1 | 补齐 `CLAUDE.md`、`AGENTS.md`、`.claude/rules/00-welcome.md`、`.cursor/rules/00-welcome.md` 的最小内容 |
| P2 | 实测各工具加载效果，并沉淀为团队长期规则 |

---

## 验收标准

- [ ] 规则正文只有一份事实来源，即 `AI/rules/`
- [ ] OpenCode 可通过 `instructions` 直接加载 `AI/rules/*.md`
- [ ] Claude Code、Cursor、Codex 至少各有一个明确入口文件
- [ ] 入口文件不是纯跳转，包含最小必要规则
- [ ] 方案文档中不再推荐符号链接和人工同步
- [ ] 评委查看目录结构时，能够直观看出“多工具兼容”

---

## 风险与降级

| 风险 | 降级方案 |
|------|---------|
| 某工具不会继续读取 `AI/rules/` | 在入口文件中保留最关键规则，避免完全失效 |
| 各工具入口机制后续变动 | 仅调整适配层，不改 `AI/rules/` 正文 |
| `AI/rules/` 路径不适合最终展示 | 保持“单一规则源”原则，允许后续迁移目录位置 |
| Trae 机制不明确 | 暂时不承诺完全适配，保留扩展位 |

---

## 实施步骤

1. 从现有 `.opencode/rules/` 提炼出 5 份规则，迁入 `AI/rules/`。
2. 修改 `opencode.json`，通过 `instructions` 直接加载 `AI/rules/*.md`。
3. 新增 `CLAUDE.md`，写入最小必要规则并指向 `AI/rules/`。
4. 新增 `AGENTS.md`，写入 Codex 协作入口并指向 `AI/rules/`。
5. 新增 `.claude/rules/00-welcome.md` 与 `.cursor/rules/00-welcome.md`，保留超薄入口内容。
6. 对展示文档和 README 做一次统一口径更新。
7. 实测 OpenCode、Claude Code、Cursor、Codex 的入口是否按预期生效。

---

## 后续沉淀建议

- 方案稳定后，可将本文升级为团队正式规范。
- 工具适配经验可沉淀为 `协作资产/rules/ai-tool-config-rules.md`。
- 各工具实测结果可单独归档为一次 session 或 summary。

---

## 自我迭代

> 版本：v1.0 | 最后更新：2026-06-09 | 更新人：AI

### 修改流程

1. 工具适配策略变化时，更新本文件
2. 在文件头部更新版本号和日期
3. 如果变更涉及规则源位置或入口机制，需同步更新展示文档
4. 实测结果应优先于推测结论
