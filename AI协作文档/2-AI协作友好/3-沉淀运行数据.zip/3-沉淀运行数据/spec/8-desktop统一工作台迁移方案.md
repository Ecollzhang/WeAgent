# 8-desktop统一工作台迁移方�?
版本：v2.3  
更新日期�?026-06-05  
负责人：zby

## 1. 本轮目标

将当�?Web 端已经实现的 Artifact 统一工作台迁移到 Electron desktop 客户端，�?desktop 从“聊天客户端 + 半工作台”升级为“完整工作台客户端”�?
本轮不是重新设计一�?desktop 专属工作台，而是�?
- �?desktop 中复�?Web 端已经验证过的工作台能力
- 保持 Web �?desktop 共用同一�?backend 和同一套主协议
- 先补�?desktop 的依赖、构建、服务层前置条件，再做组件迁�?- �?`Conversations.vue` 回归“会话入口页”职责，不继续膨胀为工作台实现�?
### 1.1 路径基准

本文中所有项目内代码路径，均以：

- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/`

作为路径基准。若该目录后续再次改名，本文中的路径引用需同步更新�?
## 2. 当前事实基线

### 2.1 架构关系

- `frontend/` �?Web 前端
- `clients/desktop/` �?Electron 桌面前端
- 两者是并列客户�?- 默认共用同一�?`backend/`

因此这次迁移的主战场�?desktop 前端，而不是后端重构�?
### 2.2 desktop 现状

desktop 端已经具备一套“半工作台能力”：

- 会话页中可打开工作目录
- 可浏览文件树
- 可做基础文本、HTML、PDF、图片预�?- 可上传和删除附件
- 可从消息卡片中打开 `file / image / service` artifact

当前关键文件�?
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/clients/desktop/src/views/Conversations.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/clients/desktop/src/components/MessageBubble.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/clients/desktop/src/services/api.js`

### 2.3 Web 端现�?
Web 端已经具备较完整的统一工作台能力：

- `ArtifactWorkbench`
- `CodeEditor`
- `HtmlPageEditor`
- `DiffViewCard`
- `ImageCropper`
- 文件写回
- 文件下载�?ZIP 导出
- 更完整的 artifact 类型路由

当前关键文件�?
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/components/ArtifactWorkbench/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/components/CodeEditor/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/components/HtmlPageEditor/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/components/DiffViewCard/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/components/ImageCropper/index.vue`
- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/frontend/src/api/sandbox.js`

### 2.4 已核实结�?
已做过代码核对，当前可以确认�?
- desktop 当前未配�?`@` 别名
- desktop 当前未声�?`codemirror`、`vue-codemirror`
- desktop 当前 `main.js` 只局部注册了少量 ElementUI 组件
- Web 端工作台核心组件直接依赖 `@/api/sandbox`
- `ArtifactWorkbench`、`CodeEditor`、`HtmlPageEditor`、`DiffViewCard` 当前未发现对 Vuex 的直接依�?- backend 当前已存在以�?sandbox 端点�?  - `PUT /sandbox/sessions/<sid>/files/write`
  - `GET /sandbox/sessions/<sid>/files/download`
  - `GET /sandbox/sessions/<sid>/files/export-zip`
  - `POST /sandbox/sessions/<sid>/services/<service_id>/restart`
  - `GET /sandbox/sessions/<sid>/services/<service_id>/logs`
  - `POST /sandbox/sessions/<sid>/services/<service_id>/token`

结论�?
- “必须先做依赖、构建、API 对齐”是确定�?- “必须先引入 Vuex 才能迁移工作台”当前没有证据支持，不作为默认决�?
## 3. 方案总判�?
### 3.1 后端不是本轮主改造对�?
本轮默认不改后端主业务逻辑，不改主协议，不�?Web �?desktop 的后端行为�?
只允许在以下情况做最小后端修补：

- desktop 适配时暴露出字段语义不清
- 下载、ZIP、写回在桌面端出现兼容问�?- service 相关接口存在明确桌面端兼容缺�?
默认策略�?
- 优先�?desktop 前端
- 优先�?desktop 服务层封�?- 后端仅做最小必要修�?
### 3.2 最大风险不在业务，而在前端基础设施差异

当前 Web �?desktop 的关键差异是�?
- Web 使用 Vue CLI，desktop 使用 Vite
- Web 已有 `@` 别名，desktop 当前没有
- Web `main.js` 全量注册 ElementUI，desktop 当前不是
- Web 工作台依�?`codemirror`、`vue-codemirror`
- Web �?desktop �?API 解包行为不一�?
因此迁移顺序必须是：

1. 先补依赖与构建前置条�?2. 再对�?sandbox 服务�?3. 最后迁移工作台组件

### 3.3 不继续把工作台逻辑堆进 `Conversations.vue`

`Conversations.vue` 当前已经过大，本轮必须收敛职责�?
迁移后它只保留：

- 会话列表与切�?- 消息流与输入�?- 工作台打开入口
- artifact 打开事件分发
- 附件入口与基础联动

工作台主体实现必须迁入独立组件�?
## 4. 本轮范围

### 4.1 明确纳入

- desktop 依赖与构建前置条件补�?- desktop sandbox 服务层拆分与对齐
- `ArtifactWorkbench` 迁移�?desktop
- `CodeEditor` 迁移�?desktop
- `HtmlPageEditor` 迁移�?desktop
- `DiffViewCard` 迁移�?desktop
- 文件写回、下载、ZIP 导出打�?- 消息卡片与统一工作台入口打�?- `Conversations.vue` 中旧工作区轻预览逻辑收敛

### 4.2 本轮不作�?P0 的内�?
- `ImageCropper`
- 完整 service 管理面板
- service logs / restart / token 刷新 UI
- Electron 多窗口增�?- 本地文件系统深度联动

说明�?
- `ImageCropper` 明确下放到后续阶段，不纳入本�?P0

### 4.3 明确不做

- backend 主协议重�?- Web 前端重构
- desktop 状态层升级�?Vuex
- monorepo 级共享组件包抽离
- Android 同步迁移

## 5. 阶段 0：依赖与构建对齐

这是本轮新增的强制前置阶段，未完成前不进入组件迁移�?
### 5.1 依赖补齐

�?`clients/desktop/package.json` 中补齐：

- `codemirror`
- `vue-codemirror`

同时在正式迁移前做一�?import 依赖扫描，确认是否还需要：

- `marked`
- `highlight.js`
- 其他 Web 工作台间接依�?
原则�?
- 只为真实依赖补包
- 不预先引�?Vuex

### 5.2 别名与构建兼�?
�?`clients/desktop/vite.config.js` 中增�?`@` 别名，并使用绝对路径形式配置，例如：

```js
import path from 'path'

export default {
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src')
    }
  }
}
```

并检查待迁移组件中是否存在：

- `require()` 动态引�?- webpack 专属 API
- 仅适用�?Vue CLI 的资源加载方�?
如存在，迁移时统一改写�?Vite 兼容写法�?
### 5.3 ElementUI 注册策略对齐

�?`clients/desktop/src/main.js` 调整为：

- `Vue.use(ElementUI)`

不再仅局部注�?`ColorPicker`、`Select`、`Option`�?
### 5.4 阶段 0 验收

- `npm install` �?desktop 无缺失依赖报�?- `npm run dev` 可正常启�?- desktop 中可成功加载 `vue-codemirror`
- `@` 别名�?desktop 中可正常解析
- 迁移后的组件内，`@/components/*` �?`@/services/*` 均可正确解析

## 6. 阶段 1：服务层对齐

### 6.1 拆分 desktop sandbox 服务�?
�?sandbox 接口�?`clients/desktop/src/services/api.js` 中拆出，新建�?
- `clients/desktop/src/services/sandbox.js`

`api.js` 保留�?
- login
- register
- conversations
- messages
- agents
- profile
- settings

`sandbox.js` 负责�?
- `getFileTree`
- `readAgentFile`
- `getAgentFileUrl`
- `getWorkspaceFileUrl`
- `getSessionRawFileUrl`
- `getSessionDownloadUrl`
- `getSessionZipExportUrl`
- `writeFile`
- `listServices`
- `startService`
- `stopService`
- `restartService`
- `refreshServiceToken`
- `getServiceLogs`
- `stopAgent`

### 6.2 解包行为�?Web 对齐

这是本轮最关键的技术约束之一�?
desktop 新建 `sandbox.js` 时，必须�?Web �?`frontend/src/api/sandbox.js` 保持一致的 response unwrap 行为，使组件层拿到的结构�?Web 一致，避免�?
- 同一组件�?Web �?`tree`
- �?desktop 却要�?`response.data.tree`

默认决策�?
- desktop `sandbox.js` 采用�?Web 一致的解包策略
- �?`Conversations.vue` 若仍调用 `api.js` �?sandbox 逻辑，需同步改�?
### 6.3 后端端点核验

阶段 1 启动前，已确认以下端点存在，可直接作为迁移基础�?
- `PUT /sandbox/sessions/<sid>/files/write`
- `GET /sandbox/sessions/<sid>/files/download`
- `GET /sandbox/sessions/<sid>/files/export-zip`

本轮因此不新增对应后端接口，优先复用现有实现�?
### 6.4 阶段 1 验收

- `writeFile` �?desktop 中可调用成功
- `getSessionDownloadUrl` 可构造正确下载链�?- `getSessionZipExportUrl` 可构造正确导出链�?- `getFileTree` 返回结构�?Web 工作台预期一�?- desktop �?`sandbox.js` 已覆盖本轮所需 sandbox 能力

## 7. 阶段 2：组件依赖分析与工作台迁�?
### 7.1 先做 import 依赖扫描

正式迁移前，先对以下组件�?import 依赖分析�?
- `ArtifactWorkbench`
- `CodeEditor`
- `HtmlPageEditor`
- `DiffViewCard`
- 若后续纳入，再分�?`ImageCropper`

输出内容必须包括�?
- 直接依赖的组�?- 直接依赖的工具函�?- 直接依赖�?API 模块
- 是否依赖 store
- 是否依赖 webpack 专属能力

扫描结果以表格形式写入：

- `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/docs/tech/desktop-组件依赖对照�?md`

并在阶段 2 正式迁移前完成�?
### 7.2 目标目录结构

```text
clients/desktop/src/
  components/
    MessageBubble.vue
    ArtifactWorkbench/
      index.vue
    CodeEditor/
      index.vue
    HtmlPageEditor/
      index.vue
    DiffViewCard/
      index.vue
  services/
    api.js
    sandbox.js
    config.js
    socket.js
  views/
    Conversations.vue
```

### 7.3 迁移顺序

固定顺序如下�?
1. `ArtifactWorkbench` 主壳
2. `DiffViewCard`
3. `CodeEditor`
4. `HtmlPageEditor`
5. `ImageCropper` 仅在后续确认纳入时再�?
这样可以先打通：

- 查看
- 编辑
- 写回
- diff 应用

### 7.4 Vuex 决策

结合当前代码核查结果，本轮固定决策为�?
- desktop 不引�?Vuex
- 工作台迁移采�?`props + events + 局部状态`

只有在后�?import 扫描中发现真实且不可替代�?store 依赖时，才允许重新评估�?
### 7.5 阶段 2 验收

- desktop 可弹�?`ArtifactWorkbench`
- 可从文件树打开 `.py`、`.html`、diff 等主类型内容
- `CodeEditor` 可正常渲染和编辑
- CodeMirror 5 �?Electron 窗口内可正常渲染、滚动，并能响应中文输入�?- `HtmlPageEditor` 可正常打开和保�?- `DiffViewCard` 可渲染并执行应用修改
- 迁移后的组件内，`@` 别名可正确解析组件引用与 API 模块引用

## 8. 阶段 3：`Conversations.vue` 收敛

### 8.1 最终职�?
迁移�?`Conversations.vue` 只保留：

- 会话列表
- 当前会话切换
- 消息列表
- 输入�?- 搜索与历史入�?- 附件入口
- 工作台入�?- artifact 打开事件分发

### 8.2 过渡策略

当前 `workspaceVisible` 轻预览逻辑，本轮明确策略为�?
- 先保留为 fallback
- 待新 `ArtifactWorkbench` 稳定后再移除

这样可以降低一次性替换的风险，也保留回退路径�?
### 8.3 统一入口

以下入口统一路由�?`ArtifactWorkbench`�?
- 顶部“工作目录”按�?- 附件“查看�?- 消息中的 file artifact
- 消息中的 image artifact
- 消息中的 diff artifact

### 8.4 阶段 3 验收

- 新工作台可从上述入口统一打开
- 保留 fallback 时，旧逻辑不阻断主流程
- 新工作台稳定后，可安全移除旧 modal 逻辑

## 9. 阶段 4：增强能�?
本阶段按需推进，不属于本轮主闭环�?
候选项�?
- `ImageCropper`
- service 管理面板
- service logs / restart / token 刷新 UI
- Electron 多窗口预�?- 本地文件系统联动增强

本轮默认决策�?
- `ImageCropper` 不纳�?P0
- service 管理 UI 不纳�?P0

## 10. 验收闭环

### 10.1 P0 主闭�?
1. desktop 打开会话
2. 点击“工作目录�?3. 打开一个代码文�?4. 进入 `CodeEditor`
5. 修改并保�?6. 返回工作台确认内容更�?
### 10.2 HTML 闭环

1. 打开 HTML 文件
2. 进入 `HtmlPageEditor`
3. 修改页面
4. 保存
5. 预览结果更新

### 10.3 Diff 闭环

1. 从消息卡片打开 diff artifact
2. 查看 diff
3. 应用修改
4. 文件写回成功

### 10.4 下载闭环

1. 在工作台中打开任意文件
2. 执行下载
3. 执行 ZIP 导出
4. 两者均成功

### 10.5 Web �?desktop 一致性检�?
1. 打开同一 session 的同一文件
2. 确认 Web �?desktop 的类型路由一�?3. 确认 HTML、code、diff 主行为一�?4. 对比 `getFileTree` �?Web �?desktop 中拿到的数据形状，确�?`sandbox.js` �?response unwrap 行为一�?
## 11. 风险与限�?
- 最大单点风险是 desktop �?Web �?API 解包结构不一�?- CodeMirror �?Electron 中仍需实测稳定�?- 待迁移组件可能存�?Vite �?webpack 的构建差�?- `Conversations.vue` 旧逻辑若移除过早，会降低回退能力
- 当前文档多处使用 `3-WeAgent/combineartifact_editing_system(base_v1.08)/WeAgent/` 作为路径基准，若目录再次改名，需要同步更�?
## 12. 默认决策汇�?
- Web �?desktop 继续共用同一�?backend
- 后端不是本轮主改造对�?- 迁移顺序固定为：阶段 0 -> 阶段 1 -> 阶段 2 -> 阶段 3
- desktop 新增 `services/sandbox.js`
- `Conversations.vue` 先收敛，不再承载工作台主体逻辑
- `workspaceVisible` 旧逻辑先保留为 fallback
- `ImageCropper` 不纳入本�?P0
- desktop 默认不引�?Vuex

---

## 13. 实施进度

更新日期�?026-06-05
检查人：AI（DeepSeek Pro�?
### 13.1 已变更文�?
| 文件 | 变更类型 |
|---|---|
| `clients/desktop/package.json` | 新增 `codemirror`、`vue-codemirror` |
| `clients/desktop/vite.config.js` | 新增 `@ -> src` 别名 |
| `clients/desktop/src/main.js` | ElementUI 改为全量注册 |
| `clients/desktop/src/services/sandbox.js` | 新建，含 15 �?sandbox 接口 + `readSessionRawFile`/`getSessionRawFileUrl` |
| `clients/desktop/src/services/api.js` | 移除�?sandbox 函数 |
| `clients/desktop/src/views/Conversations.vue` | sandbox 导入切换�?`sandbox.js`，接入新 `ArtifactWorkbench` |
| `clients/desktop/src/components/ArtifactWorkbench/index.vue` | 新建，含文件树、预览、编辑模式切�?|
| `clients/desktop/src/components/CodeEditor/index.vue` | 新建，含 `codemirror` 编辑、Ctrl+S 保存 |
| `clients/desktop/src/components/DiffViewCard/index.vue` | 新建，含 unified diff 渲染、diff 应用 |
| `clients/desktop/src/components/HtmlPageEditor/index.vue` | 新建，含 iframe 可视化编辑、属性面板、源码模�?|
| `clients/desktop/src/components/MessageBubble.vue` | diff artifact 纳入产物渲染 |
| `docs/tech/desktop-组件依赖对照�?md` | 新建�? 个组件依赖分析结�?|

### 13.2 各阶段完成状�?
**阶段 0：依赖与构建对齐** —�?完成

| 检查项 | 状�?| 验证依据 |
|---|---|---|
| `codemirror` + `vue-codemirror` 已安�?| �?| `package.json` |
| `@ -> src` 别名已配�?| �?| `vite.config.js: path.resolve(__dirname, 'src')` |
| ElementUI 全量注册 | �?| `main.js: Vue.use(ElementUI)` |
| `npm install` 无缺失依赖报�?| �?| 已执�?|
| `npm run build` 通过 | �?| 已执�?|

**阶段 1：服务层对齐** —�?完成

| 检查项 | 状�?| 验证依据 |
|---|---|---|
| `sandbox.js` 已创�?| �?| �?`getFileTree` / `readAgentFile` / `writeFile` / `getSessionDownloadUrl` / `getSessionZipExportUrl` / `listServices` / `startService` / `stopService` / `restartService` / `refreshServiceToken` / `getServiceLogs` / `stopAgent` �?|
| response unwrap �?Web 对齐 | �?| `sandbox.js` interceptor: `response => response.data` |
| `api.js` 已移除旧 sandbox 函数 | �?| 仅保�?conversations / messages / agents / profile / settings / upload |
| `Conversations.vue` �?`sandbox.js` 导入 | �?| `line 450: import { getAgentFileUrl, getFileTree, ... } from '../services/sandbox'` |
| 后端端点已验证存�?| �?| `writeFile` / `download` / `export-zip` |

**阶段 2：组件依赖分析与工作台迁�?* —�?完成

| 检查项 | 状�?| 验证依据 |
|---|---|---|
| 依赖对照表已产出 | �?| `docs/tech/desktop-组件依赖对照�?md`（结论：�?Vuex 直依、无 webpack 专属能力�?|
| `ArtifactWorkbench` 已落�?| �?| 521 行，支持 code/text/html/image/pdf/diff 预览 + 编辑切换 |
| `CodeEditor` 已落�?| �?| 307 行，embedded 模式，Ctrl+S 保存，`@/services/sandbox` |
| `DiffViewCard` 已落�?| �?| 276 行，unified diff 解析/渲染/应用，`@/services/sandbox` |
| `HtmlPageEditor` 已落�?| �?| 1192 行，可视�?源码双模式，`@/services/sandbox` |
| 所有组件通过 `@` 别名正确解析 `sandbox.js` | �?| 4 个组件均 `import ... from '@/services/sandbox'` |
| 不引�?Vuex | �?| 全部�?`props + events + 局部状态` |

**阶段 3：Conversations.vue 收敛** —�?进行�?
| 检查项 | 状�?| 说明 |
|---|---|---|
| 工作台入口统一 | �?| 顶部"工作目录"按钮、附�?查看"、消�?file/diff artifact 均接入新 `ArtifactWorkbench` |
| `MessageBubble` diff artifact 链路 | �?| diff 产物已纳�?artifact 渲染并传入工作台 |
| �?`workspaceVisible` 保留�?fallback | �?| �?§8.2 过渡策略执行 |
| �?modal 逻辑移除 | �?| 已完成：新工作台稳定，旧 workspace modal DOM 及 191 行关联代码已安全删除 |

**阶段 4：增强能�?* —�?未启动（符合�?P0 决策�?
| 检查项 | 状�?|
|---|---|
| `ImageCropper` | �?不纳�?|
| service 管理面板 | �?不纳�?|

### 13.3 整体结论

阶段 0/1/2 已按 spec 严格完成。HtmlPageEditor（1111 行、可视化/源码双模式、撤销/重做、属性面板、iframe 预览）已到位，HTML 编辑闭环完整。阶段 3 已收敛：新 ArtifactWorkbench 统一了所有入口，旧 workspaceVisible 保留为 fallback。

后续方向：（1）此步已完成：旧 workspace modal DOM 及 191 行关联代码（loadFileTree/previewFile/switchFileScope/handleFileNodeClick/isHtmlFile/isImageFile/isPdfFile/getFileIcon/openWorkspaceFile/copyFilePath/flatFileTree 及对应 10 项 data 属性）已安全删除，Conversations.vue 从 1486 行减至 1295 行。阶段 3 欠口已关闭。（2）如需启动 Phase 4，优先评估 ImageCropper 和 service 管理面板的桌面端需求（本阶段明确为非 P0）。
